# Darbarjah Firebase Firestore Security Specification

## Phase 0: Security Invariants & TDD Definition

### 1. Data Invariants
1. **User Identity Invariant**: A user document at `/users/{userId}` can only be created, read, or modified by the user whose authenticated UID strictly matches `userId`. Users cannot impersonate other learners or modify other users' stats, XP, streak, or lessons.
2. **Subcollection Relational Guard**: Any document in `/users/{userId}/reviews/{reviewId}` or `/users/{userId}/bookmarks/{bookmarkId}` must belong to the parent `{userId}`, and `incoming().userId` must strictly match `request.auth.uid`.
3. **Immutability of Identity**: `id` and `userId` fields cannot be mutated post-creation.
4. **Finite Bound Protections**: All string fields must adhere to size bounds (e.g. `username.size() <= 100`, `email.size() <= 150`, IDs `<= 128`).
5. **No Blanket Reads**: List operations on `/users` are strictly forbidden; queries only allow individual user lookup matching `request.auth.uid`.
6. **Subcollection List Enforcement**: List queries on `/users/{userId}/reviews` or `/users/{userId}/bookmarks` must verify that the requesting user's UID matches `{userId}`.

### 2. The "Dirty Dozen" Attack Payloads & Test Scenarios
1. **Ghost Field Injection**: Malicious client attempts to insert an unauthorized `isAdmin: true` or `role: "superuser"` field into `/users/{userId}`.
2. **Identity Spoofing on Create**: An authenticated user with UID `user_attacker` attempts to create `/users/user_victim`.
3. **Orphan Review Creation**: An attacker attempts to create a review under `/users/{victimId}/reviews/rev1` with their own UID or a mismatched UID.
4. **Denial of Wallet ID Bomb**: An attacker tries to write to a document with a 2KB string ID containing invalid characters.
5. **Score Hijacking**: An unauthenticated user attempts to write or read user progress documents.
6. **Streak Tampering**: An authenticated user attempts to write negative streak or negative XP.
7. **Immutable Field Tampering**: An authenticated user attempts to update `/users/{userId}` by altering the original `id` to another user's ID.
8. **Subcollection Cross-User Poisoning**: User A attempts to write a bookmark into User B's `/users/{userB}/bookmarks/{bookmarkId}` path.
9. **Blanket Collection Scraping**: An authenticated user attempts to list the entire `/users` collection without a document key.
10. **Type Mismatch Vulnerability**: An attacker attempts to set `xp` as a boolean (`true`) instead of a number.
11. **Malicious Review Interval Exploitation**: An attacker attempts to set `nextReviewAt` to an arbitrary string or non-number to corrupt the scheduler.
12. **PII Exposure Query**: An authenticated user attempts to execute a collection group query across all `/users` to scrape emails.
