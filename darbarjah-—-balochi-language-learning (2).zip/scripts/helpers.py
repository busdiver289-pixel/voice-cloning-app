import re
import json

def infer_pos(english: str, arabic: str, latin: str) -> str:
    eng = english.lower().strip()
    if eng.startswith("to ") or eng.startswith("to/"):
        return "v"
    if any(eng.endswith(x) for x in ["able", "ible", "ous", "ful", "less", "ish", "ive"]):
        return "adj"
    if any(eng == x for x in ["red", "green", "blue", "white", "black", "yellow", "hot", "cold", "big", "small", "tall", "thin", "fat", "blind", "deaf", "honest", "rich", "poor", "free", "easy", "cheap", "difficult", "heavy", "light"]):
        return "adj"
    if any(eng == x for x in ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "thirty", "forty", "fifty", "sixty", "eighty", "ninety", "hundred", "thousand"]):
        return "num"
    if any(x in eng for x in ["alas", "hello", "hi", "curse", "yippee"]):
        return "interj"
    if len(arabic.split()) > 1:
        return "phrase"
    return "n"

def infer_domain(english: str, urdu: str) -> str:
    combined = (english + " " + urdu).lower()
    if any(x in combined for x in ["water", "river", "sea", "ocean", "flow", "drown", "current", "currents", "swim", "whirlpool", "ship", "boat", "sail", "anchor"]):
        return "nautical"
    if any(x in combined for x in ["alphabet", "word", "language", "grammar", "phonology", "phonetics", "letter", "linguistics", "infinitive", "adjective", "noun", "pronoun", "preposition"]):
        return "linguistics"
    if any(x in combined for x in ["agriculture", "crop", "field", "dam", "irrigate", "wheat", "plough", "harvest", "seed", "cultivate"]):
        return "agriculture"
    if any(x in combined for x in ["plant", "herb", "tree", "flower", "fruit", "date", "palm", "vegetable", "spinach", "tamarind", "ebony"]):
        return "botany"
    if any(x in combined for x in ["animal", "horse", "goat", "camel", "cow", "sheep", "donkey", "dog", "cat", "fish", "bird", "lion", "deer", "eagle", "locust", "ant"]):
        return "zoology"
    if any(x in combined for x in ["eye", "head", "hand", "foot", "mouth", "nose", "throat", "heart", "brain", "chest", "leg", "bone", "skin", "hair", "knee", "tooth"]):
        return "anatomy"
    if any(x in combined for x in ["money", "wealth", "tax", "coin", "rupee", "bank", "market", "trade", "buy", "sell", "debt", "wage", "rich", "poor", "budget"]):
        return "economics"
    if any(x in combined for x in ["mountain", "hill", "desert", "land", "rock", "stone", "sand", "east", "west", "north", "south", "earthquake"]):
        return "geography"
    if any(x in combined for x in ["hello", "welcome", "thanks", "night", "morning", "friend", "father", "mother", "brother", "sister", "wife", "husband", "child"]):
        return "greeting"
    return "general"

print("Helper functions ready")
