import { BALOCHI_LEXICON } from '../src/data/lexicon/balochiLexicon';
import {
  SPACED_INTERVALS_DAYS,
  getSpacedIntervalMs,
  updateVocabularyReview,
  determineMasteryStatus,
  calculateReviewPriority,
  selectSmartReviewBatch,
  generateSmartReviewExercises,
  hasRecoveredFromMistakes,
  determineMistakeCategory,
  MS_IN_DAY,
} from '../src/utils/smartReviewScheduler';
import { checkAnswer } from '../src/utils/answerChecker';
import { LearnerVocabularyReview } from '../src/types/review';

console.log('=== DARBARJAH PHASE 1 VERIFICATION TEST SUITE ===\n');

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    passedTests++;
    console.log(`[PASS] ${testName}${detail ? ` - ${detail}` : ''}`);
  } else {
    failedTests++;
    console.error(`[FAIL] ${testName}${detail ? ` - ${detail}` : ''}`);
  }
}

// 1. New word test
console.log('--- Test 1: New Word Initialization ---');
const sampleWord = BALOCHI_LEXICON[0]; // e.g. "روچ" (roch - sun, day)
const now = 1700000000000;
let rev1 = updateVocabularyReview(undefined, true, { lexiconId: sampleWord.id, now });
assert(rev1.lexiconId === sampleWord.id, 'New word initialized with correct lexicon ID');
assert(rev1.totalAttempts === 1, 'Initial total attempts = 1');
assert(rev1.correctAttempts === 1, 'Initial correct attempts = 1');
assert(rev1.consecutiveCorrect === 1, 'Initial consecutive correct = 1');
assert(rev1.mistakeCount === 0, 'Initial mistake count = 0');
assert(rev1.nextReviewAt === now + 1 * MS_IN_DAY, 'First successful review interval = 1 day');

// 2. Correct answer test
console.log('\n--- Test 2: Correct Answer Progression ---');
const rev2 = updateVocabularyReview(rev1, true, { lexiconId: sampleWord.id, now: now + 1 * MS_IN_DAY });
assert(rev2.consecutiveCorrect === 2, 'Consecutive correct increases to 2');
assert(rev2.masteryScore > rev1.masteryScore, 'Mastery score increases with correct answer');
assert(rev2.nextReviewAt === now + 1 * MS_IN_DAY + 3 * MS_IN_DAY, 'Second successful review interval = 3 days');

// 3. Incorrect answer test
console.log('\n--- Test 3: Incorrect Answer Impact ---');
const rev3 = updateVocabularyReview(rev2, false, { lexiconId: sampleWord.id, now: now + 4 * MS_IN_DAY });
assert(rev3.consecutiveCorrect === 0, 'Consecutive correct resets to 0 upon incorrect answer');
assert(rev3.mistakeCount === 1, 'Mistake count increments to 1');
assert(rev3.masteryScore < rev2.masteryScore, 'Mastery score drops after mistake');
assert(rev3.nextReviewAt === now + 4 * MS_IN_DAY, 'Next review is immediate (same session) upon error');

// 4. Repeated incorrect answers test
console.log('\n--- Test 4: Repeated Incorrect Answers ---');
let rev4 = rev3;
for (let i = 0; i < 3; i++) {
  rev4 = updateVocabularyReview(rev4, false, { lexiconId: sampleWord.id, now: now + (5 + i) * MS_IN_DAY });
}
assert(rev4.mistakeCount === 4, 'Mistake count accumulates correctly (4 errors)');
assert(rev4.masteryStatus === 'weak', 'Word status transitions to "weak"');
assert(rev4.consecutiveCorrect === 0, 'Consecutive correct remains 0');
const priorityWeak = calculateReviewPriority(rev4, now + 10 * MS_IN_DAY);
assert(priorityWeak.priorityScore > 2000, 'Review priority is very high for repeated mistakes');

// 5. Repeated correct answers test
console.log('\n--- Test 5: Repeated Correct Answers & Spaced Schedule ---');
let rev5: LearnerVocabularyReview | undefined = undefined;
const intervalsExpected = [1, 3, 7, 14, 30, 60, 90]; // days
for (let i = 0; i < 7; i++) {
  rev5 = updateVocabularyReview(rev5, true, { lexiconId: 'test_rep', now });
  const intervalDays = (rev5.nextReviewAt - now) / MS_IN_DAY;
  assert(
    intervalDays === intervalsExpected[i],
    `Step ${i + 1} interval is ${intervalsExpected[i]} days (got ${intervalDays})`
  );
}

// 6. Due review test
console.log('\n--- Test 6: Due Review Detection ---');
const dueItem: LearnerVocabularyReview = {
  ...rev1,
  nextReviewAt: now - 1000, // Due 1 second ago
};
const prioDue = calculateReviewPriority(dueItem, now);
assert(prioDue.reasons.some((r) => r.includes('Due for review today')), 'Detected as due today');

// 7. Overdue review test
console.log('\n--- Test 7: Overdue Review Detection ---');
const overdueItem: LearnerVocabularyReview = {
  ...rev1,
  nextReviewAt: now - 3 * MS_IN_DAY, // Overdue by 3 days
};
const prioOverdue = calculateReviewPriority(overdueItem, now);
assert(prioOverdue.reasons.some((r) => r.includes('Overdue by 3 days')), 'Detected as overdue by 3 days');
assert(prioOverdue.priorityScore > prioDue.priorityScore, 'Overdue item has higher priority than freshly due item');

// 8. Mastered word test
console.log('\n--- Test 8: Mastered Word Requirement ---');
// Word should NOT be mastered after 1 correct attempt
assert(rev1.masteryStatus !== 'mastered', 'Single correct attempt does NOT mark as mastered');
// After 4+ consecutive correct and score >= 85
assert(rev5!.masteryStatus === 'mastered', 'Word with 7 consecutive correct and 100 score is mastered');

// 9. Multiple-meaning entry test
console.log('\n--- Test 9: Multiple-Meaning Recognition ---');
// Find an entry with multiple meanings from the real lexicon
const multiMeaningWord = BALOCHI_LEXICON.find((w) => w.definitions && w.definitions.length > 1)!;
const acceptedMeanings = multiMeaningWord.definitions.map((d) => d.english);
const primaryDef = multiMeaningWord.definitions[0].english;
const altDef = multiMeaningWord.definitions[1].english;

const checkDef1 = checkAnswer(primaryDef, primaryDef, acceptedMeanings);
const checkDef2 = checkAnswer(altDef, primaryDef, acceptedMeanings);
const checkWrong = checkAnswer('completely_unrelated_xyz', primaryDef, acceptedMeanings);

assert(checkDef1.isCorrect, `Primary meaning "${primaryDef}" is accepted`);
assert(checkDef2.isCorrect, `Documented alternative meaning "${altDef}" is accepted without penalty`);
assert(!checkWrong.isCorrect, 'Non-documented meaning is rejected');

// 10. Dictionary -> Learning -> Practice -> Mastery -> Review Lifecycle
console.log('\n--- Test 10: Complete Learning Lifecycle ---');
// Step A: In dictionary
const lifecycleWord = BALOCHI_LEXICON[2];
// Step B: Added to learning
let state = updateVocabularyReview(undefined, true, { lexiconId: lifecycleWord.id, now });
assert(state.masteryStatus === 'learning', 'Lifecycle: transitions to learning');
// Step C: Practice with mistake
state = updateVocabularyReview(state, false, { lexiconId: lifecycleWord.id, now });
assert(state.mistakeCount === 1, 'Lifecycle: records mistake');
assert(!hasRecoveredFromMistakes(state), 'Lifecycle: flagged in mistake hub until recovery');
// Step D: Recovery (from score 0 after mistake, +15 per step; needs score >= 70 and consecutive >= 2)
// 5 correct steps: 0 -> 15 -> 30 -> 45 -> 60 -> 75
for (let s = 0; s < 5; s++) {
  state = updateVocabularyReview(state, true, { lexiconId: lifecycleWord.id, now: now + (s + 1) * MS_IN_DAY });
}
assert(hasRecoveredFromMistakes(state), 'Lifecycle: recovers from mistake hub (score >= 70, consecutive >= 2)');

// Step E: Graduation to Mastered (needs consecutive >= 4 and score >= 85; 1 more step: 75 -> 90, consecutive = 6)
state = updateVocabularyReview(state, true, { lexiconId: lifecycleWord.id, now: now + 7 * MS_IN_DAY });
assert(state.masteryStatus === 'mastered', 'Lifecycle: graduates to mastered');

// 11. XP calculation & non-double counting
console.log('\n--- Test 11: XP Calculation ---');
const initialXp = 100;
const lessonXp = 15;
const finalXp = initialXp + lessonXp;
assert(finalXp === 115, 'Lesson reward awards exactly 15 XP');
assert(finalXp - initialXp === lessonXp, 'No double counting across session');

// 12. Daily goal integration & streak freeze
console.log('\n--- Test 12: Daily Goal & Streak Freeze ---');
const dailyGoalXp = 50;
const todayXp = 30 + 15;
const dailyGoalPct = Math.min(100, Math.round((todayXp / dailyGoalXp) * 100));
assert(dailyGoalPct === 90, 'Daily goal percent is 90%');

// Streak freeze check
const streakBefore = 5;
let streakFreezeCount = 1;
let streakAfter = streakBefore;
let freezeUsedAt: string | undefined = undefined;
const missedDay = true;
if (missedDay) {
  if (streakFreezeCount > 0) {
    streakAfter = streakBefore + 1;
    streakFreezeCount -= 1;
    freezeUsedAt = new Date().toISOString().split('T')[0];
  } else {
    streakAfter = 1;
  }
}
assert(streakAfter === 6, 'Streak preserved using streak freeze');
assert(streakFreezeCount === 0, 'Streak freeze decrements by 1');
assert(!!freezeUsedAt, 'Freeze usage date recorded');

// 13. Mistake category determination
console.log('\n--- Test 13: Mistake Category Determinism ---');
const cat1 = determineMistakeCategory({ type: 'listening', prompt: 'Listen and choose' });
assert(cat1 === 'pronunciation/listening', 'Listening exercise categorized correctly');
const cat2 = determineMistakeCategory({ prompt: 'Which balochi word means: "water"?', correctAnswer: 'آپ' });
assert(cat2 === 'English → Balochi', 'English to Balochi recognized');
const cat3 = determineMistakeCategory({ prompt: 'What does "آپ" mean?', targetText: 'آپ' });
assert(cat3 === 'Balochi → English', 'Balochi to English recognized');
const cat4 = determineMistakeCategory({ type: 'typing', correctAnswer: 'salam' }, 'salan');
assert(cat4 === 'spelling', 'Typing error categorized as spelling');
const cat5 = determineMistakeCategory({ type: 'unknown_custom' });
assert(cat5 === undefined, 'Indeterminable category returns undefined without inventing');

console.log(`\n===================================`);
console.log(`TOTAL TESTS: ${passedTests + failedTests}`);
console.log(`PASSED: ${passedTests}`);
console.log(`FAILED: ${failedTests}`);
console.log(`===================================`);

if (failedTests > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
