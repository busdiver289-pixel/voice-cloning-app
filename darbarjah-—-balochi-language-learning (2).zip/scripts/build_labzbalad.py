import json
import re

def main():
    print("Building Balochi Labzbalad database from book...")

if __name__ == "__main__":
    main()
