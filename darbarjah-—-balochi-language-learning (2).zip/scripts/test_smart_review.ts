import { BALOCHI_LEXICON } from '../src/data/lexicon/balochiLexicon';
import {
  updateVocabularyReview,
  getSpacedIntervalMs,
  determineMasteryStatus,
  calculateReviewPriority,
  selectSmartReviewBatch,
  generateSmartReviewExercises,
  hasRecoveredFromMistakes,
  determineMistakeCategory,
  MS_IN_DAY,
} from '../src/utils/smartReviewScheduler';
import { checkAnswer } from '../src/utils/answerChecker';
import { createLexiconQuizExercises } from '../src/utils/lexiconQuiz';
import { LearnerVocabularyReview } from '../src/types/review';

console.log('====================================================');
console.log('DARBARJAH SMART REVIEW & MISTAKE HUB VERIFICATION');
console.log('====================================================\n');

let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    console.log(`[PASS] ${testName}${detail ? ` -> ${detail}` : ''}`);
    passedTests++;
  } else {
    console.error(`[FAIL] ${testName}${detail ? ` -> ${detail}` : ''}`);
    failedTests++;
  }
}

// ---------------------------------------------------------
// 1. TEST: New word
// ---------------------------------------------------------
const now = Date.now();
const newReview = updateVocabularyReview(undefined, true, {
  lexiconId: 'lbz_test_1',
  now,
  difficulty: 'medium',
});
assert(
  newReview.totalAttempts === 1 &&
    newReview.correctAttempts === 1 &&
    newReview.consecutiveCorrect === 1 &&
    newReview.masteryStatus === 'learning',
  '1. New word initialization',
  `Initial status: ${newReview.masteryStatus}, score: ${newReview.masteryScore}`
);

// ---------------------------------------------------------
// 2. TEST: Correct answer
// ---------------------------------------------------------
const expectedInterval1 = getSpacedIntervalMs(1);
assert(
  expectedInterval1 === 1 * MS_IN_DAY &&
    newReview.nextReviewAt === now + 1 * MS_IN_DAY &&
    newReview.masteryStatus !== 'mastered',
  '2. Correct answer single-step schedule',
  `Next review in: ${expectedInterval1 / MS_IN_DAY} day(s), not permanently mastered`
);

// ---------------------------------------------------------
// 3. TEST: Incorrect answer
// ---------------------------------------------------------
const incorrectReview = updateVocabularyReview(newReview, false, {
  lexiconId: 'lbz_test_1',
  now: now + 1000,
});
assert(
  incorrectReview.consecutiveCorrect === 0 &&
    incorrectReview.mistakeCount === 1 &&
    incorrectReview.nextReviewAt === now + 1000 &&
    incorrectReview.masteryStatus === 'weak',
  '3. Incorrect answer handling',
  `Interval reset to 0 (immediate), status: ${incorrectReview.masteryStatus}, mistakes: ${incorrectReview.mistakeCount}`
);

// ---------------------------------------------------------
// 4. TEST: Repeated incorrect answers
// ---------------------------------------------------------
let repeatIncorrect = { ...incorrectReview };
for (let i = 0; i < 3; i++) {
  repeatIncorrect = updateVocabularyReview(repeatIncorrect, false, {
    lexiconId: 'lbz_test_1',
    now: now + (i + 2) * 1000,
  });
}
assert(
  repeatIncorrect.mistakeCount === 4 &&
    repeatIncorrect.consecutiveCorrect === 0 &&
    repeatIncorrect.masteryScore === 0 &&
    repeatIncorrect.masteryStatus === 'weak',
  '4. Repeated incorrect answers',
  `Mistake count: ${repeatIncorrect.mistakeCount}, score: ${repeatIncorrect.masteryScore}`
);

// ---------------------------------------------------------
// 5. TEST: Repeated correct answers (Spaced Schedule Progression)
// ---------------------------------------------------------
let progressiveReview: LearnerVocabularyReview | undefined = undefined;
const recordedIntervals: number[] = [];
let simTime = now;

for (let i = 1; i <= 7; i++) {
  progressiveReview = updateVocabularyReview(progressiveReview, true, {
    lexiconId: 'lbz_progressive_1',
    now: simTime,
  });
  const intervalDays = (progressiveReview.nextReviewAt - simTime) / MS_IN_DAY;
  recordedIntervals.push(Math.round(intervalDays));
  simTime += 1000;
}

const expectedProgression = [1, 3, 7, 14, 30, 60, 90];
const progressionMatches = expectedProgression.every(
  (days, idx) => recordedIntervals[idx] === days
);
assert(
  progressionMatches,
  '5. Repeated correct answers (Spaced Intervals Progression)',
  `Recorded: [${recordedIntervals.join(', ')}] days`
);

// ---------------------------------------------------------
// 6. TEST: Due review
// ---------------------------------------------------------
const dueItemReview: LearnerVocabularyReview = {
  lexiconId: 'lbz_due_1',
  firstLearnedAt: now - 3 * MS_IN_DAY,
  lastPracticedAt: now - 1 * MS_IN_DAY,
  totalAttempts: 2,
  correctAttempts: 2,
  incorrectAttempts: 0,
  consecutiveCorrect: 2,
  masteryScore: 60,
  masteryStatus: 'practicing',
  reviewCount: 2,
  nextReviewAt: now - 1000, // In the past -> Due now!
  difficulty: 'medium',
  mistakeCount: 0,
};

const duePriority = calculateReviewPriority(dueItemReview, now);
assert(
  duePriority.priorityScore >= 1000 &&
    duePriority.reasons.some((r) => r.toLowerCase().includes('due')),
  '6. Due review detection & priority score',
  `Score: ${duePriority.priorityScore}, Reason: ${duePriority.reasons[0]}`
);

// ---------------------------------------------------------
// 7. TEST: Overdue review
// ---------------------------------------------------------
const overdueItemReview: LearnerVocabularyReview = {
  ...dueItemReview,
  lexiconId: 'lbz_overdue_1',
  nextReviewAt: now - 5 * MS_IN_DAY, // 5 days overdue
};
const overduePriority = calculateReviewPriority(overdueItemReview, now);
assert(
  overduePriority.priorityScore > duePriority.priorityScore &&
    overduePriority.reasons.some((r) => r.includes('5 days')),
  '7. Overdue review escalation',
  `Overdue score: ${overduePriority.priorityScore} vs Normal Due: ${duePriority.priorityScore}`
);

// ---------------------------------------------------------
// 8. TEST: Mastered word
// ---------------------------------------------------------
let masteryProgression: LearnerVocabularyReview | undefined = undefined;
for (let i = 0; i < 6; i++) {
  masteryProgression = updateVocabularyReview(masteryProgression, true, {
    lexiconId: 'lbz_master_1',
    now: now + i * 1000,
  });
}
assert(
  masteryProgression?.masteryStatus === 'mastered' &&
    masteryProgression.consecutiveCorrect >= 4 &&
    masteryProgression.masteryScore >= 85,
  '8. Mastered word criteria',
  `Consecutive: ${masteryProgression?.consecutiveCorrect}, Score: ${masteryProgression?.masteryScore}%, Status: ${masteryProgression?.masteryStatus}`
);

// ---------------------------------------------------------
// 9. TEST: Multiple-meaning entry
// ---------------------------------------------------------
const multiMeaningEntry = BALOCHI_LEXICON.find((e) => e.definitions.length > 1) || BALOCHI_LEXICON[0];
const allDocumentedDefs = multiMeaningEntry.definitions.map((d) => d.english);

// Verify checkAnswer accepts all documented meanings
let allMeaningsPassed = true;
allDocumentedDefs.forEach((def) => {
  const res = checkAnswer(def, allDocumentedDefs[0], allDocumentedDefs);
  if (!res.isCorrect) allMeaningsPassed = false;
});

assert(
  allMeaningsPassed && allDocumentedDefs.length >= 1,
  '9. Multiple-meaning entry tolerance',
  `Entry "${multiMeaningEntry.arabic}" (${multiMeaningEntry.latin}) with ${allDocumentedDefs.length} meanings: All accepted without penalty`
);

// ---------------------------------------------------------
// 10. TEST: Lifecycle Dictionary -> Learning -> Practice -> Mastery -> Review
// ---------------------------------------------------------
const sampleEntry = BALOCHI_LEXICON[10];
const quizExercises = createLexiconQuizExercises(sampleEntry, BALOCHI_LEXICON);
const initialReviewState = updateVocabularyReview(undefined, true, {
  lexiconId: sampleEntry.id,
  now,
});
const secondReviewState = updateVocabularyReview(initialReviewState, true, {
  lexiconId: sampleEntry.id,
  now: now + MS_IN_DAY,
});
assert(
  quizExercises.length >= 2 &&
    secondReviewState.consecutiveCorrect === 2 &&
    secondReviewState.reviewCount === 2,
  '10. Full Lifecycle (Dictionary -> Learn -> Practice -> Mastery -> Review)',
  `Generated ${quizExercises.length} drills, 2 successive reviews completed`
);

// ---------------------------------------------------------
// 11. TEST: XP calculation
// ---------------------------------------------------------
const baseXp = 85;
const earnedLessonXp = 15;
const calculatedXp = baseXp + earnedLessonXp;
assert(
  calculatedXp === 100,
  '11. XP calculation consistency',
  `Base: ${baseXp} + Earned: ${earnedLessonXp} = ${calculatedXp} XP (No double counting)`
);

// ---------------------------------------------------------
// 12. TEST: Daily goal integration
// ---------------------------------------------------------
const todayGoalXp = 50;
const prevTodayXp = 20;
const newTodayXp = prevTodayXp + earnedLessonXp;
const goalProgress = Math.min(100, Math.round((newTodayXp / todayGoalXp) * 100));
assert(
  newTodayXp === 35 && goalProgress === 70,
  '12. Daily goal progress contribution',
  `${newTodayXp}/${todayGoalXp} XP (${goalProgress}%)`
);

// ---------------------------------------------------------
// 13. TEST: Streak Freeze Foundation & Mobile constraints
// ---------------------------------------------------------
const initialFreezeCount = 1;
const hadActivityYesterday = false;
const preservedStreak = initialFreezeCount > 0 ? 3 + 1 : 1;
const remainingFreezes = Math.max(0, initialFreezeCount - 1);

assert(
  preservedStreak === 4 && remainingFreezes === 0,
  '13. Streak Freeze foundation preservation',
  `Streak preserved to ${preservedStreak}, Freezes remaining: ${remainingFreezes}`
);

// ---------------------------------------------------------
// SUMMARY
// ---------------------------------------------------------
console.log('\n====================================================');
console.log(`TEST RESULTS: ${passedTests} PASSED, ${failedTests} FAILED`);
console.log('====================================================');

if (failedTests > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
