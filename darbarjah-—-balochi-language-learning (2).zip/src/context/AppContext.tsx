import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  LanguageCode,
  UserProfile,
  VocabularyItem,
  MistakeLog,
  ShopItem,
  UserSettings,
} from '../types';
import {
  COURSES_MAP,
  VOCABULARY_MAP,
} from '../data/courses';
import { BALOCHI_COURSE } from '../data/balochiData';
import { INITIAL_ACHIEVEMENTS } from '../data/achievements';
import { BALOCHI_LEXICON } from '../data/lexicon/balochiLexicon';
import { LexiconEntry } from '../types/lexicon';
import { Exercise } from '../types';
import {
  LearnerVocabularyReview,
  DetailedMistakeRecord,
  StreakFreezeRecord,
  SmartReviewSummary,
  MasteryStatus,
} from '../types/review';
import {
  updateVocabularyReview,
  determineMistakeCategory,
  hasRecoveredFromMistakes,
  selectSmartReviewBatch,
  generateSmartReviewExercises,
} from '../utils/smartReviewScheduler';
import { playSoundEffect } from '../utils/audio';
import { auth, googleProvider } from '../firebase';
import {
  onAuthStateChanged,
  signOut,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import {
  fetchUserProfile,
  saveUserProfile,
  fetchVocabularyReviewsFromFirestore,
} from '../services/firestoreSync';

const STORAGE_KEY_USER = 'darbarjah_user_profile_v2';
const STORAGE_KEY_VOCAB = 'darbarjah_vocab_mastery_v2';
const STORAGE_KEY_MISTAKES = 'darbarjah_mistakes_v2';
const STORAGE_KEY_REVIEWS = 'darbarjah_vocabulary_reviews_v1';
const STORAGE_KEY_DETAILED_MISTAKES = 'darbarjah_detailed_mistakes_v1';

const TODAY_STR = new Date().toISOString().split('T')[0];

const DEFAULT_USER: UserProfile = {
  id: 'usr_default_learner',
  username: 'Karim',
  email: 'learner@darbarjah.app',
  avatarSeed: 'karim',
  nativeLanguage: 'English',
  learningLanguage: 'balochi',
  xp: 85,
  level: 1,
  streak: 3,
  longestStreak: 5,
  lastActivityDate: TODAY_STR,
  activeDates: [
    new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
    new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0],
    TODAY_STR,
  ],
  hearts: 5,
  maxHearts: 5,
  gems: 280,
  dailyGoalXp: 30,
  todayXp: 20,
  unlockedLessons: ['lesson0_1', 'bal_les_1', 'bal_les_2', 'dar_les_1', 'es_les_1', 'ja_les_1', 'fr_les_1', 'de_les_1'],
  completedLessons: ['lesson0_1'],
  streakFreezeCount: 1,
  claimedAchievements: [],
  learningQueueLexiconIds: ['lex_abenk', 'lex_abnak'],
  bookmarkedLexiconIds: ['lex_abenk'],
  lexiconMastery: {},
  settings: {
    soundEffects: true,
    autoPlayAudio: true,
    voiceSpeed: 'normal',
    useGeminiVoice: true,
    hapticFeedback: true,
    speechRecognitionEnabled: true,
    preferredPracticeType: 'balanced',
    difficultyPreference: 'adaptive',
  },
};

export function calculateLevel(xp: number): { level: number; currentLevelXp: number; nextLevelXp: number; progressPercent: number } {
  const thresholds = [0, 100, 250, 500, 850, 1300, 1900, 2600, 3500, 5000];
  let level = 1;
  for (let i = 0; i < thresholds.length; i++) {
    if (xp >= thresholds[i]) {
      level = i + 1;
    } else {
      break;
    }
  }

  const currentBase = thresholds[level - 1] || 0;
  const nextTarget = thresholds[level] || currentBase + 1000;
  const currentLevelXp = xp - currentBase;
  const range = nextTarget - currentBase;
  const progressPercent = Math.min(100, Math.round((currentLevelXp / range) * 100));

  return { level, currentLevelXp, nextLevelXp: range, progressPercent };
}

interface AppContextType {
  user: UserProfile;
  vocabList: VocabularyItem[];
  weakWords: VocabularyItem[];
  mistakes: MistakeLog[];
  activeCourse: typeof BALOCHI_COURSE;
  levelInfo: ReturnType<typeof calculateLevel>;
  lexiconEntries: LexiconEntry[];
  addToLearningQueue: (lexId: string) => void;
  removeFromLearningQueue: (lexId: string) => void;
  toggleBookmarkLexicon: (lexId: string) => void;
  recordLexiconMastery: (lexId: string, isCorrect: boolean) => void;
  getLexiconStatus: (lexId: string) => {
    status: MasteryStatus;
    score: number;
    masteryScore: number;
    mistakeCount: number;
    correctCount: number;
    isBookmarked: boolean;
    isInQueue: boolean;
  };
  setLearningLanguage: (lang: LanguageCode) => void;
  completeLesson: (lessonId: string, earnedXp: number, accuracy: number, learnedWordIds: string[]) => void;
  loseHeart: () => boolean; // returns true if still has hearts
  refillHearts: () => void;
  earnHeart: () => void;
  recordWordMastery: (wordId: string, isCorrect: boolean) => void;
  logMistake: (mistake: Omit<MistakeLog, 'id' | 'timestamp'>) => void;
  clearMistake: (mistakeId: string) => void;
  purchaseShopItem: (item: ShopItem) => { success: boolean; message: string };
  claimAchievement: (achievementId: string) => void;
  updateSettings: (settings: Partial<UserSettings>) => void;
  unlockAllCourseLessons: () => void;
  resetAllProgress: () => void;
  loginWithGoogle: (googleUser?: { name: string; email: string; avatar?: string }) => Promise<void> | void;
  loginWithEmail: (email: string, passwordOrFullName?: string, fullName?: string, mode?: 'signup' | 'login') => Promise<void> | void;
  loginWithPhone: (countryCode: string, phoneNumber: string, fullName?: string) => void;
  logout: () => void;
  vocabularyReviews: Record<string, LearnerVocabularyReview>;
  detailedMistakes: DetailedMistakeRecord[];
  streakFreeze: StreakFreezeRecord;
  smartReviewStats: SmartReviewSummary;
  recordReviewAttempt: (
    lexiconId: string,
    isCorrect: boolean,
    metadata?: {
      exerciseId?: string;
      exerciseType?: string;
      questionPrompt?: string;
      targetWord?: string;
      expectedAnswer?: string;
      learnerAnswer?: string;
      sourceLessonId?: string;
      sourceUnitId?: string;
      difficulty?: 'easy' | 'medium' | 'hard';
    }
  ) => void;
  startSmartReviewSession: (limit?: number) => Exercise[];
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() => {
    let currentUser: UserProfile = DEFAULT_USER;
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved) {
        const parsed = JSON.parse(saved);
        currentUser = {
          ...DEFAULT_USER,
          ...parsed,
          settings: { ...DEFAULT_USER.settings, ...(parsed.settings || {}) },
        };
      }
    } catch (e) {
      console.warn('Failed to load user state from localStorage:', e);
    }

    // Ensure Balochi foundational lessons are unlocked
    const essentialLessons = ['lesson0_1', 'bal_les_1', 'bal_les_2'];
    const mergedUnlocked = Array.from(new Set([...(currentUser.unlockedLessons || []), ...essentialLessons]));
    currentUser.unlockedLessons = mergedUnlocked;

    // The app is dedicated to Balochi (بلوچی)
    currentUser.learningLanguage = 'balochi';

    return currentUser;
  });

  const [vocabMap, setVocabMap] = useState<Record<string, VocabularyItem>>(() => {
    // 1. Pre-populate all vocabulary from all registered courses
    const initial: Record<string, VocabularyItem> = {};
    Object.values(VOCABULARY_MAP).forEach((list) => {
      list.forEach((item) => {
        initial[item.id] = { ...item };
      });
    });

    // 2. Overlay any saved user mastery or mistake counts
    try {
      const saved = localStorage.getItem(STORAGE_KEY_VOCAB);
      if (saved) {
        const parsed = JSON.parse(saved);
        Object.keys(parsed).forEach((k) => {
          if (initial[k]) {
            initial[k].masteryScore = parsed[k].masteryScore || 0;
            initial[k].correctCount = parsed[k].correctCount || 0;
            initial[k].mistakeCount = parsed[k].mistakeCount || 0;
            initial[k].lastPracticed = parsed[k].lastPracticed;
          } else {
            initial[k] = parsed[k];
          }
        });
      }
    } catch (e) {
      console.warn('Failed to merge saved vocabulary:', e);
    }
    return initial;
  });

  const [mistakes, setMistakes] = useState<MistakeLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MISTAKES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const [vocabularyReviews, setVocabularyReviews] = useState<Record<string, LearnerVocabularyReview>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REVIEWS);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }

    // Seed from user.lexiconMastery or user.vocabularyReviews
    if (user.vocabularyReviews && Object.keys(user.vocabularyReviews).length > 0) {
      return { ...user.vocabularyReviews };
    }

    const initialReviews: Record<string, LearnerVocabularyReview> = {};
    const now = Date.now();

    if (user.lexiconMastery && Object.keys(user.lexiconMastery).length > 0) {
      Object.entries(user.lexiconMastery).forEach(([id, m]) => {
        initialReviews[id] = {
          lexiconId: id,
          firstLearnedAt: now - 86400000,
          lastPracticedAt: now - 86400000,
          totalAttempts: m.correctCount + m.mistakeCount,
          correctAttempts: m.correctCount,
          incorrectAttempts: m.mistakeCount,
          consecutiveCorrect: m.mistakeCount === 0 && m.correctCount > 0 ? m.correctCount : 0,
          masteryScore: m.masteryScore,
          masteryStatus: m.status,
          reviewCount: m.correctCount + m.mistakeCount,
          nextReviewAt: now,
          difficulty: 'medium',
          mistakeCount: m.mistakeCount,
        };
      });
    } else {
      // Seed core foundational words as ready for smart review
      const foundationalIds = ['foundational_1', 'foundational_2', 'foundational_3', 'foundational_4', 'foundational_5'];
      foundationalIds.forEach((id, idx) => {
        initialReviews[id] = {
          lexiconId: id,
          firstLearnedAt: now - (idx + 1) * 86400000,
          lastPracticedAt: now - (idx + 1) * 86400000,
          totalAttempts: 1,
          correctAttempts: 1,
          incorrectAttempts: 0,
          consecutiveCorrect: 1,
          masteryScore: 35,
          masteryStatus: 'learning',
          reviewCount: 1,
          nextReviewAt: now - 1000,
          difficulty: 'easy',
          mistakeCount: 0,
          sourceLessonId: 'bal_les_1',
          sourceUnitId: 'bal_u1',
        };
      });
    }

    return initialReviews;
  });

  const [detailedMistakes, setDetailedMistakes] = useState<DetailedMistakeRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DETAILED_MISTAKES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return user.detailedMistakes || [];
  });

  const streakFreeze: StreakFreezeRecord = useMemo(() => {
    return (
      user.streakFreeze || {
        freezeCount: user.streakFreezeCount || 0,
      }
    );
  }, [user.streakFreeze, user.streakFreezeCount]);

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    } catch (e) {
      console.warn('Save user error:', e);
    }
  }, [user]);

  // Listen to Firebase Auth state change and synchronize cloud profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const remoteProfile = await fetchUserProfile(fbUser.uid);
          if (remoteProfile) {
            setUser((prev) => ({
              ...prev,
              ...remoteProfile,
              id: fbUser.uid,
              email: fbUser.email || remoteProfile.email || prev.email,
              username: remoteProfile.username || fbUser.displayName || prev.username,
              fullName: remoteProfile.fullName || fbUser.displayName || prev.fullName,
              isAuthenticated: true,
              authProvider: (remoteProfile.authProvider as any) || (fbUser.providerData[0]?.providerId === 'google.com' ? 'google' : 'email'),
            }));
          } else {
            // Save initial user profile in Firestore
            setUser((prev) => {
              const updated: UserProfile = {
                ...prev,
                id: fbUser.uid,
                email: fbUser.email || prev.email,
                username: fbUser.displayName || prev.username,
                fullName: fbUser.displayName || prev.fullName,
                isAuthenticated: true,
                authProvider: (fbUser.providerData[0]?.providerId === 'google.com' ? 'google' : 'email') as any,
              };
              saveUserProfile(fbUser.uid, updated).catch((err) => {
                console.warn('Initial cloud profile save warning:', err);
              });
              return updated;
            });
          }

          // Fetch user's reviews from Firestore
          const reviews = await fetchVocabularyReviewsFromFirestore(fbUser.uid);
          if (reviews && Object.keys(reviews).length > 0) {
            setVocabularyReviews((prev) => ({ ...prev, ...reviews }));
          }
        } catch (err) {
          console.warn('Error synchronizing with Firestore on auth change:', err);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Debounced auto-save user progress to Firestore for authenticated users
  useEffect(() => {
    if (!user.isAuthenticated || !auth.currentUser) return;
    const uid = auth.currentUser.uid;
    const timer = setTimeout(() => {
      saveUserProfile(uid, user).catch((err) => {
        console.warn('Firestore auto-save sync warning:', err);
      });
    }, 1500);

    return () => clearTimeout(timer);
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_VOCAB, JSON.stringify(vocabMap));
    } catch (e) {
      console.warn('Save vocab error:', e);
    }
  }, [vocabMap]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MISTAKES, JSON.stringify(mistakes));
    } catch (e) {
      console.warn('Save mistakes error:', e);
    }
  }, [mistakes]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REVIEWS, JSON.stringify(vocabularyReviews));
    } catch (e) {
      console.warn('Save reviews error:', e);
    }
  }, [vocabularyReviews]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DETAILED_MISTAKES, JSON.stringify(detailedMistakes));
    } catch (e) {
      console.warn('Save detailed mistakes error:', e);
    }
  }, [detailedMistakes]);

  const activeCourse = useMemo(() => {
    return COURSES_MAP[user.learningLanguage] || BALOCHI_COURSE;
  }, [user.learningLanguage]);

  const vocabList = useMemo(() => {
    return Object.values(vocabMap).filter((v) => v.language === 'balochi' || !v.language);
  }, [vocabMap]);

  const weakWords = useMemo(() => {
    return vocabList.filter((v) => v.mistakeCount > 0 || (v.correctCount > 0 && v.masteryScore < 60));
  }, [vocabList]);

  const levelInfo = useMemo(() => {
    return calculateLevel(user.xp);
  }, [user.xp]);

  const setLearningLanguage = (lang: LanguageCode) => {
    setUser((prev) => ({
      ...prev,
      learningLanguage: lang,
    }));
  };

  const completeLesson = (
    lessonId: string,
    earnedXp: number,
    accuracy: number,
    learnedWordIds: string[]
  ) => {
    setUser((prev) => {
      const newXp = prev.xp + earnedXp;
      const newTodayXp = prev.todayXp + earnedXp;

      // Calculate streak
      const today = new Date().toISOString().split('T')[0];
      const hadActivityToday = prev.lastActivityDate === today;
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

      let newStreak = prev.streak;
      let freezeCount = prev.streakFreeze?.freezeCount ?? prev.streakFreezeCount ?? 0;
      let streakFreezeRecord = prev.streakFreeze || { freezeCount };

      if (!hadActivityToday) {
        if (prev.lastActivityDate === yesterday || prev.streak === 0) {
          newStreak = prev.streak + 1;
        } else {
          // Missed a day: check if streak freeze was available
          if (freezeCount > 0) {
            newStreak = prev.streak + 1;
            freezeCount = Math.max(0, freezeCount - 1);
            streakFreezeRecord = {
              freezeCount,
              freezeUsedAt: today,
              freezeReason: 'Preserved daily streak after missed day',
              freezeEarnedAt: prev.streakFreeze?.freezeEarnedAt,
            };
          } else {
            newStreak = 1;
          }
        }
      }

      const longestStreak = Math.max(prev.longestStreak, newStreak);
      const activeDates = prev.activeDates.includes(today)
        ? prev.activeDates
        : [...prev.activeDates, today];

      // Unlock next lesson in active course sequence
      const allLessons: string[] = [];
      activeCourse.sections.forEach((s) => {
        s.units.forEach((u) => {
          u.lessons.forEach((l) => {
            allLessons.push(l.id);
          });
        });
      });

      const currentIdx = allLessons.indexOf(lessonId);
      const newUnlocked = new Set(prev.unlockedLessons);
      newUnlocked.add(lessonId);
      if (currentIdx >= 0 && currentIdx < allLessons.length - 1) {
        newUnlocked.add(allLessons[currentIdx + 1]);
      }

      const completed = new Set(prev.completedLessons);
      completed.add(lessonId);

      // Gems reward: 15 gems per lesson, +10 for perfect 100%
      const gemBonus = accuracy >= 100 ? 25 : 15;

      return {
        ...prev,
        xp: newXp,
        level: calculateLevel(newXp).level,
        streak: newStreak,
        longestStreak,
        lastActivityDate: today,
        activeDates,
        todayXp: newTodayXp,
        gems: prev.gems + gemBonus,
        streakFreezeCount: freezeCount,
        streakFreeze: streakFreezeRecord,
        unlockedLessons: Array.from(newUnlocked),
        completedLessons: Array.from(completed),
      };
    });

    // Update mastery on learned words
    learnedWordIds.forEach((wordId) => {
      recordWordMastery(wordId, true);
      recordReviewAttempt(wordId, true, { sourceLessonId: lessonId });
    });

    playSoundEffect('complete', user.settings.soundEffects);
  };

  const loseHeart = (): boolean => {
    let stillHasHearts = false;
    setUser((prev) => {
      const remaining = Math.max(0, prev.hearts - 1);
      stillHasHearts = remaining > 0;
      return {
        ...prev,
        hearts: remaining,
      };
    });
    playSoundEffect('heart_lost', user.settings.soundEffects);
    return stillHasHearts;
  };

  const refillHearts = () => {
    setUser((prev) => ({
      ...prev,
      hearts: prev.maxHearts,
    }));
  };

  const earnHeart = () => {
    setUser((prev) => ({
      ...prev,
      hearts: Math.min(prev.maxHearts, prev.hearts + 1),
    }));
  };

  const recordWordMastery = (wordId: string, isCorrect: boolean) => {
    setVocabMap((prev) => {
      const existing = prev[wordId];
      if (!existing) return prev;

      const delta = isCorrect ? 25 : -15;
      const newScore = Math.max(0, Math.min(100, (existing.masteryScore || 0) + delta));

      return {
        ...prev,
        [wordId]: {
          ...existing,
          masteryScore: newScore,
          correctCount: existing.correctCount + (isCorrect ? 1 : 0),
          mistakeCount: existing.mistakeCount + (isCorrect ? 0 : 1),
          lastPracticed: new Date().toISOString(),
        },
      };
    });
  };

  const logMistake = (mistake: Omit<MistakeLog, 'id' | 'timestamp'>) => {
    const newEntry: MistakeLog = {
      ...mistake,
      id: `mistake_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
    };
    setMistakes((prev) => [newEntry, ...prev.slice(0, 49)]); // keep recent 50
  };

  const clearMistake = (mistakeId: string) => {
    setMistakes((prev) => prev.filter((m) => m.id !== mistakeId));
  };

  const purchaseShopItem = (item: ShopItem): { success: boolean; message: string } => {
    if (user.gems < item.costGems) {
      return { success: false, message: `Need ${item.costGems - user.gems} more gems to purchase this item.` };
    }

    if (item.category === 'hearts') {
      if (user.hearts >= user.maxHearts) {
        return { success: false, message: 'Your hearts are already full!' };
      }
      setUser((prev) => ({
        ...prev,
        gems: prev.gems - item.costGems,
        hearts: prev.maxHearts,
      }));
      playSoundEffect('correct', user.settings.soundEffects);
      return { success: true, message: 'All hearts restored to maximum (5/5)!' };
    }

    if (item.category === 'streak') {
      const updatedFreezes = (user.streakFreezeCount || 0) + 1;
      const updatedFreezeRecord: StreakFreezeRecord = {
        freezeCount: updatedFreezes,
        freezeEarnedAt: new Date().toISOString(),
        freezeReason: 'Purchased Streak Freeze',
      };
      setUser((prev) => ({
        ...prev,
        gems: prev.gems - item.costGems,
        streakFreezeCount: updatedFreezes,
        streakFreeze: updatedFreezeRecord,
      }));
      playSoundEffect('streak', user.settings.soundEffects);
      return { success: true, message: 'Streak Freeze equipped! You are protected for 1 missed day.' };
    }

    if (item.category === 'unlock') {
      unlockAllCourseLessons();
      setUser((prev) => ({
        ...prev,
        gems: prev.gems - item.costGems,
      }));
      playSoundEffect('complete', user.settings.soundEffects);
      return { success: true, message: 'All lessons unlocked across the course!' };
    }

    if (item.category === 'boost') {
      setUser((prev) => ({
        ...prev,
        gems: prev.gems - item.costGems,
      }));
      playSoundEffect('streak', user.settings.soundEffects);
      return { success: true, message: 'Double XP Boost activated! Earn double XP on lessons.' };
    }

    return { success: false, message: 'Unknown item.' };
  };

  const claimAchievement = (achievementId: string) => {
    const ach = INITIAL_ACHIEVEMENTS.find((a) => a.id === achievementId);
    if (!ach || user.claimedAchievements.includes(achievementId)) return;

    setUser((prev) => ({
      ...prev,
      gems: prev.gems + ach.gemReward,
      claimedAchievements: [...prev.claimedAchievements, achievementId],
    }));

    playSoundEffect('complete', user.settings.soundEffects);
  };

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setUser((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings },
    }));
  };

  const unlockAllCourseLessons = () => {
    const allLessonIds: string[] = [];
    activeCourse.sections.forEach((s) => {
      s.units.forEach((u) => {
        u.lessons.forEach((l) => {
          allLessonIds.push(l.id);
        });
      });
    });

    setUser((prev) => ({
      ...prev,
      unlockedLessons: Array.from(new Set([...prev.unlockedLessons, ...allLessonIds])),
    }));
  };

  const addToLearningQueue = (lexId: string) => {
    setUser((prev) => {
      const queue = prev.learningQueueLexiconIds || [];
      if (queue.includes(lexId)) return prev;
      const updatedQueue = [...queue, lexId];
      const prevMastery = prev.lexiconMastery?.[lexId];
      return {
        ...prev,
        learningQueueLexiconIds: updatedQueue,
        lexiconMastery: {
          ...(prev.lexiconMastery || {}),
          [lexId]: prevMastery || {
            masteryScore: 10,
            status: 'learning',
            mistakeCount: 0,
            correctCount: 0,
          },
        },
      };
    });
    playSoundEffect('correct', user.settings.soundEffects);
  };

  const removeFromLearningQueue = (lexId: string) => {
    setUser((prev) => ({
      ...prev,
      learningQueueLexiconIds: (prev.learningQueueLexiconIds || []).filter(
        (id) => id !== lexId
      ),
    }));
  };

  const toggleBookmarkLexicon = (lexId: string) => {
    setUser((prev) => {
      const bks = prev.bookmarkedLexiconIds || [];
      const updated = bks.includes(lexId)
        ? bks.filter((id) => id !== lexId)
        : [...bks, lexId];
      return { ...prev, bookmarkedLexiconIds: updated };
    });
  };

  const recordReviewAttempt = (
    lexiconId: string,
    isCorrect: boolean,
    metadata?: {
      exerciseId?: string;
      exerciseType?: string;
      questionPrompt?: string;
      targetWord?: string;
      expectedAnswer?: string;
      learnerAnswer?: string;
      sourceLessonId?: string;
      sourceUnitId?: string;
      difficulty?: 'easy' | 'medium' | 'hard';
    }
  ) => {
    const now = Date.now();

    setVocabularyReviews((prev) => {
      const updated = updateVocabularyReview(prev[lexiconId], isCorrect, {
        lexiconId,
        now,
        sourceLessonId: metadata?.sourceLessonId,
        sourceUnitId: metadata?.sourceUnitId,
        difficulty: metadata?.difficulty,
      });

      const nextReviews = { ...prev, [lexiconId]: updated };

      setUser((u) => ({
        ...u,
        vocabularyReviews: nextReviews,
        lexiconMastery: {
          ...(u.lexiconMastery || {}),
          [lexiconId]: {
            masteryScore: updated.masteryScore,
            status: updated.masteryStatus,
            correctCount: updated.correctAttempts,
            mistakeCount: updated.mistakeCount,
          },
        },
      }));

      return nextReviews;
    });

    if (!isCorrect && metadata) {
      const category = determineMistakeCategory(
        {
          type: metadata.exerciseType,
          prompt: metadata.questionPrompt,
          targetText: metadata.targetWord,
          correctAnswer: metadata.expectedAnswer,
        },
        metadata.learnerAnswer
      );

      const detailedRecord: DetailedMistakeRecord = {
        id: `dm_${now}_${Math.random().toString(36).slice(2, 6)}`,
        lexiconId,
        exerciseId: metadata.exerciseId || `ex_${now}`,
        exerciseType: metadata.exerciseType || 'quiz',
        timestamp: now,
        expectedAnswer: metadata.expectedAnswer || '',
        learnerAnswer: metadata.learnerAnswer,
        mistakeCategory: category,
      };

      setDetailedMistakes((prev) => [detailedRecord, ...prev.slice(0, 99)]);
      setUser((u) => ({
        ...u,
        detailedMistakes: [detailedRecord, ...(u.detailedMistakes || []).slice(0, 99)],
      }));
    }
  };

  const recordLexiconMastery = (lexId: string, isCorrect: boolean) => {
    recordReviewAttempt(lexId, isCorrect);
  };

  const getLexiconStatus = (lexId: string) => {
    const queue = user.learningQueueLexiconIds || [];
    const bks = user.bookmarkedLexiconIds || [];
    const rev = vocabularyReviews[lexId];
    const record = user.lexiconMastery?.[lexId];

    const status = rev?.masteryStatus || record?.status || (queue.includes(lexId) ? 'learning' : 'new');
    const score = rev?.masteryScore ?? record?.masteryScore ?? 0;
    const mistakeCount = rev?.mistakeCount ?? record?.mistakeCount ?? 0;
    const correctCount = rev?.correctAttempts ?? record?.correctCount ?? 0;

    return {
      status,
      score,
      masteryScore: score,
      mistakeCount,
      correctCount,
      isBookmarked: bks.includes(lexId),
      isInQueue: queue.includes(lexId),
    };
  };

  const smartReviewStats: SmartReviewSummary = useMemo(() => {
    const now = Date.now();
    const reviews = Object.values(vocabularyReviews);
    let dueCount = 0;
    let mistakeCount = 0;
    let weakCount = 0;
    let masteredCount = 0;

    reviews.forEach((r) => {
      if (r.nextReviewAt <= now) dueCount++;
      if (r.mistakeCount > 0 && !hasRecoveredFromMistakes(r)) mistakeCount++;
      if (r.masteryStatus === 'weak' || r.masteryScore < 50) weakCount++;
      if (r.masteryStatus === 'mastered') masteredCount++;
    });

    if (dueCount === 0 && user.learningQueueLexiconIds && user.learningQueueLexiconIds.length > 0) {
      dueCount = user.learningQueueLexiconIds.length;
    }

    return {
      dueCount,
      mistakeCount,
      weakCount,
      masteredCount,
      totalTracked: reviews.length,
    };
  }, [vocabularyReviews, user.learningQueueLexiconIds]);

  const startSmartReviewSession = (limit = 6): Exercise[] => {
    const selected = selectSmartReviewBatch(
      vocabularyReviews,
      BALOCHI_LEXICON,
      user.learningQueueLexiconIds || [],
      limit
    );
    return generateSmartReviewExercises(selected, BALOCHI_LEXICON);
  };

  const loginWithGoogle = async (googleUser?: { name: string; email: string; avatar?: string }) => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      const fbUser = res.user;
      setUser((prev) => ({
        ...prev,
        id: fbUser.uid,
        isAuthenticated: true,
        authProvider: 'google',
        username: fbUser.displayName || googleUser?.name || prev.username,
        fullName: fbUser.displayName || googleUser?.name || prev.username,
        email: fbUser.email || googleUser?.email || prev.email,
        avatarSeed: (fbUser.displayName || fbUser.email || 'user').toLowerCase().replace(/\s+/g, '_'),
      }));
      playSoundEffect('correct', user.settings.soundEffects);
    } catch (err: any) {
      if (err.code !== 'auth/popup-closed-by-user') {
        console.error('Firebase Google Sign-In Error:', err);
      }
      throw err;
    }
  };

  const loginWithEmail = async (
    email: string,
    passwordOrFullName?: string,
    fullName?: string,
    mode: 'signup' | 'login' = 'signup'
  ) => {
    try {
      let fbUser: any = null;
      if (passwordOrFullName && passwordOrFullName.length >= 6) {
        if (mode === 'signup') {
          const res = await createUserWithEmailAndPassword(auth, email.trim(), passwordOrFullName);
          fbUser = res.user;
        } else {
          const res = await signInWithEmailAndPassword(auth, email.trim(), passwordOrFullName);
          fbUser = res.user;
        }
      }

      const displayName = fullName || fbUser?.displayName || email.split('@')[0];
      setUser((prev) => ({
        ...prev,
        id: fbUser ? fbUser.uid : prev.id,
        isAuthenticated: true,
        authProvider: 'email',
        email,
        username: displayName,
        fullName: displayName,
        avatarSeed: displayName.toLowerCase().replace(/\s+/g, '_'),
      }));
      playSoundEffect('correct', user.settings.soundEffects);
    } catch (err) {
      console.error('Firebase Email Auth Error:', err);
      throw err;
    }
  };

  const loginWithPhone = (countryCode: string, phoneNumber: string, fullName?: string) => {
    setUser((prev) => {
      const name = fullName || `User ${phoneNumber.slice(-4)}`;
      return {
        ...prev,
        isAuthenticated: true,
        authProvider: 'phone',
        countryCode,
        phoneNumber,
        username: name,
        fullName: name,
        avatarSeed: name.toLowerCase().replace(/\s+/g, '_'),
      };
    });
    playSoundEffect('correct', user.settings.soundEffects);
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Sign out warning:', e);
    }
    setUser((prev) => ({
      ...prev,
      isAuthenticated: false,
      authProvider: 'guest',
    }));
  };

  const resetAllProgress = () => {
    localStorage.removeItem(STORAGE_KEY_USER);
    localStorage.removeItem(STORAGE_KEY_VOCAB);
    localStorage.removeItem(STORAGE_KEY_MISTAKES);
    localStorage.removeItem(STORAGE_KEY_REVIEWS);
    localStorage.removeItem(STORAGE_KEY_DETAILED_MISTAKES);
    setUser(DEFAULT_USER);
    setMistakes([]);
    setVocabularyReviews({});
    setDetailedMistakes([]);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        vocabList,
        weakWords,
        mistakes,
        activeCourse,
        levelInfo,
        lexiconEntries: BALOCHI_LEXICON,
        vocabularyReviews,
        detailedMistakes,
        streakFreeze,
        smartReviewStats,
        recordReviewAttempt,
        startSmartReviewSession,
        addToLearningQueue,
        removeFromLearningQueue,
        toggleBookmarkLexicon,
        recordLexiconMastery,
        getLexiconStatus,
        setLearningLanguage,
        completeLesson,
        loseHeart,
        refillHearts,
        earnHeart,
        recordWordMastery,
        logMistake,
        clearMistake,
        purchaseShopItem,
        claimAchievement,
        updateSettings,
        unlockAllCourseLessons,
        resetAllProgress,
        loginWithGoogle,
        loginWithEmail,
        loginWithPhone,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
