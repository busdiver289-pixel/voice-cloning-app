import { LexiconEntry } from '../../types/lexicon';
import { LABZBALAD_ENTRIES } from './labzbaladEntries';

const FOUNDATIONAL_LEXICON: LexiconEntry[] = [
  // --- Linguistic Source Material Specified in Brief ---
  {
    id: 'lex_abnak',
    arabic: 'آبنَاک',
    latin: 'ábnák',
    headword: 'آبنَاک',
    partOfSpeech: 'adj',
    domain: 'general',
    definitions: [
      {
        id: 'def_abnak_1',
        english: 'full of water',
        urdu: 'پانی سے بھرا ہوا',
      },
      {
        id: 'def_abnak_2',
        english: 'dignified; gracious; honourable',
        urdu: 'باعزت، باوقار',
      },
      {
        id: 'def_abnak_3',
        english: 'wealthy; prosperous',
        urdu: 'خوشحال، دولت مند',
        domain: 'economics',
      },
    ],
    examples: [
      {
        arabic: 'اے ڈگار آبناک اِنت',
        latin: 'E dagaar ábnák ent',
        english: 'This land is well-watered / prosperous',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_aband',
    arabic: 'آبَند',
    latin: 'áband',
    headword: 'آبَند',
    partOfSpeech: 'n',
    definitions: [
      {
        id: 'def_aband_1',
        english: 'dam; dyke',
        domain: 'agriculture',
        urdu: 'بند، ڈیم',
      },
      {
        id: 'def_aband_2',
        english: 'region; zone',
        domain: 'geography',
        urdu: 'علاقہ، خطہ',
      },
    ],
    examples: [
      {
        arabic: 'آپ آبند ءِ تہا اِنت',
        latin: 'Áp áband e taha ent',
        english: 'The water is in the dam',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_abnus',
    arabic: 'آبنوس',
    latin: 'ábnus',
    headword: 'آبنوس',
    partOfSpeech: 'n',
    domain: 'botany',
    definitions: [
      {
        id: 'def_abnus_1',
        english: 'ebony',
        scientificName: 'Diospyros ebenum',
        urdu: 'آبنوس (سیاہ وزنی لکڑی)',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abnusi',
    arabic: 'آبنوسی',
    latin: 'ábnusi',
    headword: 'آبنوسی',
    partOfSpeech: 'adj',
    domain: 'botany',
    definitions: [
      {
        id: 'def_abnusi_1',
        english: 'ebony; made of ebony; like ebony; hard or black like ebony',
        urdu: 'آبنوس کا بنا ہوا، سیاہ اور سخت',
      },
    ],
    crossReferences: [
      {
        type: 'derived_from',
        arabic: 'آبنوس',
        latin: 'ábnus',
        refId: 'lex_abnus',
        note: 'Derived from ábnus (ebony)',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abu',
    arabic: 'آبو',
    latin: 'ábu',
    headword: 'آبو',
    partOfSpeech: 'n',
    domain: 'general',
    definitions: [
      {
        id: 'def_abu_1',
        english: 'water lily; lotus; aquatic flower (variant)',
        urdu: 'نیلوفر، آبی پھول',
      },
    ],
    variants: [
      {
        arabic: 'آبۆ',
        latin: 'ábó',
        refId: 'lex_abo',
        type: 'variant_of',
      },
    ],
    crossReferences: [
      {
        type: 'variant_of',
        arabic: 'آبۆ',
        latin: 'ábó',
        refId: 'lex_abo',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abo',
    arabic: 'آبۆ',
    latin: 'ábó',
    headword: 'آبۆ',
    partOfSpeech: 'n',
    domain: 'botany',
    definitions: [
      {
        id: 'def_abo_1',
        english: 'water lily; aquatic plant; lotus',
        urdu: 'نیلوفر، کنول',
      },
    ],
    variants: [
      {
        arabic: 'آبو',
        latin: 'ábu',
        refId: 'lex_abu',
        type: 'variant_of',
      },
    ],
    crossReferences: [
      {
        type: 'variant_of',
        arabic: 'آبو',
        latin: 'ábu',
        refId: 'lex_abu',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abwar',
    arabic: 'آبوار',
    latin: 'ábwár',
    headword: 'آبوار',
    partOfSpeech: 'adj',
    domain: 'agriculture',
    definitions: [
      {
        id: 'def_abwar_1',
        english: 'water-turn; irrigation schedule; watered crop',
        urdu: 'پانی کی باری، سیرابی',
      },
    ],
    variants: [
      {
        arabic: 'آپوار',
        latin: 'ápwár',
        refId: 'lex_apwar',
        type: 'variant_of',
      },
    ],
    crossReferences: [
      {
        type: 'variant_of',
        arabic: 'آپوار',
        latin: 'ápwár',
        refId: 'lex_apwar',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_apwar',
    arabic: 'آپوار',
    latin: 'ápwár',
    headword: 'آپوار',
    partOfSpeech: 'adj',
    domain: 'agriculture',
    definitions: [
      {
        id: 'def_apwar_1',
        english: 'water-turn; irrigation schedule; irrigated parcel',
        urdu: 'پانی کی باری',
      },
    ],
    variants: [
      {
        arabic: 'آبوار',
        latin: 'ábwár',
        refId: 'lex_abwar',
        type: 'variant_of',
      },
    ],
    crossReferences: [
      {
        type: 'variant_of',
        arabic: 'آبوار',
        latin: 'ábwár',
        refId: 'lex_abwar',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_abenk',
    arabic: 'آبێنک',
    latin: 'ábénk',
    headword: 'آبێنک',
    partOfSpeech: 'n',
    domain: 'linguistics',
    definitions: [
      {
        id: 'def_abenk_1',
        english: 'alphabet',
        urdu: 'حروفِ تہجی',
      },
    ],
    synonyms: [
      {
        arabic: 'اَلِپبے',
        latin: 'alepbé',
        refId: 'lex_alepbe',
        type: 'synonym_of',
      },
    ],
    crossReferences: [
      {
        type: 'related_to',
        arabic: 'آبێنکار',
        latin: 'ábénkár',
        refId: 'lex_abenkar',
      },
      {
        type: 'related_to',
        arabic: 'آبێنکزانت',
        latin: 'ábénkzánt',
        refId: 'lex_abenkzant',
      },
    ],
    examples: [
      {
        arabic: 'بلوچی آبێنک ماں دَربَر جاہ ءَ دَربَرگ بیت',
        latin: 'Balochi ábénk mán Darbarjah a darbarag bayt',
        english: 'The Balochi alphabet is learned in the academy / school',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_alepbe',
    arabic: 'اَلِپبے',
    latin: 'alepbé',
    headword: 'اَلِپبے',
    partOfSpeech: 'n',
    domain: 'linguistics',
    definitions: [
      {
        id: 'def_alepbe_1',
        english: 'alphabet; ABCs',
        urdu: 'الف بے، حروفِ تہجی',
      },
    ],
    synonyms: [
      {
        arabic: 'آبێنک',
        latin: 'ábénk',
        refId: 'lex_abenk',
        type: 'synonym_of',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_abenkar',
    arabic: 'آبێنکار',
    latin: 'ábénkár',
    headword: 'آبێنکار',
    partOfSpeech: 'n',
    domain: 'linguistics',
    definitions: [
      {
        id: 'def_abenkar_1',
        english: 'alphabetist; one that studies or invents alphabets',
        urdu: 'حروف شناس، ماہرِ حروفِ تہجی',
      },
    ],
    crossReferences: [
      {
        type: 'derived_from',
        arabic: 'آبێنک',
        latin: 'ábénk',
        refId: 'lex_abenk',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abenkari',
    arabic: 'آبێنکاری',
    latin: 'ábénkári',
    headword: 'آبێنکاری',
    partOfSpeech: 'n',
    domain: 'linguistics',
    definitions: [
      {
        id: 'def_abenkari_1',
        english: 'alphabetism; the use of letters as symbols',
        urdu: 'حروف نگاری، علامتی استعمال',
      },
    ],
    crossReferences: [
      {
        type: 'derived_from',
        arabic: 'آبێنکار',
        latin: 'ábénkár',
        refId: 'lex_abenkar',
      },
    ],
    frequency: 'low',
  },
  {
    id: 'lex_abenkzant',
    arabic: 'آبێنکزانت',
    latin: 'ábénkzánt',
    headword: 'آبێنکزانت',
    partOfSpeech: 'n',
    domain: 'linguistics',
    definitions: [
      {
        id: 'def_abenkzant_1',
        english: 'alphabetologist; one that studies the alphabetic systems of writing',
        urdu: 'ماہرِ نظام ہائے رسم الخط',
      },
    ],
    crossReferences: [
      {
        type: 'derived_from',
        arabic: 'آبێنک',
        latin: 'ábénk',
        refId: 'lex_abenk',
      },
    ],
    frequency: 'low',
  },

  // --- Foundational Balochi Core Entries Linked with Learning Engine ---
  {
    id: 'lex_salaam',
    arabic: 'سلام',
    latin: 'Salaam',
    headword: 'سلام',
    partOfSpeech: 'interj',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_salaam_1',
        english: 'Hello; hi; peace be upon you',
        urdu: 'سلام، آداب',
      },
      {
        id: 'def_salaam_2',
        english: 'peace; safety',
        urdu: 'امن و سلامتی',
      },
    ],
    examples: [
      {
        arabic: 'سلام سَنگت',
        latin: 'Salaam Sangat',
        english: 'Hello Friend',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_wash_aatke',
    arabic: 'وَش آتکے',
    latin: 'Washh Aatke',
    headword: 'وَش آتکے',
    partOfSpeech: 'phrase',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_washaatke_1',
        english: 'Welcome; you are pleasantly arrived',
        urdu: 'خوش آمدید',
      },
    ],
    examples: [
      {
        arabic: 'شما وش آتکے',
        latin: 'Shuma washh aatke',
        english: 'You are welcome',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_suhb_wassh_baat',
    arabic: 'سُھب وَش بات',
    latin: 'Suhb Wassh Baat',
    headword: 'سُھب وَش بات',
    partOfSpeech: 'phrase',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_suhb_1',
        english: 'Good morning; may your morning be blessed and pleasant',
        urdu: 'صبح بخیر',
      },
    ],
    examples: [
      {
        arabic: 'سُھب وَش بات، واجہ',
        latin: 'Suhb wassh baat, waja',
        english: 'Good morning, respected sir',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_shap_wassh_baat',
    arabic: 'شَپ وَش بات',
    latin: 'Shap wassh baat',
    headword: 'شَپ وَش بات',
    partOfSpeech: 'phrase',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_shap_1',
        english: 'Good night; may your night be peaceful',
        urdu: 'شب بخیر',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_huda_hapiz',
    arabic: 'ھُدا ھاپز',
    latin: 'Huda hapiz',
    headword: 'ھُدا ھاپز',
    partOfSpeech: 'phrase',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_hudahapiz_1',
        english: 'Good bye; farewell; God protect you',
        urdu: 'خدا حافظ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_minntwar',
    arabic: 'مِنتوار',
    latin: 'Minntwar',
    headword: 'مِنتوار',
    partOfSpeech: 'adj',
    domain: 'greeting',
    definitions: [
      {
        id: 'def_minntwar_1',
        english: 'Thank you; obliged; grateful',
        urdu: 'شکریہ، ممنون',
      },
    ],
    examples: [
      {
        arabic: 'باز مِنتوار واجہ',
        latin: 'Baz minntwar waja',
        english: 'Thank you very much sir',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_sangat',
    arabic: 'سَنگت',
    latin: 'Sangat',
    headword: 'سَنگت',
    partOfSpeech: 'n',
    domain: 'social',
    definitions: [
      {
        id: 'def_sangat_1',
        english: 'friend; comrade; companion',
        urdu: 'دوست، ساتھی',
      },
    ],
    examples: [
      {
        arabic: 'آ منی سَنگت اِنت',
        latin: 'Aa mani sangat ent',
        english: 'He/she is my friend',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_ap',
    arabic: 'آپ',
    latin: 'Áp',
    headword: 'آپ',
    partOfSpeech: 'n',
    domain: 'nature',
    definitions: [
      {
        id: 'def_ap_1',
        english: 'water; fresh liquid',
        urdu: 'پانی',
      },
    ],
    variants: [
      {
        arabic: 'آب',
        latin: 'áb',
        type: 'variant_of',
      },
    ],
    examples: [
      {
        arabic: 'من ءَ آپ پکار اِنت',
        latin: 'Man a áp pakár ent',
        english: 'I need water',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_cham',
    arabic: 'چَمّ',
    latin: 'Cham',
    headword: 'چَمّ',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_cham_1',
        english: 'eye; eyes',
        urdu: 'آنکھ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_sar',
    arabic: 'سر',
    latin: 'Sar',
    headword: 'سر',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_sar_1',
        english: 'head',
        urdu: 'سر',
      },
      {
        id: 'def_sar_2',
        english: 'top; beginning; chieftain',
        urdu: 'اوپر، آغاز',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_meed',
    arabic: 'مید',
    latin: 'Meed',
    headword: 'مید',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_meed_1',
        english: 'hair (of the head)',
        urdu: 'بال',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_dap',
    arabic: 'دَپ',
    latin: 'Dap',
    headword: 'دَپ',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_dap_1',
        english: 'mouth',
        urdu: 'منہ',
      },
      {
        id: 'def_dap_2',
        english: 'entrance; gate; opening',
        urdu: 'دروازہ، دہانہ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_ponz',
    arabic: 'پونز',
    latin: 'Ponz',
    headword: 'پونز',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_ponz_1',
        english: 'nose',
        urdu: 'ناک',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_dast',
    arabic: 'دَست',
    latin: 'Dast',
    headword: 'دَست',
    partOfSpeech: 'n',
    domain: 'anatomy',
    definitions: [
      {
        id: 'def_dast_1',
        english: 'hand; arm',
        urdu: 'ہاتھ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_pas',
    arabic: 'پَس',
    latin: 'Pas',
    headword: 'پَس',
    partOfSpeech: 'n',
    domain: 'zoology',
    definitions: [
      {
        id: 'def_pas_1',
        english: 'goat; sheep; small livestock',
        urdu: 'بکری، بھیڑ',
      },
    ],
    examples: [
      {
        arabic: 'منی پَس آودا نیا',
        latin: 'Mani pas aaoda naya',
        english: 'My goat was not there',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_poshi',
    arabic: 'پُشی',
    latin: 'Poshi',
    headword: 'پُشی',
    partOfSpeech: 'n',
    domain: 'zoology',
    definitions: [
      {
        id: 'def_poshi_1',
        english: 'cat; kitten',
        urdu: 'بلی',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_log',
    arabic: 'لوگ',
    latin: 'Log',
    headword: 'لوگ',
    partOfSpeech: 'n',
    domain: 'general',
    definitions: [
      {
        id: 'def_log_1',
        english: 'house; home; residence',
        urdu: 'گھر، مکان',
      },
      {
        id: 'def_log_2',
        english: 'family; household',
        urdu: 'خاندان، گھرانہ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_maat',
    arabic: 'مات',
    latin: 'Maat',
    headword: 'مات',
    partOfSpeech: 'n',
    domain: 'family',
    definitions: [
      {
        id: 'def_maat_1',
        english: 'mother',
        urdu: 'ماں، والدہ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_pit',
    arabic: 'پِت',
    latin: 'Pit',
    headword: 'پِت',
    partOfSpeech: 'n',
    domain: 'family',
    definitions: [
      {
        id: 'def_pit_1',
        english: 'father',
        urdu: 'باپ، والد',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_braas',
    arabic: 'براس',
    latin: 'Braas',
    headword: 'براس',
    partOfSpeech: 'n',
    domain: 'family',
    definitions: [
      {
        id: 'def_braas_1',
        english: 'brother',
        urdu: 'بھائی',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_gwahar',
    arabic: 'گوھار',
    latin: 'Gwahar',
    headword: 'گوھار',
    partOfSpeech: 'n',
    domain: 'family',
    definitions: [
      {
        id: 'def_gwahar_1',
        english: 'sister',
        urdu: 'بہن',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_roch',
    arabic: 'روچ',
    latin: 'Roch',
    headword: 'روچ',
    partOfSpeech: 'n',
    domain: 'astronomy',
    definitions: [
      {
        id: 'def_roch_1',
        english: 'sun',
        urdu: 'سورج',
      },
      {
        id: 'def_roch_2',
        english: 'day (24-hour period or daylight)',
        urdu: 'دن',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_mahkaan',
    arabic: 'ماہکان',
    latin: 'Mahkaan',
    headword: 'ماہکان',
    partOfSpeech: 'n',
    domain: 'astronomy',
    definitions: [
      {
        id: 'def_mahkaan_1',
        english: 'moonlight; moonlit night',
        urdu: 'چاندنی، چاند کی روشنی',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_dagaar',
    arabic: 'ڈگار',
    latin: 'Dagaar',
    headword: 'ڈگار',
    partOfSpeech: 'n',
    domain: 'agriculture',
    definitions: [
      {
        id: 'def_dagaar_1',
        english: 'cultivated land; agricultural field; soil',
        urdu: 'زمین، کھیت',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_koh',
    arabic: 'کوہ',
    latin: 'Koh',
    headword: 'کوہ',
    partOfSpeech: 'n',
    domain: 'geography',
    definitions: [
      {
        id: 'def_koh_1',
        english: 'mountain; hill',
        urdu: 'پہاڑ',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_zar_money',
    arabic: 'زَر',
    latin: 'Zar',
    headword: 'زَر',
    partOfSpeech: 'n',
    domain: 'economics',
    definitions: [
      {
        id: 'def_zar_1',
        english: 'money; wealth; currency',
        urdu: 'زر، روپیہ، دولت',
      },
      {
        id: 'def_zar_2',
        english: 'gold',
        urdu: 'سونا',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_zir_sea',
    arabic: 'زِر',
    latin: 'Zir',
    headword: 'زِر',
    partOfSpeech: 'n',
    domain: 'nautical',
    definitions: [
      {
        id: 'def_zir_1',
        english: 'sea; ocean',
        urdu: 'سمندر',
      },
    ],
    examples: [
      {
        arabic: 'ما زِر ءِ تہا رؤگ اِنت',
        latin: 'Ma zir e taha rawag ent',
        english: 'We are going into the sea',
      },
    ],
    frequency: 'high',
  },
  {
    id: 'lex_roch_tik',
    arabic: 'روچتک',
    latin: 'Roch-tik',
    headword: 'روچتک',
    partOfSpeech: 'n',
    domain: 'geography',
    definitions: [
      {
        id: 'def_rochtik_1',
        english: 'east; orient; sunrise direction',
        urdu: 'مشرق، جہاں سے سورج نکلتا ہے',
      },
    ],
    frequency: 'medium',
  },
  {
    id: 'lex_roch_zarti',
    arabic: 'روچزرتی',
    latin: 'Roch-zarti',
    headword: 'روچزرتی',
    partOfSpeech: 'n',
    domain: 'geography',
    definitions: [
      {
        id: 'def_rochzarti_1',
        english: 'west; sunset direction; occident',
        urdu: 'مغرب، جہاں سورج غروب ہوتا ہے',
      },
    ],
    frequency: 'medium',
  },
];

export const BALOCHI_LEXICON: LexiconEntry[] = [
  ...FOUNDATIONAL_LEXICON.map((e) => ({
    ...e,
    audio: e.audio || { type: 'unavailable' as const },
    status: (e.status || 'canonical') as 'canonical',
  })),
  ...LABZBALAD_ENTRIES,
];
