/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { CoursePath } from './components/CoursePath';
import { PracticeHub } from './components/PracticeHub';
import { VocabularyBook } from './components/VocabularyBook';
import { AITutorModal } from './components/AITutorModal';
import { ShopModal } from './components/ShopModal';
import { ProfileView } from './components/ProfileView';
import { LessonModal } from './components/LessonModal';
import { LanguageSelectorModal } from './components/LanguageSelectorModal';
import { AuthModal } from './components/AuthModal';
import AuthScreen from './components/AuthScreen';
import { ShareModal } from './components/ShareModal';
import { Lesson, Exercise } from './types';

function MainApp() {
  const { user } = useApp();
  const [currentTab, setCurrentTab] = useState<
    'learn' | 'practice' | 'vocabulary' | 'tutor' | 'shop' | 'profile'
  >('learn');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [showAuthScreen, setShowAuthScreen] = useState(false);

  // Auto-prompt registration on app opening for new/guest visitors
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(() => {
    try {
      const alreadyPrompted = sessionStorage.getItem('darbarjah_auth_prompted');
      return !user.isAuthenticated && !alreadyPrompted;
    } catch {
      return !user.isAuthenticated;
    }
  });

  // Custom drill launcher for practice hub
  const handleStartCustomExercise = (exercises: Exercise[], title: string) => {
    const customLesson: Lesson = {
      id: `custom_drill_${Date.now()}`,
      unitId: 'practice_hub',
      title,
      description: 'Adaptive personalized review workout',
      iconName: 'zap',
      xpReward: 15,
      exercises,
      targetWordIds: [],
    };
    setActiveLesson(customLesson);
  };

  const handleCloseAuth = () => {
    setIsAuthModalOpen(false);
    try {
      sessionStorage.setItem('darbarjah_auth_prompted', 'true');
    } catch {
      // ignore
    }
  };

  if (showAuthScreen) {
    return (
      <AuthScreen
        onAuthed={() => setShowAuthScreen(false)}
        onSkip={() => setShowAuthScreen(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Strict 3-zone Top Bar Contract */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenLanguageSelector={() => setIsLangModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {currentTab === 'learn' && (
          <CoursePath
            onStartLesson={(lesson) => setActiveLesson(lesson)}
            onOpenPractice={() => setCurrentTab('practice')}
            onOpenVocab={() => setCurrentTab('vocabulary')}
            onStartCustomExercise={handleStartCustomExercise}
            onOpenShareModal={() => setIsShareModalOpen(true)}
          />
        )}

        {currentTab === 'practice' && (
          <PracticeHub onStartCustomExercise={handleStartCustomExercise} />
        )}

        {currentTab === 'vocabulary' && (
          <VocabularyBook onStartCustomExercise={handleStartCustomExercise} />
        )}

        {currentTab === 'tutor' && <AITutorModal />}

        {currentTab === 'shop' && <ShopModal />}

        {currentTab === 'profile' && (
          <ProfileView
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenShareModal={() => setIsShareModalOpen(true)}
          />
        )}
      </main>

      {/* Language Selector Modal */}
      <LanguageSelectorModal
        isOpen={isLangModalOpen}
        onClose={() => setIsLangModalOpen(false)}
      />

      {/* Registration & Sign Up Modal on Opening */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={handleCloseAuth}
        onOpenFullscreenAuth={() => setShowAuthScreen(true)}
      />

      {/* Share Darbarjah Modal with Link */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Active Running Lesson Engine */}
      {activeLesson && (
        <LessonModal
          lesson={activeLesson}
          onClose={() => setActiveLesson(null)}
          onFinish={() => setActiveLesson(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
