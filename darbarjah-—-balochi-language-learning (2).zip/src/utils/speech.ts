import { LanguageCode } from '../types';
import { normalizeString } from './answerChecker';

interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
        confidence: number;
      };
    };
  };
}

interface SpeechRecognitionInstance {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
}

/**
 * Browser speech recognition support is available for supported languages.
 * Balochi recognition runs in beta mode using phonetic capturing.
 */
export function isSpeechRecognitionSupportedForLanguage(language: LanguageCode): boolean {
  return isSpeechRecognitionSupported();
}

export function startSpeechRecognition(
  language: LanguageCode,
  onResult: (transcript: string, isFinal: boolean) => void,
  onError: (err: string) => void,
  onEnd: () => void
): { stop: () => void } | null {
  if (!isSpeechRecognitionSupported()) {
    onError('Speech recognition is not supported in this browser environment.');
    return null;
  }

  try {
    const SpeechClass =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionInstance }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionInstance }).webkitSpeechRecognition;

    if (!SpeechClass) return null;

    const recognition = new SpeechClass();
    recognition.continuous = false;
    recognition.interimResults = true;

    const langMap: Record<LanguageCode, string> = {
      balochi: 'ur-PK', // Beta phonetic recognition
      darija: 'ar-MA',
      spanish: 'es-ES',
      japanese: 'ja-JP',
      french: 'fr-FR',
      german: 'de-DE',
    };

    recognition.lang = langMap[language] || 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const result = event.results[0];
      if (result && result[0]) {
        const transcript = result[0].transcript;
        onResult(transcript, true);
      }
    };

    recognition.onerror = (event: { error: string }) => {
      onError(event.error);
    };

    recognition.onend = () => {
      onEnd();
    };

    recognition.start();

    return {
      stop: () => {
        try {
          recognition.stop();
        } catch {
          // ignore
        }
      },
    };
  } catch (e) {
    onError(e instanceof Error ? e.message : 'Error starting speech recognition');
    return null;
  }
}

export function evaluateSpeechAccuracy(
  transcript: string,
  targetText: string,
  acceptedList: string[] = []
): { score: number; isPassed: boolean; feedback: string } {
  const normTrans = normalizeString(transcript);
  const normTarget = normalizeString(targetText);
  const allTargets = [normTarget, ...acceptedList.map(normalizeString)];

  if (allTargets.includes(normTrans)) {
    return {
      score: 100,
      isPassed: true,
      feedback: 'Fantastic! Crystal clear pronunciation.',
    };
  }

  // Token matching
  const transTokens = normTrans.split(' ').filter(Boolean);
  const targetTokens = normTarget.split(' ').filter(Boolean);

  let matchCount = 0;
  for (const token of targetTokens) {
    if (transTokens.includes(token)) {
      matchCount++;
    }
  }

  const tokenRatio = targetTokens.length > 0 ? matchCount / targetTokens.length : 0;
  const score = Math.round(tokenRatio * 100);

  if (score >= 60) {
    return {
      score,
      isPassed: true,
      feedback: 'Great effort! Good intonation and recognizable words.',
    };
  }

  return {
    score: Math.max(score, 30),
    isPassed: false,
    feedback: `We heard: "${transcript || '...'}" — try speaking a bit closer to the microphone and slower.`,
  };
}
