import { Exercise } from '../types';
import { LexiconEntry } from '../types/lexicon';

/**
 * Creates adaptive quiz exercises from a LexiconEntry, properly handling multiple definitions
 * and preventing ambiguous grading penalties.
 */
export function createLexiconQuizExercises(
  entry: LexiconEntry,
  allEntries: LexiconEntry[]
): Exercise[] {
  const exercises: Exercise[] = [];

  // All valid definitions for accepted answers
  const allEnglishDefs = entry.definitions.map((d) => d.english.toLowerCase());

  // Exercise 1: Definition Multiple Choice (for primary or specific meaning)
  entry.definitions.forEach((def, idx) => {
    const isMultiple = entry.definitions.length > 1;
    const promptText = isMultiple
      ? `What is a documented meaning of "${entry.arabic}" (${entry.latin})?`
      : `What does "${entry.arabic}" (${entry.latin}) mean in English?`;

    // Distractors from other entries
    const otherEntries = allEntries.filter((e) => e.id !== entry.id);
    const distractors = otherEntries
      .slice(0, 3)
      .map((e) => e.definitions[0]?.english || 'other');

    const options = [def.english, ...distractors].sort(() => Math.random() - 0.5);

    exercises.push({
      id: `quiz_${entry.id}_def_${idx}`,
      lessonId: 'lexicon_drill',
      type: 'multiple_choice',
      prompt: promptText,
      targetText: entry.arabic,
      transliteration: entry.latin,
      correctAnswer: def.english,
      acceptedAnswers: allEnglishDefs, // Any documented definition is accepted!
      options,
      audioText: entry.latin,
      difficulty: 'intermediate',
    });
  });

  // Exercise 2: Reverse English -> Balochi Recall
  const primaryDef = entry.definitions[0]?.english || '';
  const otherHeadwords = allEntries
    .filter((e) => e.id !== entry.id)
    .slice(0, 3)
    .map((e) => `${e.arabic} (${e.latin})`);

  exercises.push({
    id: `quiz_${entry.id}_reverse`,
    lessonId: 'lexicon_drill',
    type: 'multiple_choice',
    prompt: `Which Balochi word means: "${primaryDef}"?`,
    correctAnswer: `${entry.arabic} (${entry.latin})`,
    acceptedAnswers: [
      entry.arabic,
      entry.latin.toLowerCase(),
      `${entry.arabic} (${entry.latin})`.toLowerCase(),
    ],
    options: [`${entry.arabic} (${entry.latin})`, ...otherHeadwords].sort(
      () => Math.random() - 0.5
    ),
    audioText: entry.latin,
    difficulty: 'intermediate',
  });

  return exercises;
}
