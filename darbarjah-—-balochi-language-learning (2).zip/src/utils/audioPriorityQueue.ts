import { Course } from '../types';
import { LexiconEntry, PersonalLexiconState } from '../types/lexicon';

export type AudioPriorityTier =
  | 'active_lesson'
  | 'high_frequency'
  | 'learning_queue'
  | 'pronunciation_mistake'
  | 'general_lexicon';

export interface AudioPriorityItem {
  entry: LexiconEntry;
  priorityScore: number;
  tier: AudioPriorityTier;
  reasons: string[];
  activeLessons: string[];
  mistakeCount: number;
  inLearningQueue: boolean;
  frequency: string;
}

export interface AudioCoverageReport {
  totalEntries: number;
  authenticCount: number;
  aiPreviewCount: number;
  unavailableCount: number;
  activeLessonWordsCount: number;
  activeLessonWordsWithAuthenticAudio: number;
  highestPriorityWordsLackingAudio: AudioPriorityItem[];
}

/**
 * Normalizes text for matching lesson terms to lexicon entries
 */
function normalizeForMatching(text: string): string {
  return text
    .replace(/[؟?،!.,:;"'()]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Extracts a lookup map of all words appearing in active course lessons
 */
export function extractLessonWordMappings(course: Course): Map<string, { lessonIds: string[]; lessonTitles: string[] }> {
  const map = new Map<string, { lessonIds: string[]; lessonTitles: string[] }>();

  const addTerm = (rawTerm: string, lessonId: string, lessonTitle: string) => {
    if (!rawTerm || rawTerm.length < 2) return;
    const term = normalizeForMatching(rawTerm);
    if (!map.has(term)) {
      map.set(term, { lessonIds: [], lessonTitles: [] });
    }
    const entry = map.get(term)!;
    if (!entry.lessonIds.includes(lessonId)) {
      entry.lessonIds.push(lessonId);
      entry.lessonTitles.push(lessonTitle);
    }
  };

  course.sections.forEach((sec) => {
    sec.units.forEach((unit) => {
      unit.lessons.forEach((les) => {
        // Target word IDs
        if (les.targetWordIds) {
          les.targetWordIds.forEach((wId) => {
            addTerm(wId, les.id, les.title);
            // Handle common id prefixes
            addTerm(wId.replace(/^bal_\d+_/, ''), les.id, les.title);
          });
        }

        // Exercise prompts, target texts, and matching pairs
        les.exercises.forEach((ex) => {
          if (ex.targetText) addTerm(ex.targetText, les.id, les.title);
          if (ex.transliteration) addTerm(ex.transliteration, les.id, les.title);
          if (ex.audioText) addTerm(ex.audioText, les.id, les.title);
          if (ex.matchingPairs) {
            ex.matchingPairs.forEach((p) => {
              if (p.left) addTerm(p.left, les.id, les.title);
              if (p.transliteration) addTerm(p.transliteration, les.id, les.title);
            });
          }
        });
      });
    });
  });

  return map;
}

/**
 * Computes the audio priority queue for all dictionary entries lacking authentic audio.
 * Follows the 5 strict priority tiers:
 * 1. Words appearing in active lessons
 * 2. High-frequency/core vocabulary
 * 3. Words currently in the learner's practice queue
 * 4. Words with repeated pronunciation mistakes
 * 5. Other dictionary entries
 */
export function computeAudioPriorityQueue(
  lexiconEntries: LexiconEntry[],
  course: Course,
  personalStates: Record<string, PersonalLexiconState> = {}
): AudioPriorityItem[] {
  const lessonMappings = extractLessonWordMappings(course);
  const queue: AudioPriorityItem[] = [];

  lexiconEntries.forEach((entry) => {
    // Only queue items that do not yet have verified authentic native audio
    if (entry.audio?.type === 'authentic_recording' && entry.audio.url) {
      return;
    }

    let score = 0;
    const reasons: string[] = [];
    const activeLessons: string[] = [];

    // Check Tier 1: Active Lessons
    const normAra = normalizeForMatching(entry.arabic);
    const normHead = normalizeForMatching(entry.headword);
    const normLat = normalizeForMatching(entry.latin);
    const normId = normalizeForMatching(entry.id);

    const lessonHits =
      lessonMappings.get(normAra) ||
      lessonMappings.get(normHead) ||
      lessonMappings.get(normLat) ||
      lessonMappings.get(normId);

    if (lessonHits) {
      score += 10000;
      activeLessons.push(...lessonHits.lessonTitles);
      reasons.push(`Tier 1: Taught in active course lesson (${lessonHits.lessonTitles[0]})`);
    }

    // Check Tier 2: High-frequency / Core Vocabulary
    const isCoreOrHigh = entry.frequency === 'high' || entry.id.startsWith('lex_');
    if (isCoreOrHigh) {
      score += 2500;
      reasons.push('Tier 2: Core high-frequency Balochi vocabulary');
    }

    // Check Tier 3: In Learner's Personal Learning Queue
    const pState = personalStates[entry.id];
    const inQueue = pState?.isInLearningQueue || false;
    if (inQueue) {
      score += 1000;
      reasons.push("Tier 3: In learner's active study queue");
    }

    // Check Tier 4: Pronunciation/Speaking Mistakes
    const mistakes = pState?.mistakeCount || 0;
    if (mistakes > 0) {
      const mistakePoints = Math.min(mistakes * 500, 3000);
      score += mistakePoints;
      reasons.push(`Tier 4: ${mistakes} recorded pronunciation/practice mistake(s)`);
    }

    // Tier 5: General dictionary baseline
    if (score === 0) {
      score = 10;
      reasons.push('Tier 5: General dictionary entry awaiting audio recording');
    }

    // Assign Primary Tier
    let tier: AudioPriorityTier = 'general_lexicon';
    if (lessonHits) {
      tier = 'active_lesson';
    } else if (isCoreOrHigh) {
      tier = 'high_frequency';
    } else if (inQueue) {
      tier = 'learning_queue';
    } else if (mistakes > 0) {
      tier = 'pronunciation_mistake';
    }

    queue.push({
      entry,
      priorityScore: score,
      tier,
      reasons,
      activeLessons,
      mistakeCount: mistakes,
      inLearningQueue: inQueue,
      frequency: entry.frequency || 'medium',
    });
  });

  // Sort descending by priority score
  queue.sort((a, b) => b.priorityScore - a.priorityScore);

  return queue;
}

/**
 * Generates an authoritative coverage audit report
 */
export function getAudioCoverageReport(
  lexiconEntries: LexiconEntry[],
  course: Course,
  personalStates: Record<string, PersonalLexiconState> = {}
): AudioCoverageReport {
  let authenticCount = 0;
  let aiPreviewCount = 0;
  let unavailableCount = 0;

  lexiconEntries.forEach((e) => {
    if (e.audio?.type === 'authentic_recording' && e.audio.url) {
      authenticCount++;
    } else if (e.audio?.type === 'ai_preview') {
      aiPreviewCount++;
    } else {
      unavailableCount++;
    }
  });

  const lessonMappings = extractLessonWordMappings(course);
  const activeLessonEntries = lexiconEntries.filter((e) => {
    const normAra = normalizeForMatching(e.arabic);
    const normHead = normalizeForMatching(e.headword);
    const normLat = normalizeForMatching(e.latin);
    const normId = normalizeForMatching(e.id);
    return lessonMappings.has(normAra) || lessonMappings.has(normHead) || lessonMappings.has(normLat) || lessonMappings.has(normId);
  });

  const activeLessonWordsWithAuthenticAudio = activeLessonEntries.filter(
    (e) => e.audio?.type === 'authentic_recording' && !!e.audio.url
  ).length;

  const fullQueue = computeAudioPriorityQueue(lexiconEntries, course, personalStates);

  return {
    totalEntries: lexiconEntries.length,
    authenticCount,
    aiPreviewCount,
    unavailableCount,
    activeLessonWordsCount: activeLessonEntries.length,
    activeLessonWordsWithAuthenticAudio,
    highestPriorityWordsLackingAudio: fullQueue.slice(0, 20),
  };
}
