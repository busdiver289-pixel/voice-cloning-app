import { Exercise } from '../types';
import { LexiconEntry } from '../types/lexicon';
import {
  LearnerVocabularyReview,
  DetailedMistakeRecord,
  MistakeCategory,
  MasteryStatus,
} from '../types/review';

/**
 * Spaced Review Schedule Intervals (in Days)
 * Step 0: Immediate / same session (0 days)
 * Step 1: 1 day
 * Step 2: 3 days
 * Step 3: 7 days
 * Step 4: 14 days
 * Step 5: 30 days
 * Step 6: 60 days
 * Step 7+: 90 days+
 */
export const SPACED_INTERVALS_DAYS = [0, 1, 3, 7, 14, 30, 60, 90] as const;

export const MS_IN_DAY = 86_400_000;
export const MS_IN_HOUR = 3_600_000;

/**
 * Calculates review interval in milliseconds from consecutive correct count
 */
export function getSpacedIntervalMs(consecutiveCorrect: number): number {
  if (consecutiveCorrect <= 0) return 0;
  const index = Math.min(consecutiveCorrect, SPACED_INTERVALS_DAYS.length - 1);
  return SPACED_INTERVALS_DAYS[index] * MS_IN_DAY;
}

/**
 * Calculates deterministic mastery status
 * Note: Never permanently marks a word as mastered from a single correct attempt.
 */
export function determineMasteryStatus(
  masteryScore: number,
  consecutiveCorrect: number,
  totalAttempts: number,
  mistakeCount: number
): MasteryStatus {
  if (totalAttempts === 0) return 'new';
  if (mistakeCount > 0 && consecutiveCorrect === 0) return 'weak';
  if (mistakeCount > 0 && masteryScore < 45) return 'weak';
  if (consecutiveCorrect >= 4 && masteryScore >= 85) return 'mastered';
  if (consecutiveCorrect >= 2 && masteryScore >= 60) return 'practicing';
  return 'learning';
}

/**
 * Records a review attempt and computes the next spaced review timestamp
 */
export function updateVocabularyReview(
  existing: LearnerVocabularyReview | undefined,
  isCorrect: boolean,
  options: {
    lexiconId: string;
    now?: number;
    sourceLessonId?: string;
    sourceUnitId?: string;
    difficulty?: 'easy' | 'medium' | 'hard';
  }
): LearnerVocabularyReview {
  const now = options.now ?? Date.now();
  const base: LearnerVocabularyReview = existing
    ? { ...existing }
    : {
        lexiconId: options.lexiconId,
        firstLearnedAt: now,
        lastPracticedAt: now,
        totalAttempts: 0,
        correctAttempts: 0,
        incorrectAttempts: 0,
        consecutiveCorrect: 0,
        masteryScore: 0,
        masteryStatus: 'new',
        reviewCount: 0,
        nextReviewAt: now,
        difficulty: options.difficulty ?? 'medium',
        mistakeCount: 0,
        sourceLessonId: options.sourceLessonId,
        sourceUnitId: options.sourceUnitId,
      };

  base.lastPracticedAt = now;
  base.totalAttempts += 1;
  base.reviewCount += 1;
  if (options.sourceLessonId && !base.sourceLessonId) base.sourceLessonId = options.sourceLessonId;
  if (options.sourceUnitId && !base.sourceUnitId) base.sourceUnitId = options.sourceUnitId;

  if (isCorrect) {
    base.correctAttempts += 1;
    base.consecutiveCorrect += 1;
    base.lastCorrectAt = now;

    // Gradual score progression (+15 per correct step, max 100)
    base.masteryScore = Math.min(100, base.masteryScore + 15);

    // Calculate next review interval based on spaced repetition schedule
    const intervalMs = getSpacedIntervalMs(base.consecutiveCorrect);
    base.nextReviewAt = now + intervalMs;
  } else {
    base.incorrectAttempts += 1;
    base.mistakeCount += 1;
    base.consecutiveCorrect = 0;
    base.lastIncorrectAt = now;

    // Score deduction (-15 per mistake, min 0)
    base.masteryScore = Math.max(0, base.masteryScore - 15);

    // Incorrect answer reduces interval to 0 (immediate / same session) to prioritize review
    base.nextReviewAt = now;
  }

  base.masteryStatus = determineMasteryStatus(
    base.masteryScore,
    base.consecutiveCorrect,
    base.totalAttempts,
    base.mistakeCount
  );

  return base;
}

/**
 * Checks whether an item has recovered from previous mistakes
 */
export function hasRecoveredFromMistakes(review: LearnerVocabularyReview): boolean {
  if (review.mistakeCount === 0) return true;
  return review.consecutiveCorrect >= 2 && review.masteryScore >= 70;
}

/**
 * Deterministically determines the mistake category based on exercise metadata.
 * Returns undefined if the category cannot be verified (Never invents data).
 */
export function determineMistakeCategory(
  exercise: {
    type?: string;
    prompt?: string;
    targetText?: string;
    transliteration?: string;
    correctAnswer?: string;
  },
  learnerAnswer?: string
): MistakeCategory | undefined {
  const type = exercise.type;
  const prompt = exercise.prompt ? exercise.prompt.toLowerCase() : '';

  // 1. Listening / Pronunciation
  if (type === 'listening' || type === 'speaking' || prompt.includes('listen') || prompt.includes('pronounce')) {
    return 'pronunciation/listening';
  }

  // 2. Script Recognition
  if (prompt.includes('alphabet') || prompt.includes('letter') || prompt.includes('script')) {
    return 'native script recognition';
  }
  if (prompt.includes('latin') || prompt.includes('transliteration')) {
    return 'Latin recognition';
  }

  // 3. Directional Translation
  if (prompt.includes('which balochi word') || (exercise.correctAnswer && /[\u0600-\u06FF]/.test(exercise.correctAnswer))) {
    return 'English → Balochi';
  }
  if (prompt.includes('what does') || prompt.includes('translate') || (exercise.targetText && /[\u0600-\u06FF]/.test(exercise.targetText))) {
    return 'Balochi → English';
  }

  // 4. Definition / Meaning
  if (prompt.includes('definition') || prompt.includes('documented meaning')) {
    return 'definition';
  }

  // 5. Spelling (typing error with minor distance)
  if (type === 'typing' && learnerAnswer && exercise.correctAnswer) {
    return 'spelling';
  }

  if (type === 'multiple_choice' || type === 'translation') {
    return 'meaning';
  }

  return undefined;
}

/**
 * Deterministic Review Priority Calculation
 * Evaluates urgency without arbitrary randomness.
 */
export function calculateReviewPriority(
  review: LearnerVocabularyReview,
  now = Date.now(),
  isCoreLessonWord = false
): { priorityScore: number; reasons: string[] } {
  let score = 0;
  const reasons: string[] = [];

  // Factor 1: Overdue status
  if (now >= review.nextReviewAt) {
    const hoursOverdue = Math.max(0, Math.floor((now - review.nextReviewAt) / MS_IN_HOUR));
    const overdueScore = 1000 + Math.min(2000, hoursOverdue * 10);
    score += overdueScore;
    reasons.push(hoursOverdue > 24 ? `Overdue by ${Math.floor(hoursOverdue / 24)} days` : 'Due for review today');
  }

  // Factor 2: Mistake history
  if (review.mistakeCount > 0) {
    const mistakeWeight = Math.min(2500, review.mistakeCount * 250);
    score += mistakeWeight;
    reasons.push(`${review.mistakeCount} previous mistake${review.mistakeCount > 1 ? 's' : ''}`);
  }

  // Factor 3: Recent incorrect attempt
  if (review.lastIncorrectAt && (!review.lastCorrectAt || review.lastIncorrectAt > review.lastCorrectAt)) {
    score += 800;
    reasons.push('Most recent attempt was incorrect');
  }

  // Factor 4: Low mastery score
  if (review.masteryScore < 60) {
    const lowMasteryWeight = (100 - review.masteryScore) * 8;
    score += lowMasteryWeight;
    reasons.push(`Low mastery score (${review.masteryScore}%)`);
  }

  // Factor 5: Weak status
  if (review.masteryStatus === 'weak') {
    score += 600;
    reasons.push('Flagged as weak vocabulary');
  }

  // Factor 6: Core course / lesson importance
  if (isCoreLessonWord) {
    score += 300;
    reasons.push('Core curriculum vocabulary');
  }

  // Factor 7: Time since last review
  const daysSince = Math.floor((now - review.lastPracticedAt) / MS_IN_DAY);
  if (daysSince > 3) {
    score += Math.min(500, daysSince * 15);
    reasons.push(`Not reviewed for ${daysSince} days`);
  }

  return { priorityScore: score, reasons };
}

/**
 * Selects a smart batch of vocabulary words for a review session.
 * Deduplicates entries and prioritizes due words, weak words, and recent mistakes.
 */
export function selectSmartReviewBatch(
  reviews: Record<string, LearnerVocabularyReview>,
  allLexicon: LexiconEntry[],
  queuedLexiconIds: string[] = [],
  limit = 6,
  now = Date.now()
): LexiconEntry[] {
  const lexiconMap = new Map<string, LexiconEntry>();
  allLexicon.forEach((e) => lexiconMap.set(e.id, e));

  // Build scored list for all tracked vocabulary
  const scoredItems: Array<{ entry: LexiconEntry; score: number; review?: LearnerVocabularyReview }> = [];

  Object.values(reviews).forEach((rev) => {
    const entry = lexiconMap.get(rev.lexiconId);
    if (!entry) return;
    const { priorityScore } = calculateReviewPriority(rev, now);
    scoredItems.push({ entry, score: priorityScore, review: rev });
  });

  // Also consider words explicitly queued by the learner that may not have reviews yet
  queuedLexiconIds.forEach((qId) => {
    if (!reviews[qId]) {
      const entry = lexiconMap.get(qId);
      if (entry) {
        scoredItems.push({ entry, score: 750 }); // High initial reinforcement priority
      }
    }
  });

  // Sort descending by priority score
  scoredItems.sort((a, b) => b.score - a.score);

  // Return unique entries up to limit
  const seenIds = new Set<string>();
  const selected: LexiconEntry[] = [];

  for (const item of scoredItems) {
    if (!seenIds.has(item.entry.id)) {
      seenIds.add(item.entry.id);
      selected.push(item.entry);
      if (selected.length >= limit) break;
    }
  }

  // Fallback: If learner has no tracked or due reviews, provide initial foundational entries
  if (selected.length === 0) {
    allLexicon.slice(0, limit).forEach((e) => {
      if (!seenIds.has(e.id)) {
        seenIds.add(e.id);
        selected.push(e);
      }
    });
  }

  return selected;
}

/**
 * Generates smart review exercises respecting the dictionary's multiple-meanings structure.
 * Never penalizes valid documented alternative meanings.
 */
export function generateSmartReviewExercises(
  entries: LexiconEntry[],
  allLexicon: LexiconEntry[]
): Exercise[] {
  const exercises: Exercise[] = [];

  entries.forEach((entry, idx) => {
    const allEnglishDefs = entry.definitions.map((d) => d.english.trim().toLowerCase());
    const primaryEnglish = entry.definitions[0]?.english || 'Meaning';

    // Distractors from other entries
    const otherEntries = allLexicon.filter((e) => e.id !== entry.id);
    const distractors = otherEntries
      .slice(0, 3)
      .map((e) => e.definitions[0]?.english || 'Other');

    // Exercise Type A: Balochi -> English Meaning Recall
    const optionsA = [primaryEnglish, ...distractors].sort(() => Math.random() - 0.5);
    exercises.push({
      id: `rev_mc_${entry.id}_${idx}`,
      lessonId: 'smart_review',
      type: 'multiple_choice',
      prompt: `What is a documented meaning of "${entry.arabic}" (${entry.latin})?`,
      targetText: entry.arabic,
      transliteration: entry.latin,
      correctAnswer: primaryEnglish,
      acceptedAnswers: allEnglishDefs, // Multiple documented meanings respected!
      options: optionsA,
      audioText: entry.latin,
      difficulty: 'intermediate',
    });

    // Exercise Type B: English -> Balochi Reverse Identification
    const otherBalochi = otherEntries
      .slice(0, 3)
      .map((e) => `${e.arabic} (${e.latin})`);
    const correctBalochiChoice = `${entry.arabic} (${entry.latin})`;
    const optionsB = [correctBalochiChoice, ...otherBalochi].sort(() => Math.random() - 0.5);

    exercises.push({
      id: `rev_rev_${entry.id}_${idx}`,
      lessonId: 'smart_review',
      type: 'multiple_choice',
      prompt: `Which Balochi word means: "${primaryEnglish}"?`,
      correctAnswer: correctBalochiChoice,
      acceptedAnswers: [
        entry.arabic,
        entry.latin.toLowerCase(),
        correctBalochiChoice.toLowerCase(),
      ],
      options: optionsB,
      audioText: entry.latin,
      difficulty: 'intermediate',
    });
  });

  return exercises;
}
