import { LanguageCode } from '../types';

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export type SoundEffectType = 'correct' | 'incorrect' | 'click' | 'complete' | 'streak' | 'heart_lost' | 'level_up';

// Balochi alphabet (Alefbe) audio cache key helper and in-memory store
export const ALEFBE_CACHE_KEY = (letter: string) => `bal_alefbe_${letter}`;

const alefbeAudioCache = new Map<string, string>();

export function getCachedAlefbeAudio(letter: string): string | null {
  if (alefbeAudioCache.has(letter)) {
    return alefbeAudioCache.get(letter) || null;
  }
  if (typeof window !== 'undefined') {
    try {
      return sessionStorage.getItem(ALEFBE_CACHE_KEY(letter));
    } catch {
      return null;
    }
  }
  return null;
}

export function setCachedAlefbeAudio(letter: string, base64Audio: string): void {
  alefbeAudioCache.set(letter, base64Audio);
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.setItem(ALEFBE_CACHE_KEY(letter), base64Audio);
    } catch {
      // Storage quota resilience
    }
  }
}

export function playSoundEffect(type: SoundEffectType, enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    if (type === 'correct') {
      // Sparkling major triad arpeggio (C5 -> E5 -> G5 -> C6)
      const freqs = [523.25, 659.25, 783.99, 1046.5];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);

        gain.gain.setValueAtTime(0, now + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.07 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.3);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.32);
      });
    } else if (type === 'incorrect') {
      // Gentle soft low buzz
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.linearRampToValueAtTime(110, now + 0.25);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.32);
    } else if (type === 'click') {
      // Crisp subtle pop
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.04);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'complete' || type === 'level_up') {
      // Celebration fanfare
      const melody = [
        { f: 523.25, d: 0.12 },
        { f: 659.25, d: 0.12 },
        { f: 783.99, d: 0.12 },
        { f: 1046.5, d: 0.35 },
      ];
      let t = now;
      melody.forEach((note) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note.f, t);

        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + note.d);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + note.d + 0.05);
        t += note.d * 0.8;
      });
    } else if (type === 'streak') {
      // Warm rising tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.35);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.42);
    } else if (type === 'heart_lost') {
      // Descending minor tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.exponentialRampToValueAtTime(220, now + 0.25);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    }
  } catch (err) {
    console.debug('WebAudio effect error:', err);
  }
}

export async function playSpeech(
  text: string,
  language: LanguageCode,
  options?: {
    speed?: 'normal' | 'slow';
    useGemini?: boolean;
    letterKey?: string;
    onStart?: () => void;
    onEnd?: () => void;
  }
): Promise<void> {
  const speed = options?.speed || 'normal';
  const rate = speed === 'slow' ? 0.65 : 1.0;

  options?.onStart?.();

  // Check Alefbe cache first if letterKey is specified
  if (options?.letterKey) {
    const cachedAudio = getCachedAlefbeAudio(options.letterKey);
    if (cachedAudio) {
      try {
        const audio = new Audio(`data:audio/wav;base64,${cachedAudio}`);
        audio.playbackRate = rate;
        audio.onended = () => options?.onEnd?.();
        audio.onerror = () => fallbackSpeech(text, language, rate, options?.onEnd);
        await audio.play();
        return;
      } catch {
        // Fall through to regular playback if audio context issue
      }
    }
  }

  // Try server-side Gemini TTS if enabled
  if (options?.useGemini !== false) {
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, language, speed }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          if (options?.letterKey) {
            setCachedAlefbeAudio(options.letterKey, data.audioBase64);
          }
          const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
          audio.playbackRate = rate;
          audio.onended = () => options?.onEnd?.();
          audio.onerror = () => fallbackSpeech(text, language, rate, options?.onEnd);
          await audio.play();
          return;
        }
      }
    } catch {
      // Fallback seamlessly to Web Speech Synthesis
    }
  }

  fallbackSpeech(text, language, rate, options?.onEnd);
}

/**
 * Pronounce an Alefbe letter with automatic caching under ALEFBE_CACHE_KEY
 */
export async function playAlefbeSpeech(
  letter: string,
  spokenText?: string,
  options?: { speed?: 'normal' | 'slow'; onStart?: () => void; onEnd?: () => void }
): Promise<void> {
  const speechText = spokenText || letter;
  return playSpeech(speechText, 'balochi', {
    ...options,
    letterKey: letter,
  });
}

function fallbackSpeech(
  text: string,
  language: LanguageCode,
  rate: number,
  onEnd?: () => void
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onEnd?.();
    return;
  }

  window.speechSynthesis.cancel();

  // Never use Urdu (or another language) as a silent fallback for Balochi.
  // That would make non-Balochi speech sound like an authentic Balochi lesson.
  if (language === 'balochi') {
    console.warn('Balochi browser TTS fallback disabled: no reliable Balochi voice is available.');
    onEnd?.();
    return;
  }

  const langMap: Partial<Record<LanguageCode, string>> = {
    darija: 'ar-MA',
    spanish: 'es-ES',
    japanese: 'ja-JP',
    french: 'fr-FR',
    german: 'de-DE',
  };

  const targetLocale = langMap[language] || 'en-US';
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = targetLocale;
  utterance.rate = rate;

  // Search for the best available matching voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice =
    voices.find((v) => v.lang.toLowerCase().startsWith(targetLocale.slice(0, 2).toLowerCase())) ||
    voices.find((v) => v.lang.includes(targetLocale));

  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onend = () => onEnd?.();
  utterance.onerror = () => onEnd?.();

  window.speechSynthesis.speak(utterance);
}
