export interface CheckResult {
  isCorrect: boolean;
  hasTypo: boolean;
  userAnswer: string;
  expectedAnswer: string;
  feedback?: string;
  similarity: number; // 0 to 1
}

export function normalizeString(str: string): string {
  if (!str) return '';

  return str
    .toLowerCase()
    .trim()
    // Normalize Arabic forms: alif with hamza / madda -> plain alif
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    // Remove Arabic Tashkeel (harakat)
    .replace(/[\u064B-\u0652]/g, '')
    // Remove Latin diacritics
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    // Remove punctuation
    .replace(/[.,/#!$%^&*;:{}=\-_`~()?"'«»¡¿]/g, '')
    // Collapse whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
  }

  return dp[m][n];
}

export function checkAnswer(
  userAnswer: string,
  correctAnswer: string,
  acceptedAnswers: string[] = []
): CheckResult {
  const normUser = normalizeString(userAnswer);
  const normCorrect = normalizeString(correctAnswer);

  const allAccepted = [normCorrect, ...acceptedAnswers.map(normalizeString)].filter(Boolean);

  // 1. Exact normalized match
  if (allAccepted.includes(normUser)) {
    return {
      isCorrect: true,
      hasTypo: false,
      userAnswer,
      expectedAnswer: correctAnswer,
      similarity: 1.0,
      feedback: 'Excellent! Exactly right.',
    };
  }

  // 2. Fuzzy match with typo tolerance
  let highestSimilarity = 0;
  let closestTarget = correctAnswer;

  for (const target of allAccepted) {
    const dist = levenshteinDistance(normUser, target);
    const maxLen = Math.max(normUser.length, target.length);
    const sim = maxLen > 0 ? (maxLen - dist) / maxLen : 0;

    if (sim > highestSimilarity) {
      highestSimilarity = sim;
      closestTarget = target;
    }

    // Single letter typo on words > 4 chars, or 2 letter typo on longer phrases
    const allowedErrors = maxLen >= 12 ? 2 : maxLen >= 4 ? 1 : 0;
    if (dist <= allowedErrors && allowedErrors > 0) {
      return {
        isCorrect: true,
        hasTypo: true,
        userAnswer,
        expectedAnswer: correctAnswer,
        similarity: sim,
        feedback: `You have a minor typo, but your answer is accepted! Correct spelling: "${correctAnswer}"`,
      };
    }
  }

  return {
    isCorrect: false,
    hasTypo: false,
    userAnswer,
    expectedAnswer: correctAnswer,
    similarity: highestSimilarity,
    feedback: `Not quite. Correct answer: "${correctAnswer}"`,
  };
}
