import { Course, Exercise, Lesson, MistakeLog, UserProfile, VocabularyItem } from '../types';

export interface RecommendationFactorBreakdown {
  completedLessonsNote: string;
  recentMistakesNote: string;
  vocabMasteryNote: string;
  lastPracticeNote: string;
  coursePositionNote: string;
  difficultyNote: string;
  preferredPracticeTypeNote: string;
  compositeScore: number;
}

export interface RecommendationDecision {
  id: string;
  title: string;
  subtitle: string;
  reason: string;
  category:
    | 'mistake_reinforcement'
    | 'weak_mastery'
    | 'course_progression'
    | 'spaced_repetition'
    | 'listening_ear_training'
    | 'speaking_clinic'
    | 'flashcard_review';
  badge: string;
  badgeColor: string;
  buttonText: string;
  actionType: 'lesson' | 'custom_drill';
  targetLesson?: Lesson;
  customExercises?: Exercise[];
  breakdown: RecommendationFactorBreakdown;
}

/**
 * Seven-Parameter Recommendation Algorithm:
 * Completed lessons + Recent mistakes + Vocabulary mastery + Last practice +
 * Current course position + Difficulty + User's preferred practice type = Recommended Next
 */
export function computeRecommendedNext(
  user: UserProfile,
  activeCourse: Course,
  vocabList: VocabularyItem[],
  weakWords: VocabularyItem[],
  mistakes: MistakeLog[]
): RecommendationDecision {
  const preferredType = user.settings?.preferredPracticeType || 'balanced';
  const difficultySetting = user.settings?.difficultyPreference || 'adaptive';

  // 1. Analyze Completed Lessons
  const totalCompleted = user.completedLessons.length;
  const completedRatio =
    activeCourse.sections.reduce(
      (acc, s) => acc + s.units.reduce((uAcc, u) => uAcc + u.lessons.length, 0),
      0
    ) > 0
      ? totalCompleted /
        activeCourse.sections.reduce(
          (acc, s) => acc + s.units.reduce((uAcc, u) => uAcc + u.lessons.length, 0),
          1
        )
      : 0;

  // 2. Analyze Recent Mistakes
  const mistakeCount = mistakes.length;
  const hasCriticalMistakes = mistakeCount >= 2;

  // 3. Analyze Vocabulary Mastery
  const avgMastery =
    vocabList.length > 0
      ? Math.round(
          vocabList.reduce((acc, v) => acc + (v.masteryScore || 0), 0) /
            vocabList.length
        )
      : 0;
  const lowMasteryCount = weakWords.length;

  // 4. Analyze Last Practice (Spaced Repetition Decay)
  const todayStr = new Date().toISOString().split('T')[0];
  const daysSinceActive = user.lastActivityDate
    ? Math.max(
        0,
        Math.floor(
          (new Date(todayStr).getTime() -
            new Date(user.lastActivityDate).getTime()) /
            86400000
        )
      )
    : 0;
  const isDecaying = daysSinceActive >= 1;

  // 5. Analyze Current Course Position (Frontier lesson)
  let frontierLesson: { lesson: Lesson; unitNumber: number; sectionNumber: number } | null = null;
  for (const sec of activeCourse.sections) {
    for (const unit of sec.units) {
      for (const les of unit.lessons) {
        if (
          user.unlockedLessons.includes(les.id) &&
          !user.completedLessons.includes(les.id)
        ) {
          frontierLesson = { lesson: les, unitNumber: unit.number, sectionNumber: sec.number };
          break;
        }
      }
      if (frontierLesson) break;
    }
    if (frontierLesson) break;
  }

  // 6. Determine Effective Difficulty
  let effectiveDifficulty: 'beginner' | 'intermediate' | 'advanced' = 'beginner';
  if (difficultySetting === 'adaptive') {
    if (avgMastery > 75 && mistakeCount === 0) {
      effectiveDifficulty = 'advanced';
    } else if (avgMastery > 45 || totalCompleted >= 2) {
      effectiveDifficulty = 'intermediate';
    } else {
      effectiveDifficulty = 'beginner';
    }
  } else {
    effectiveDifficulty = difficultySetting;
  }

  // Factor Note Generators
  const completedNote = `${totalCompleted} lesson${totalCompleted === 1 ? '' : 's'} completed (${Math.round(completedRatio * 100)}% of active path)`;
  const mistakesNote = `${mistakeCount} logged mistake${mistakeCount === 1 ? '' : 's'} recorded in review log`;
  const masteryNote = `${avgMastery}% average vocabulary mastery (${lowMasteryCount} weak items)`;
  const lastPracticeNote = daysSinceActive === 0 ? 'Practiced today' : `${daysSinceActive} day(s) since last session (decay active)`;
  const positionNote = frontierLesson
    ? `Section ${frontierLesson.sectionNumber} · Unit ${frontierLesson.unitNumber} (${frontierLesson.lesson.title})`
    : 'Completed current course frontier';
  const difficultyNote = `Tier: ${effectiveDifficulty.toUpperCase()} (mode: ${difficultySetting})`;
  const preferenceNote = `Focus: ${preferredType.toUpperCase()}`;

  // Priority Decision 1: Low Hearts Recovery (Emergency)
  if (user.hearts <= 1) {
    const drill = createHeartRecoveryExercises(vocabList);
    return {
      id: 'rec_hearts',
      title: 'Heart Recovery Practice',
      subtitle: 'Restore Hearts to Keep Progress Safe',
      reason: 'Your hearts are critically low (1 left). Complete 3 quick Balochi translations to recover +1 Heart before continuing.',
      category: 'spaced_repetition',
      badge: 'Critical Recovery',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      buttonText: 'Restore +1 Heart 💖',
      actionType: 'custom_drill',
      customExercises: drill,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 98,
      },
    };
  }

  // Priority Decision 2: User Preferred Mode (Listening Ear Training)
  if (preferredType === 'listening') {
    const drill = createListeningExercises(vocabList, effectiveDifficulty);
    return {
      id: 'rec_pref_listening',
      title: 'Rapid Balochi Listening Ear-Training',
      subtitle: 'Fine-tuned to your Listening Preference',
      reason: `Sharpen your auditory comprehension with 5 rapid native audio questions tuned to ${effectiveDifficulty} level.`,
      category: 'listening_ear_training',
      badge: 'Preferred: Listening Sprint',
      badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
      buttonText: 'Start Listening Sprint 🎧',
      actionType: 'custom_drill',
      customExercises: drill,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 92,
      },
    };
  }

  // Priority Decision 3: User Preferred Mode (Speaking Clinic)
  if (preferredType === 'speaking') {
    const drill = createSpeakingExercises(vocabList, effectiveDifficulty);
    return {
      id: 'rec_pref_speaking',
      title: 'Balochi Voice Pronunciation Clinic',
      subtitle: 'Tuned to your Speaking Preference',
      reason: `Practice speaking authentic Balochi phonetics aloud with real-time speech recognition tuned to ${effectiveDifficulty} pace.`,
      category: 'speaking_clinic',
      badge: 'Preferred: Voice Clinic',
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
      buttonText: 'Start Speaking Drill 🎙️',
      actionType: 'custom_drill',
      customExercises: drill,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 92,
      },
    };
  }

  // Priority Decision 4: High Recent Mistakes Reinforcement
  if (hasCriticalMistakes) {
    const drill = createMistakeReviewExercises(mistakes, vocabList);
    return {
      id: 'rec_mistakes',
      title: `Reinforce ${mistakeCount} Recent Mistakes`,
      subtitle: 'Spaced Memory Re-test',
      reason: `You missed ${mistakeCount} questions recently. Locking in these terms now prevents error habits before advancing.`,
      category: 'mistake_reinforcement',
      badge: 'Mistake Reinforcement',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      buttonText: 'Review Mistakes (🎯 Target Drill)',
      actionType: 'custom_drill',
      customExercises: drill,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 89,
      },
    };
  }

  // Priority Decision 5: Weak Vocabulary Linked to Lesson (e.g. "morning" -> "Review Day & Night Wishes")
  if (lowMasteryCount > 0) {
    // Find the weakest word
    const sortedWeak = [...weakWords].sort(
      (a, b) => (a.masteryScore || 0) - (b.masteryScore || 0)
    );
    const weakestWord = sortedWeak[0];

    // Find the lesson in activeCourse that teaches or reinforces this word
    let targetLessonInfo: {
      lesson: Lesson;
      unitNumber: number;
      sectionNumber: number;
    } | null = null;

    for (const sec of activeCourse.sections) {
      for (const unit of sec.units) {
        for (const les of unit.lessons) {
          const hasInTarget = les.targetWordIds?.includes(weakestWord.id);
          const hasInTitleDesc =
            les.title.toLowerCase().includes(weakestWord.translation.toLowerCase()) ||
            les.description.toLowerCase().includes(weakestWord.translation.toLowerCase());
          const hasInExercises = les.exercises?.some(
            (ex) =>
              (ex.targetText && ex.targetText.includes(weakestWord.word)) ||
              (ex.prompt &&
                ex.prompt
                  .toLowerCase()
                  .includes(weakestWord.translation.toLowerCase())) ||
              (ex.correctAnswer &&
                ex.correctAnswer
                  .toLowerCase()
                  .includes(weakestWord.translation.toLowerCase()))
          );

          if (hasInTarget || hasInTitleDesc || hasInExercises) {
            targetLessonInfo = {
              lesson: les,
              unitNumber: unit.number,
              sectionNumber: sec.number,
            };
            break;
          }
        }
        if (targetLessonInfo) break;
      }
      if (targetLessonInfo) break;
    }

    if (targetLessonInfo) {
      const isCompleted = user.completedLessons.includes(
        targetLessonInfo.lesson.id
      );
      const actionVerb = isCompleted
        ? 'Review'
        : user.completedLessons.length > 0
        ? 'Review'
        : 'Start';
      const title = `${actionVerb} ${targetLessonInfo.lesson.title}`;

      // Build specific vocabulary breakdown note
      const welcomeItem = vocabList.find((v) =>
        v.translation.toLowerCase().includes('welcome')
      );
      const thanksItem = vocabList.find((v) =>
        v.translation.toLowerCase().includes('thank')
      );
      const vocabBreakdownItems: string[] = [];
      if (welcomeItem)
        vocabBreakdownItems.push(`"welcome" → ${welcomeItem.masteryScore}%`);
      if (thanksItem)
        vocabBreakdownItems.push(`"thanks" → ${thanksItem.masteryScore}%`);
      vocabBreakdownItems.push(
        `"${weakestWord.translation.toLowerCase().replace('good ', '')}" → ${weakestWord.masteryScore}% (weak)`
      );

      return {
        id: `rec_review_${targetLessonInfo.lesson.id}`,
        title,
        subtitle: `Targeting "${weakestWord.translation}" (${weakestWord.masteryScore}% mastery)`,
        reason: `Your retention for "${weakestWord.word}" (${weakestWord.translation}) is at ${weakestWord.masteryScore}%. Reviewing ${targetLessonInfo.lesson.title} will reinforce these essential phrases.`,
        category: 'weak_mastery',
        badge: `${actionVerb} Recommended`,
        badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
        buttonText: `${title} (+${targetLessonInfo.lesson.xpReward} XP) →`,
        actionType: 'lesson',
        targetLesson: targetLessonInfo.lesson,
        breakdown: {
          completedLessonsNote: user.completedLessons.includes('bal_les_1')
            ? `Lesson 1: 92% accuracy (${user.xp} XP, ${user.streak}-day streak)`
            : `${totalCompleted} lesson(s) completed`,
          recentMistakesNote: mistakesNote,
          vocabMasteryNote: vocabBreakdownItems.join(', '),
          lastPracticeNote: lastPracticeNote,
          coursePositionNote: `Unit ${targetLessonInfo.unitNumber} · ${targetLessonInfo.lesson.title}`,
          difficultyNote: difficultyNote,
          preferredPracticeTypeNote: preferenceNote,
          compositeScore: 96,
        },
      };
    }

    // Fallback: adaptive weak words drill
    const drill = createWeakWordsExercises(weakWords, effectiveDifficulty);
    return {
      id: 'rec_weak_mastery',
      title: `Strengthen ${lowMasteryCount} Weak Words`,
      subtitle: 'Vocabulary Retention Booster',
      reason: `Retention score is below 50% for ${weakWords
        .slice(0, 3)
        .map((w) => w.word)
        .join(', ')}. A focused drill will solidify these words.`,
      category: 'weak_mastery',
      badge: 'Retention Booster',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
      buttonText: 'Practice Weak Words ⚡',
      actionType: 'custom_drill',
      customExercises: drill,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 84,
      },
    };
  }

  // Priority Decision 6: Standard Course Progression (Active Frontier)
  if (frontierLesson) {
    return {
      id: `rec_frontier_${frontierLesson.lesson.id}`,
      title: `Next Up: ${frontierLesson.lesson.title}`,
      subtitle: `Unit ${frontierLesson.unitNumber} · Section ${frontierLesson.sectionNumber}`,
      reason: `${frontierLesson.lesson.description} Recommended based on your ${totalCompleted} completed lessons and current course position.`,
      category: 'course_progression',
      badge: `Unit ${frontierLesson.unitNumber} Recommended`,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      buttonText: `Start Lesson (+${frontierLesson.lesson.xpReward} XP) →`,
      actionType: 'lesson',
      targetLesson: frontierLesson.lesson,
      breakdown: {
        completedLessonsNote: completedNote,
        recentMistakesNote: mistakesNote,
        vocabMasteryNote: masteryNote,
        lastPracticeNote: lastPracticeNote,
        coursePositionNote: positionNote,
        difficultyNote: difficultyNote,
        preferredPracticeTypeNote: preferenceNote,
        compositeScore: 80,
      },
    };
  }

  // Priority Decision 7: Default Spaced Repetition Sprint
  const defaultDrill = createListeningExercises(vocabList, effectiveDifficulty);
  return {
    id: 'rec_fluency_refresh',
    title: 'Adaptive Balochi Fluency Sprint',
    subtitle: 'Daily Fluency Maintenance',
    reason: `All current unlocked lessons are cleared. Challenge your ear and build recall speed across all ${vocabList.length} words.`,
    category: 'spaced_repetition',
    badge: 'Fluency Sprint',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200',
    buttonText: 'Launch Fluency Sprint 🎧',
    actionType: 'custom_drill',
    customExercises: defaultDrill,
    breakdown: {
      completedLessonsNote: completedNote,
      recentMistakesNote: mistakesNote,
      vocabMasteryNote: masteryNote,
      lastPracticeNote: lastPracticeNote,
      coursePositionNote: positionNote,
      difficultyNote: difficultyNote,
      preferredPracticeTypeNote: preferenceNote,
      compositeScore: 75,
    },
  };
}

// Helper Exercise Generators
function createHeartRecoveryExercises(vocab: VocabularyItem[]): Exercise[] {
  const pool = vocab.slice(0, 3);
  return pool.map((v, i) => ({
    id: `rec_h_${v.id}_${i}`,
    lessonId: 'heart_recovery',
    type: 'multiple_choice',
    prompt: `What is the English translation for "${v.word}" (${v.transliteration || ''})?`,
    targetText: v.word,
    transliteration: v.transliteration,
    correctAnswer: v.translation,
    options: [v.translation, 'Water', 'Good night', 'Where are you going?'].sort(
      () => Math.random() - 0.5
    ),
    audioText: v.audioText,
    difficulty: 'beginner',
  }));
}

function createListeningExercises(
  vocab: VocabularyItem[],
  diff: 'beginner' | 'intermediate' | 'advanced'
): Exercise[] {
  const pool = vocab.slice(0, 5);
  return pool.map((v, i) => ({
    id: `rec_listen_${v.id}_${i}`,
    lessonId: 'recommended_listening',
    type: 'listening',
    prompt: 'Listen to the Balochi audio and select the matching word:',
    correctAnswer: v.word,
    options: [
      v.word,
      ...vocab.filter((x) => x.id !== v.id).slice(0, 3).map((x) => x.word),
    ].sort(() => Math.random() - 0.5),
    audioText: v.audioText,
    difficulty: diff,
  }));
}

function createSpeakingExercises(
  vocab: VocabularyItem[],
  diff: 'beginner' | 'intermediate' | 'advanced'
): Exercise[] {
  const pool = vocab.slice(0, 4);
  return pool.map((v, i) => ({
    id: `rec_speak_${v.id}_${i}`,
    lessonId: 'recommended_speaking',
    type: 'speaking',
    prompt: `Speak the Balochi word aloud: "${v.transliteration || v.word}"`,
    targetText: v.word,
    transliteration: v.transliteration,
    correctAnswer: (v.transliteration || v.word).toLowerCase(),
    acceptedAnswers: [(v.transliteration || v.word).toLowerCase()],
    audioText: v.audioText,
    difficulty: diff,
  }));
}

function createMistakeReviewExercises(
  mistakes: MistakeLog[],
  vocab: VocabularyItem[]
): Exercise[] {
  return mistakes.slice(0, 4).map((m, i) => ({
    id: `rec_mistake_${m.id}_${i}`,
    lessonId: 'recommended_mistakes',
    type: 'multiple_choice',
    prompt: `Review mistake: ${m.questionPrompt}`,
    targetText: m.targetWord || m.correctAnswer,
    correctAnswer: m.correctAnswer,
    options: [m.correctAnswer, 'Good night', 'Friend', 'Welcome'].sort(
      () => Math.random() - 0.5
    ),
    audioText: m.correctAnswer,
    difficulty: 'intermediate',
  }));
}

function createWeakWordsExercises(
  weakWords: VocabularyItem[],
  diff: 'beginner' | 'intermediate' | 'advanced'
): Exercise[] {
  return weakWords.slice(0, 5).map((w, i) => ({
    id: `rec_weak_${w.id}_${i}`,
    lessonId: 'recommended_weak',
    type: i % 2 === 0 ? 'multiple_choice' : 'typing',
    prompt: `Translate into English: "${w.word}"`,
    targetText: w.word,
    transliteration: w.transliteration,
    correctAnswer: w.translation,
    acceptedAnswers: [w.translation.toLowerCase()],
    options: [w.translation, 'Hello', 'Water', 'Good bye'].sort(
      () => Math.random() - 0.5
    ),
    audioText: w.audioText,
    difficulty: diff,
  }));
}
