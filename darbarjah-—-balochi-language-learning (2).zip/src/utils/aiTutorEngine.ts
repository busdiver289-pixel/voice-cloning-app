/**
 * Darbarjah Adaptive AI Tutor Dialogue Engine
 * Provides authentic, rich conversational responses across roleplay scenarios.
 * Operates seamlessly with Gemini 3.8 Flash and as a robust contextual conversation engine.
 */

export interface TutorResponse {
  reply: string;
  translation: string;
  hint: string;
  suggestions: string[];
}

export function extractSpokenText(fullText: string): string {
  if (!fullText) return '';
  // If text contains Perso-Arabic script, extract clean Arabic script phrase
  const arabicMatch = fullText.match(/[\u0600-\u06FF\s،؛؟!.]+/g);
  if (arabicMatch) {
    const combined = arabicMatch.join(' ').trim();
    if (combined.length > 2) return combined;
  }
  // Otherwise clean out bracketed notes/translations
  return fullText.replace(/\([^)]*\)/g, '').replace(/\[[^\]]*\]/g, '').trim() || fullText;
}

export function generateAdaptiveTutorResponse(
  language: string,
  scenario: string,
  messages: Array<{ sender: string; text: string }>
): TutorResponse {
  const userMessages = messages.filter((m) => m.sender === 'user' || m.sender === 'Learner');
  const lastUserMsg = userMessages.length > 0 ? userMessages[userMessages.length - 1].text.trim().toLowerCase() : '';
  const turnCount = userMessages.length;

  const scen = scenario.toLowerCase();

  // -------------------------------------------------------------
  // BALOCHI CONVERSATION SCENARIOS
  // -------------------------------------------------------------
  if (language === 'balochi' || !language) {
    // 1. Meet & Greet (سلام سَنگت)
    if (scen.includes('meet') || scen.includes('greet') || scen.includes('سلام')) {
      // Check for user introducing their name
      const nameMatch = lastUserMsg.match(/(?:mani\s+naam|naam\s+is|name\s+is|mani\s+nam|نام|name)\s+(?:ent\s+)?([a-zA-Z\u0600-\u06FF]+)/i) ||
        (lastUserMsg.length < 20 && !lastUserMsg.includes('choni') && !lastUserMsg.includes('salam') ? lastUserMsg.match(/([a-zA-Z\u0600-\u06FF]+)/) : null);
      
      const detectedName = nameMatch && nameMatch[1] && nameMatch[1].length > 1 ? nameMatch[1] : '';

      if (detectedName && (lastUserMsg.includes('naam') || lastUserMsg.includes('nam') || turnCount === 1)) {
        return {
          reply: `وشنام باتے ${detectedName} سَنگت! باز وشحال بوتاں تئی پجار ءَ۔ تو چونی، دراہ ءُ وشیں؟ (Wash-naam baate ${detectedName} sangat! Baz washhaal bootan tai pajar a. Tao choni, drah o washen?)`,
          translation: `May your name be blessed, friend ${detectedName}! Very pleased to meet you. How are you, in good health and well?`,
          hint: 'Say: "Man wasshan, minntwar!" (I am fine, thank you!) or "Drah aan"',
          suggestions: [
            'من وش ءُ دراہ آں، منتوار (Man wash o drah aan, minntwar)',
            'الحمدللہ باز جوان آں (Alhamdulillah, baz jowan aan)',
            'تئی هال چوں انت؟ (Tai haal chon ent?)',
          ],
        };
      }

      // Check if user is asking how the tutor is
      if (lastUserMsg.includes('choni') || lastUserMsg.includes('چونی') || lastUserMsg.includes('haal') || lastUserMsg.includes('how are you')) {
        return {
          reply: 'من ہم باز وش ءُ سلامت آں، تئی مہر انت سَنگت! مروچی روچ چوں گوزگا انت؟ (Man ham baz wash o salamat aan, tai mehr ent sangat! Marochi roch chon gozaga ent?)',
          translation: 'I am also very well and safe, thanks to your kindness friend! How is your day passing today?',
          hint: 'Say: "Roch baz jowan ent" (The day is very good) or "Kar kanga aan" (I am working)',
          suggestions: [
            'روچ باز جوان انت (Roch baz jowan ent)',
            'من کار کنگا آں (Man kar kanga aan)',
            'سنگتاں گوں دیوان کنیں (Sangatan gon deewan kanen)',
          ],
        };
      }

      // Check if user is saying they are fine
      if (lastUserMsg.includes('wash') || lastUserMsg.includes('وش') || lastUserMsg.includes('drah') || lastUserMsg.includes('fine') || lastUserMsg.includes('alhamdulillah')) {
        return {
          reply: 'مدام وش ءُ شادمان باتے! تو بلوچستان ءَ کجام دمگ ءَ دوست دارئے؟ (Madam wash o shadman baate! Tao Balochistan a kajam damag a dost dare?)',
          translation: 'May you always be happy and cheerful! Which region in Balochistan do you like?',
          hint: 'Say: "Gwadar" (Coast), "Makran", "Quetta", or "Sarawan"',
          suggestions: [
            'گوادر ءِ زِر ءُ ساحل (Gwadar e zir - Gwadar coast)',
            'شال ءُ کوئٹہ (Shaal / Quetta)',
            'مکران ءِ کھیر ءُ مچّ (Makran e machh - Date palms)',
          ],
        };
      }

      // Check if user mentions regions / places
      if (lastUserMsg.includes('gwadar') || lastUserMsg.includes('quetta') || lastUserMsg.includes('makran') || lastUserMsg.includes('karachi') || lastUserMsg.includes('شال')) {
        return {
          reply: 'باز ڈولداریں ھندے! اودا چائے ورگ ءِ وتی لذتے است۔ تو بلوچی گپ جت کنئے؟ (Baz doldaren hande! Auda chae warag e wati lazzate ast. Tao Balochi gapp jat kane?)`',
          translation: 'A truly beautiful place! Drinking tea there is a joy. Can you speak and practice Balochi?',
          hint: 'Say: "Hao, kama kama" (Yes, little by little) or "Man darbaraga aan" (I am learning)',
          suggestions: [
            'ہو، من دربرگا آں (Hao, man darbaraga aan)',
            'کما کما زاناں (Kama kama zanaan)',
            'بلوچی شریں زبانے (Balochi sharen zubane)',
          ],
        };
      }

      // Default turn progression for Meet & Greet
      if (turnCount >= 3) {
        return {
          reply: 'آفرین سَنگت! تو باز جوانیں وڑے ءَ بلوچی دربرگا ئے! پدا گندیں ءُ گپ کنیں (Aafreen sangat! Tao baz jowanen wad a Balochi darbaraga ye! Pada ginden o gapp kanen)',
          translation: 'Bravo friend! You are learning Balochi wonderfully! We will meet again and chat.',
          hint: 'Say: "Minntwar واجہ!" (Thank you respected friend!) or "Khuda hafiz"',
          suggestions: [
            'باز منتوار واجہ! (Baz minntwar waja!)',
            'پدا گندیں (Pada ginden - See you again)',
            'خدا حافظ (Khuda hafiz)',
          ],
        };
      }

      return {
        reply: 'وَش آتکے سَنگت! تئی گپ باز جوان انت۔ بیا گیشتر گپ کنیں (Wash aatke sangat! Tai gapp baz jowan ent. Bya geshter gapp kanen)',
        translation: 'Welcome friend! Your words are very good. Let us converse further.',
        hint: 'Say: "Tai naam che ent?" (What is your name?) or "Mani naam..."',
        suggestions: [
          'تئی نام کئے انت؟ (Tai naam Kae ent?)',
          'تو چونی سَنگت؟ (Tao choni sangat?)',
          'من وش آں منتوار (Man wash aan minntwar)',
        ],
      };
    }

    // 2. Where Are You From? (تو کُجّیگے)
    if (scen.includes('where') || scen.includes('origin') || scen.includes('کجّیگے') || scen.includes('home')) {
      if (lastUserMsg.includes('karachi') || lastUserMsg.includes('quetta') || lastUserMsg.includes('gwadar') || lastUserMsg.includes('turbat') || lastUserMsg.includes('lahore') || lastUserMsg.includes('london')) {
        return {
          reply: 'واہ واہ! اودا بلوچ باز نند انت ءُ تئی شھر باز نامدار انت۔ تئی کھول ہم ہمودا نندیت؟ (Waah waah! Auda Baloch baz nand ant o tai shahr baz naamdar ent. Tai khol ham hamoda nandit?)',
          translation: 'Splendid! Many Baloch live there and your city is renowned. Does your family also reside there?',
          hint: 'Say: "Hao, mani khol hamoda انت" (Yes, my family is there) or "Inna" (No)',
          suggestions: [
            'ہو، منی کھول ہمودا نندیت (Hao, mani khol hamoda nandit)',
            'انّا، من درمُلک ءَ آں (Inna, man darmulk a aan)',
            'تو کُجّیگے واجہ؟ (Tao kujege waja?)',
          ],
        };
      }

      if (lastUserMsg.includes('tao') || lastUserMsg.includes('kujege') || lastUserMsg.includes('where are you')) {
        return {
          reply: 'من مکران ءُ کیچ ءِ ھند ءِ باشنده آں! مئے ھند ءَ کہیر ءُ مچّ باز انت۔ تئی شھر ءَ موسم چوں انت؟ (Man Makran o Kech e hand e bashandah aan! Mae hand a kaheer o machh baz ant. Tai shahr a mosam chon ent?)',
          translation: 'I am a resident of Makran and Kech! In our region there are date palms in abundance. How is the weather in your city?',
          hint: 'Say: "Mosam baz wash ent" (Weather is pleasant) or "Garm ent" (Warm)',
          suggestions: [
            'موسم باز وش انت (Mosam baz wash ent)',
            'گرم انت (Garm ent - It is warm)',
            'سرد ءُ یخ انت (Sard o yakh ent - It is cold)',
          ],
        };
      }

      return {
        reply: 'من مکران ءُ گوادر ءِ زِربار ءَ ننداں۔ تو وتی شھر ءِ بارہ ءَ گیشتر هال بدئے (Man Makran o Gwadar e zirbar a nandan. Tao wati shahr e bara a geshter haal bade)',
        translation: 'I live by the coast of Makran and Gwadar. Tell me more about your city!',
        hint: 'Say: "Mani shahr baz doldar ent" (My city is very beautiful)',
        suggestions: [
          'منی شھر باز ڈولدار انت (Mani shahr baz doldar ent)',
          'ہوا باز وش انت (Hawa baz wash ent)',
          'منتوار سَنگت (Minntwar sangat)',
        ],
      };
    }

    // 3. Family & Friends (کھول ءُ سَنگت)
    if (scen.includes('family') || scen.includes('friend') || scen.includes('کھول') || scen.includes('سنگت')) {
      return {
        reply: 'سنگت ءِ قدر باز انت! بلوچی ءَ گْوش انت: سنگت برات ءِ بدل انت۔ تئی دگہ کجام سیاد است؟ (Sangat e qadr baz ent! Balochi a gwash ant: Sangat braat e badal ent. Tai diga kajam seeyad ast?)',
        translation: 'A true friend is priceless! In Balochi they say: A loyal friend is like a brother. What other relatives do you have?',
        hint: 'Say: "Mani Pith o Maath" (My father and mother) or "Braat" (Brother)',
        suggestions: [
          'منی مات ءُ پت (Mani maath o pith)',
          'منی برات ءُ گہار (Mani braat o gwhaar)',
          'سنگت باز جوانیں مردمے انت (Sangat baz jowanen mardume ent)',
        ],
      };
    }

    // 4. Bazaar & Market (میلہ ءُ بازار)
    if (scen.includes('bazaar') || scen.includes('market') || scen.includes('میلہ') || scen.includes('shopping')) {
      if (lastUserMsg.includes('beha') || lastUserMsg.includes('price') || lastUserMsg.includes('chent') || lastUserMsg.includes('how much')) {
        return {
          reply: 'ارزان انت، تئی واستہ براتی رعایت است! کل پنجاہ کلدار جوڑ بیت۔ نوش جان باتے! (Arzan ent, tai waste braati reayat ast! Kull panjah kaldar jor beet. Nosh e jaan baate!)',
          translation: 'It is very affordable, with a special fraternal discount for you! 50 rupees in total. May it nourish you well!',
          hint: 'Say: "Ae zarran ba-zeer" (Take this money) and "Minntwar!"',
          suggestions: [
            'اے زرّاں بہ زیر (Ae zarran ba-zeer - Take this money)',
            'باز منتوار واجہ (Baz minntwar waja)',
            'پدا کایاں (Pada kayan - I will return)',
          ],
        };
      }

      return {
        reply: 'سد منت! چائے شیرگرم ءُ شکرگوں حاص تیار انت، چماٹو هم تازیگ انت۔ گیشتر چے درکار انت واجہ؟ (Sad minnt! Chae sheer-garm o shaker-gon khas tayyar ent, chamato ham tazeg ant. Geshter che darkar ent waja?)',
        translation: 'A hundred thanks! Warm sweet milk tea is freshly brewed, and vegetables are fresh. What else do you need, sir?',
        hint: 'Say: "Behaaei chent?" (What is the price?) or "Yakk cup chae bade" (Give me a cup of tea)',
        suggestions: [
          'بہائی چنت انت؟ (Behaaei chent ent?)',
          'یک کپ چائے بدئے (Yakk cup chae bade)',
          'بس انت، باز منتوار (Bas ent, baz minntwar)',
        ],
      };
    }

    // Fallback Balochi dialogue
    return {
      reply: 'باز جوانیں گپ! بلوچی دربرگ تئی کوشست ستا کڑزیت۔ تو دگہ چے گْوشگے لوٹئے؟ (Baz jowanen gapp! Balochi darbarag tai koshish sata karzet. Tao diga che gwashege lote?)',
      translation: 'Very fine words! Your effort in learning Balochi deserves praise. What else would you like to say?',
      hint: 'Say: "Minntwar!" (Thank you!) or ask "Tao choni?"',
      suggestions: [
        'باز منتوار واجہ (Baz minntwar waja)',
        'تئی منتوار آں (Tai minntwar aan)',
        'پدا گندیں (Pada ginden)',
      ],
    };
  }

  // -------------------------------------------------------------
  // SPANISH CONVERSATION SCENARIOS
  // -------------------------------------------------------------
  if (language === 'spanish') {
    if (scen.includes('café') || scen.includes('restaurant') || scen.includes('cafe')) {
      if (lastUserMsg.includes('café') || lastUserMsg.includes('agua') || lastUserMsg.includes('coffee') || lastUserMsg.includes('por favor')) {
        return {
          reply: '¡Excelente elección! Un café con leche y agua fresca en camino. ¿Deseas algo dulce para acompañar?',
          translation: 'Excellent choice! A coffee with milk and fresh water on the way. Would you like something sweet to go with it?',
          hint: 'Reply: "Sí, una tostada por favor" (Yes, toast please) or "La cuenta, por favor" (The bill, please)',
          suggestions: [
            'Sí, un cruasán por favor',
            'No, gracias, solo eso',
            '¿Cuánto cuesta?',
          ],
        };
      }
      return {
        reply: '¡Buenas tardes! Tenemos café recién tostado y deliciosos zumos. ¿Qué te pongo hoy?',
        translation: 'Good afternoon! We have freshly roasted coffee and delicious juices. What can I get you today?',
        hint: 'Say: "Un café con leche, por favor" (A coffee with milk, please)',
        suggestions: [
          'Un café con leche, por favor',
          'Un vaso de agua fresca',
          '¿Qué me recomiendas?',
        ],
      };
    }

    return {
      reply: '¡Muy bien dicho! Hablas con mucha soltura. ¿Qué más te gustaría practicar hoy?',
      translation: 'Very well said! You speak with great ease. What else would you like to practice today?',
      hint: 'Reply: "Me gustaría aprender más palabras" (I would like to learn more words)',
      suggestions: [
        'Muchas gracias',
        'Hasta luego, amigo',
        'Quiero practicar más',
      ],
    };
  }

  // -------------------------------------------------------------
  // MOROCCAN DARIJA SCENARIOS
  // -------------------------------------------------------------
  if (scen.includes('tea') || scen.includes('cafe') || scen.includes('atay')) {
    return {
      reply: 'مرحبا بيك خويا! هاهو أتاي سخون بالنعناع مشحر على حقو و طريقو. بالصحة و الراحة! (Marhaba bik khoya! Haho atay skhoun b n3na3 mcheher. Bssaha w raha!)',
      translation: 'Welcome brother! Here is piping hot mint tea steeped to perfection. To your health and comfort!',
      hint: 'Reply: "Laykhelik" (God preserve you) or "Bchhal had l-atay?" (How much is this tea?)',
      suggestions: [
        'شكراً بزاف خويا (Chokran bzaf khoya)',
        'الله يعطيك الصحة (Lah y3tik saha)',
        'بشحال هاد أتاي؟ (Bchhal had atay?)',
      ],
    };
  }

  return {
    reply: 'تبارك الله عليك! راك غادي مزيان بزاف. شنو بغيتي نزيدو نهضرو فيه؟ (Tbrakllah alik! Rak ghadi mzyan bzaf. Chno bghiti nzido nhadro fih?)',
    translation: 'Blessings upon you! You are doing very well. What else would you like us to talk about?',
    hint: 'Reply: "Chokran bzaf" (Thank you very much)',
    suggestions: [
      'شكراً بزاف (Chokran bzaf)',
      'بغيت نتعلم كثر (Bghit nt3lem kter)',
      'بالسلامة (Bsslama)',
    ],
  };
}
