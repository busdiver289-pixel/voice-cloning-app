import { LexiconEntry, LexiconPos } from '../types/lexicon';

/**
 * Normalizes Latin text by stripping diacritics and accents for relaxed search,
 * while never modifying the stored canonical text.
 */
export function normalizeLatin(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove combining accents
    .replace(/á/g, 'a')
    .replace(/é/g, 'e')
    .replace(/í/g, 'i')
    .replace(/ó/g, 'o')
    .replace(/ú/g, 'u')
    .replace(/ń/g, 'n')
    .replace(/č/g, 'ch')
    .replace(/š/g, 'sh')
    .replace(/ž/g, 'zh')
    .replace(/ť/g, 't')
    .replace(/ď/g, 'd')
    .trim();
}

/**
 * Normalizes Arabic-script text for search comparison:
 * - strips tashkeel / harakat
 * - standardizes alef variants (آ, أ, إ, ٱ -> ا)
 * - standardizes yeh & kaf variants
 */
export function normalizeArabic(str: string): string {
  if (!str) return '';
  return str
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '') // strip diacritics & tatweel
    .replace(/[آأإٱ]/g, 'ا')
    .replace(/[ىئ]/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/ة/g, 'ہ')
    .replace(/ؤ/g, 'و')
    .replace(/ے/g, 'ی')
    .replace(/ں/g, 'ن')
    .trim();
}

/**
 * Converts internal dictionary POS tags to friendly display labels.
 */
export function getFriendlyPosLabel(pos: LexiconPos): string {
  switch (pos) {
    case 'n':
      return 'noun';
    case 'adj':
      return 'adjective';
    case 'v':
      return 'verb';
    case 'adv':
      return 'adverb';
    case 'prep':
      return 'preposition';
    case 'pron':
      return 'pronoun';
    case 'conj':
      return 'conjunction';
    case 'interj':
      return 'interjection';
    case 'num':
      return 'numeral';
    case 'phrase':
      return 'phrase / idiom';
    case 'affix':
      return 'affix';
    default:
      return 'other';
  }
}

/**
 * High-performance search through the Lexicon supporting:
 * - Balochi Arabic (exact & normalized)
 * - Balochi Latin (exact & relaxed)
 * - English definitions (reverse lookup)
 * - Synonyms & Variants
 * - Domain tags
 * - Partial matching
 */
export function searchLexicon(
  entries: LexiconEntry[],
  query: string,
  options?: {
    domainFilter?: string;
    posFilter?: string;
    statusFilter?: string;
    personalStatuses?: Record<string, string>;
    bookmarkedIds?: string[];
  }
): LexiconEntry[] {
  const q = query.trim();
  const qLower = q.toLowerCase();
  const qNormLatin = normalizeLatin(q);
  const qNormArabic = normalizeArabic(q);

  return entries.filter((entry) => {
    // 1. Domain filter
    if (options?.domainFilter && options.domainFilter !== 'all') {
      const entryDomain = entry.domain?.toLowerCase() || '';
      const hasDefDomain = entry.definitions.some(
        (d) => d.domain?.toLowerCase() === options.domainFilter?.toLowerCase()
      );
      if (entryDomain !== options.domainFilter.toLowerCase() && !hasDefDomain) {
        return false;
      }
    }

    // 2. POS filter
    if (options?.posFilter && options.posFilter !== 'all') {
      if (entry.partOfSpeech !== options.posFilter) {
        return false;
      }
    }

    // 3. Status filter (known, learning, weak, mastered, bookmarked)
    if (options?.statusFilter && options.statusFilter !== 'all') {
      const status = options.personalStatuses?.[entry.id] || 'new';
      if (options.statusFilter === 'bookmarked') {
        if (!options.bookmarkedIds?.includes(entry.id)) return false;
      } else if (options.statusFilter !== status) {
        return false;
      }
    }

    // If no query string, return all matching filters
    if (!q) return true;

    // 4. Arabic matching (Exact & Normalized)
    if (entry.arabic.includes(q) || normalizeArabic(entry.arabic).includes(qNormArabic)) {
      return true;
    }

    // 5. Latin matching (Exact & Relaxed)
    const normEntryLatin = normalizeLatin(entry.latin);
    if (
      entry.latin.toLowerCase().includes(qLower) ||
      normEntryLatin.includes(qNormLatin)
    ) {
      return true;
    }

    // 6. English definitions (Reverse lookup)
    for (const def of entry.definitions) {
      if (
        def.english.toLowerCase().includes(qLower) ||
        (def.scientificName && def.scientificName.toLowerCase().includes(qLower)) ||
        (def.urdu && def.urdu.includes(q))
      ) {
        return true;
      }
    }

    // 7. Synonyms matching
    if (entry.synonyms) {
      for (const syn of entry.synonyms) {
        if (
          syn.arabic.includes(q) ||
          normalizeArabic(syn.arabic).includes(qNormArabic) ||
          syn.latin.toLowerCase().includes(qLower) ||
          normalizeLatin(syn.latin).includes(qNormLatin)
        ) {
          return true;
        }
      }
    }

    // 8. Variants matching
    if (entry.variants) {
      for (const v of entry.variants) {
        if (
          v.arabic.includes(q) ||
          normalizeArabic(v.arabic).includes(qNormArabic) ||
          v.latin.toLowerCase().includes(qLower) ||
          normalizeLatin(v.latin).includes(qNormLatin)
        ) {
          return true;
        }
      }
    }

    // 9. Domain text matching
    if (entry.domain && entry.domain.toLowerCase().includes(qLower)) {
      return true;
    }

    return false;
  });
}
