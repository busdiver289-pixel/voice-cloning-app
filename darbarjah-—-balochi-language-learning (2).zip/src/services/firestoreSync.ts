import {
  doc,
  getDoc,
  setDoc,
  collection,
  getDocs,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile } from '../types';
import { LearnerVocabularyReview } from '../types/review';

/**
 * Fetch a learner's cloud profile from Firestore.
 */
export async function fetchUserProfile(userId: string): Promise<Partial<UserProfile> | null> {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    const snap = await getDoc(userDocRef);
    if (!snap.exists()) {
      return null;
    }
    const data = snap.data();
    return data as Partial<UserProfile>;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Persist learner's profile and progress to Firestore.
 */
export async function saveUserProfile(userId: string, user: UserProfile): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    
    // Construct clean payload strictly adhering to firestore.rules and blueprint
    const payload: Record<string, any> = {
      id: userId,
      username: (user.username || 'Learner').slice(0, 100),
      email: (user.email || '').slice(0, 150),
      fullName: (user.fullName || user.username || '').slice(0, 100),
      authProvider: user.authProvider || 'guest',
      xp: Math.max(0, user.xp || 0),
      level: Math.max(1, user.level || 1),
      streak: Math.max(0, user.streak || 0),
      longestStreak: Math.max(0, user.longestStreak || 0),
      hearts: Math.max(0, user.hearts ?? 5),
      gems: Math.max(0, user.gems || 0),
      dailyGoalXp: Math.max(0, user.dailyGoalXp || 30),
      todayXp: Math.max(0, user.todayXp || 0),
      unlockedLessons: (user.unlockedLessons || ['lesson0_1', 'bal_les_1']).slice(0, 200),
      completedLessons: (user.completedLessons || []).slice(0, 200),
      activeDates: (user.activeDates || []).slice(0, 365),
      claimedAchievements: (user.claimedAchievements || []).slice(0, 100),
      streakFreezeCount: Math.max(0, user.streakFreezeCount || 0),
    };

    await setDoc(userDocRef, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Persist an individual spaced repetition review record
 */
export async function saveVocabularyReviewToFirestore(
  userId: string,
  review: LearnerVocabularyReview
): Promise<void> {
  const safeId = review.lexiconId.replace(/[^a-zA-Z0-9_\-]/g, '_');
  const path = `users/${userId}/reviews/${safeId}`;
  try {
    const reviewRef = doc(db, 'users', userId, 'reviews', safeId);
    const payload = {
      id: safeId,
      userId,
      lexiconId: review.lexiconId,
      masteryScore: review.masteryScore,
      status: review.masteryStatus || 'learning',
      totalAttempts: review.totalAttempts,
      correctAttempts: review.correctAttempts,
      consecutiveCorrect: review.consecutiveCorrect || 0,
      mistakeCount: review.mistakeCount || 0,
      nextReviewAt: review.nextReviewAt,
    };
    await setDoc(reviewRef, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Fetch all spaced repetition reviews for the current user
 */
export async function fetchVocabularyReviewsFromFirestore(
  userId: string
): Promise<Record<string, LearnerVocabularyReview>> {
  const path = `users/${userId}/reviews`;
  try {
    const reviewsColl = collection(db, 'users', userId, 'reviews');
    const snapshot = await getDocs(reviewsColl);
    const result: Record<string, LearnerVocabularyReview> = {};
    snapshot.forEach((d) => {
      const data = d.data() as LearnerVocabularyReview;
      result[data.lexiconId] = data;
    });
    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}
