import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { SUPPORTED_LANGUAGES } from '../data/courses';
import { Lesson, Unit, Exercise } from '../types';
import {
  computeRecommendedNext,
  RecommendationDecision,
} from '../utils/recommendationEngine';
import {
  Check,
  Lock,
  Star,
  Sparkles,
  Zap,
  Target,
  ArrowRight,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Sliders,
  CheckCircle2,
  Award,
  Trophy,
  AlertTriangle,
  RotateCcw,
  Share2,
} from 'lucide-react';

interface CoursePathProps {
  onStartLesson: (lesson: Lesson) => void;
  onOpenPractice: () => void;
  onOpenVocab: () => void;
  onStartCustomExercise?: (exercises: Exercise[], title: string) => void;
  onOpenShareModal?: () => void;
}

export const CoursePath: React.FC<CoursePathProps> = ({
  onStartLesson,
  onOpenPractice,
  onOpenVocab,
  onStartCustomExercise,
  onOpenShareModal,
}) => {
  const {
    activeCourse,
    user,
    weakWords,
    mistakes,
    vocabList,
    updateSettings,
    smartReviewStats,
    startSmartReviewSession,
  } = useApp();
  const [showFormulaBreakdown, setShowFormulaBreakdown] = useState(false);

  const currentLang =
    SUPPORTED_LANGUAGES.find((l) => l.code === user.learningLanguage) ||
    SUPPORTED_LANGUAGES[0];

  const dailyGoalPercent = Math.min(
    100,
    Math.round((user.todayXp / (user.dailyGoalXp || 30)) * 100)
  );

  // Seven-Parameter Recommendation Engine:
  // Completed lessons + Recent mistakes + Vocabulary mastery + Last practice +
  // Current course position + Difficulty + User's preferred practice type = Recommended Next
  const recommendation: RecommendationDecision = useMemo(() => {
    return computeRecommendedNext(
      user,
      activeCourse,
      vocabList,
      weakWords,
      mistakes
    );
  }, [user, activeCourse, vocabList, weakWords, mistakes]);

  const handleLaunchRecommended = () => {
    if (recommendation.actionType === 'lesson' && recommendation.targetLesson) {
      onStartLesson(recommendation.targetLesson);
    } else if (
      recommendation.actionType === 'custom_drill' &&
      recommendation.customExercises
    ) {
      if (onStartCustomExercise) {
        onStartCustomExercise(
          recommendation.customExercises,
          recommendation.title
        );
      } else {
        onOpenPractice();
      }
    } else {
      onOpenPractice();
    }
  };

  const currentPref = user.settings?.preferredPracticeType || 'balanced';

  const handleSelectPreference = (
    type: 'balanced' | 'listening' | 'speaking' | 'quiz'
  ) => {
    updateSettings({ preferredPracticeType: type });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Course Hero Banner */}
      <div className="bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg mb-8 relative overflow-hidden">
        {/* Subtle geometric pattern */}
        <div className="absolute -right-8 -bottom-8 w-48 h-48 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
        <div className="absolute right-6 top-6 text-6xl opacity-15 select-none font-arabic">
          بلوچی
        </div>

        <div className="relative z-10 max-w-xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300 uppercase tracking-wider mb-2">
            <span>{currentLang.flag} {currentLang.name} Track</span>
            <span aria-hidden="true">·</span>
            <span>Section 1 of {activeCourse.sections.length}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display mb-2">
            {activeCourse.title}
          </h1>

          <p className="text-sm text-emerald-100/90 leading-relaxed mb-6">
            Master conversational fluency through bite-sized lessons, native speech listening, voice practice, and real-time feedback.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            {/* Daily Goal bar */}
            <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/15 flex items-center gap-3 text-xs">
              <Target className="w-4 h-4 text-emerald-300 shrink-0" />
              <div>
                <div className="flex items-center justify-between gap-4 font-semibold text-white">
                  <span>Daily Goal</span>
                  <span className="tabular-nums font-mono">
                    {user.todayXp} / {user.dailyGoalXp} XP
                  </span>
                </div>
                <div className="w-32 bg-white/20 h-1.5 rounded-full overflow-hidden mt-1.5">
                  <div
                    className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${dailyGoalPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {weakWords.length > 0 && (
              <button
                onClick={onOpenPractice}
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-400/30 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Review {weakWords.length} Weak Words</span>
              </button>
            )}

            {onOpenShareModal && (
              <button
                onClick={onOpenShareModal}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5 text-emerald-300" />
                <span>Share App (+25 Gems)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Practice / Review Summary Card (Real Learner Data) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs mb-8">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="text-base font-bold text-slate-900 font-display">
              Practice &amp; Review Summary
            </span>
            <span className="text-[10px] font-extrabold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full">
              Live Retention
            </span>
          </div>

          <button
            onClick={() => {
              if (onStartCustomExercise) {
                const ex = startSmartReviewSession(6);
                onStartCustomExercise(ex, 'Darbarjah Smart Review');
              } else {
                onOpenPractice();
              }
            }}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 transition-colors"
          >
            <span>Start Smart Review</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Smart Review */}
          <button
            onClick={() => {
              if (onStartCustomExercise) {
                const ex = startSmartReviewSession(6);
                onStartCustomExercise(ex, 'Darbarjah Smart Review');
              } else {
                onOpenPractice();
              }
            }}
            className="p-3.5 rounded-xl bg-slate-50 hover:bg-emerald-50/60 border border-slate-200 hover:border-emerald-300 transition-all text-left flex items-center justify-between group min-h-[44px]"
          >
            <div>
              <span className="text-xs font-semibold text-slate-500 block">
                Smart Review
              </span>
              <span className="text-lg font-extrabold text-slate-900 font-mono block">
                {smartReviewStats.dueCount} words due
              </span>
              <span className="text-[11px] text-emerald-700 font-medium group-hover:underline">
                Start session →
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
            </div>
          </button>

          {/* Mistake Hub */}
          <button
            onClick={onOpenPractice}
            className="p-3.5 rounded-xl bg-slate-50 hover:bg-rose-50/60 border border-slate-200 hover:border-rose-300 transition-all text-left flex items-center justify-between group min-h-[44px]"
          >
            <div>
              <span className="text-xs font-semibold text-slate-500 block">
                Mistake Hub
              </span>
              <span className="text-lg font-extrabold text-slate-900 font-mono block">
                {smartReviewStats.mistakeCount} words need attention
              </span>
              <span className="text-[11px] text-rose-700 font-medium group-hover:underline">
                View mistakes →
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </button>

          {/* Weak Vocabulary */}
          <button
            onClick={onOpenPractice}
            className="p-3.5 rounded-xl bg-slate-50 hover:bg-amber-50/60 border border-slate-200 hover:border-amber-300 transition-all text-left flex items-center justify-between group min-h-[44px]"
          >
            <div>
              <span className="text-xs font-semibold text-slate-500 block">
                Weak Vocabulary
              </span>
              <span className="text-lg font-extrabold text-slate-900 font-mono block">
                {smartReviewStats.weakCount} words
              </span>
              <span className="text-[11px] text-amber-800 font-medium group-hover:underline">
                Drill weak words →
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
          </button>
        </div>
      </div>

      {/* Seven-Parameter Recommendation Engine: Recommended Next */}
      <div className="bg-gradient-to-r from-emerald-50 via-white to-teal-50/50 rounded-2xl border border-emerald-200/90 p-5 sm:p-6 shadow-sm mb-10 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shrink-0 shadow-md">
              <Zap className="w-6 h-6 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span
                  className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full border ${recommendation.badgeColor}`}
                >
                  {recommendation.badge}
                </span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-xs font-semibold text-slate-500">
                  Priority Score: {recommendation.breakdown.compositeScore}/100
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 font-display">
                {recommendation.title}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {recommendation.subtitle}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl">
                {recommendation.reason}
              </p>

              {/* Preferred Practice Mode Switcher */}
              <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-slate-100 flex-wrap">
                <span className="text-[11px] font-semibold text-slate-400 mr-1 flex items-center gap-1">
                  <Sliders className="w-3 h-3" />
                  Preferred Type:
                </span>
                {(
                  [
                    { id: 'balanced', label: 'Balanced' },
                    { id: 'listening', label: 'Listening' },
                    { id: 'speaking', label: 'Speaking' },
                    { id: 'quiz', label: 'Quiz' },
                  ] as const
                ).map((mode) => {
                  const isActive = currentPref === mode.id;
                  return (
                    <button
                      key={mode.id}
                      onClick={() => handleSelectPreference(mode.id)}
                      className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-all ${
                        isActive
                          ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {mode.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start md:items-end gap-2 shrink-0">
            <button
              onClick={handleLaunchRecommended}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 whitespace-nowrap"
            >
              <span>{recommendation.buttonText}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowFormulaBreakdown(!showFormulaBreakdown)}
              className="text-[11px] font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 self-start md:self-end"
            >
              <span>Formula Factors ({showFormulaBreakdown ? 'Hide' : 'Inspect'})</span>
              {showFormulaBreakdown ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>

        {/* Expandable 7-Parameter Formula Breakdown */}
        {showFormulaBreakdown && (
          <div className="mt-4 pt-4 border-t border-emerald-100 bg-white/80 rounded-xl p-4 text-xs space-y-2">
            <div className="font-bold text-slate-800 mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Recommendation Formula Inputs:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">1. Completed Lessons</span>
                <span>{recommendation.breakdown.completedLessonsNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">2. Recent Mistakes</span>
                <span>{recommendation.breakdown.recentMistakesNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">3. Vocabulary Mastery</span>
                <span>{recommendation.breakdown.vocabMasteryNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">4. Last Practice</span>
                <span>{recommendation.breakdown.lastPracticeNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">5. Current Course Position</span>
                <span>{recommendation.breakdown.coursePositionNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800 block">6. Difficulty</span>
                <span>{recommendation.breakdown.difficultyNote}</span>
              </div>
              <div className="p-2 rounded bg-slate-50 border border-slate-100 sm:col-span-2">
                <span className="font-semibold text-slate-800 block">7. User's Preferred Practice Type</span>
                <span>{recommendation.breakdown.preferredPracticeTypeNote}</span>
              </div>
            </div>
            <div className="text-[11px] text-emerald-800 font-semibold bg-emerald-50 p-2 rounded border border-emerald-100">
              = Recommended Next: {recommendation.title} ({recommendation.subtitle})
            </div>
          </div>
        )}
      </div>

      {/* Course Sections & Units Path */}
      <div className="space-y-12">
        {activeCourse.sections.map((section) => (
          <div key={section.id} className="space-y-6">
            {/* Section Header */}
            <div className="border-b border-slate-200 pb-3 flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 uppercase tracking-wider mb-1">
                  <span>بخش {section.number}</span>
                  <span>·</span>
                  <span>Section {section.number}</span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 font-display">
                  {section.title}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">{section.description}</p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">
                {section.units.length} Units
              </span>
            </div>

            {section.units.map((unit: Unit) => {
              const completedInUnit = unit.lessons.filter((l) =>
                user.completedLessons.includes(l.id)
              ).length;
              const unitProgressPercent = Math.round(
                (completedInUnit / unit.lessons.length) * 100
              );
              const isUnitCompleted = completedInUnit === unit.lessons.length;

              return (
                <div
                  key={unit.id}
                  className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
                >
                  {/* Unit Header */}
                  <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white p-5 sm:p-6">
                    <div className="flex items-start justify-between flex-wrap gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                          <span className="bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                            دَربَند {unit.number} · Unit {unit.number}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="text-slate-300">
                            {unit.lessons.length} Lessons
                          </span>
                        </div>
                        <h3 className="text-lg sm:text-xl font-bold font-display text-white">
                          {unit.title}
                        </h3>
                        <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
                          {unit.description}
                        </p>
                      </div>

                      <button
                        onClick={onOpenVocab}
                        className="text-xs font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/15 rounded-xl px-3.5 py-2 transition-colors flex items-center gap-1.5 shrink-0"
                      >
                        <BookOpen className="w-4 h-4 text-emerald-300" />
                        <span>واژہ نامہ (Unit Vocab)</span>
                      </button>
                    </div>

                    {/* Unit Progress Bar */}
                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-4 text-xs">
                      <div className="flex items-center gap-2 text-slate-300">
                        <span>Progress:</span>
                        <span className="font-bold text-white tabular-nums font-mono">
                          {completedInUnit} / {unit.lessons.length} Lessons Completed
                        </span>
                      </div>
                      <div className="w-32 sm:w-48 bg-white/15 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                          style={{ width: `${unitProgressPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Lesson Nodes Interactive Path - Clean, readable, no overlapping text! */}
                  <div className="p-5 sm:p-8 space-y-4">
                    {unit.lessons.map((lesson, idx) => {
                      const isUnlocked = user.unlockedLessons.includes(lesson.id);
                      const isCompleted = user.completedLessons.includes(lesson.id);
                      const isNext = isUnlocked && !isCompleted;

                      return (
                        <div
                          key={lesson.id}
                          className="w-full bg-white hover:bg-slate-50 border border-slate-200/90 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4 transition-all shadow-xs hover:shadow-md hover:border-emerald-300"
                        >
                          <div className="flex items-center gap-4">
                            <button
                              onClick={() => isUnlocked && onStartLesson(lesson)}
                              disabled={!isUnlocked}
                              className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-all ${
                                isCompleted
                                  ? 'bg-emerald-600 text-white shadow-md ring-4 ring-emerald-100 hover:scale-105'
                                  : isNext
                                  ? 'bg-emerald-600 text-white shadow-lg ring-4 ring-emerald-300 animate-pulse hover:scale-105'
                                  : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                              }`}
                              title={lesson.title}
                            >
                              {isCompleted ? (
                                <Check className="w-6 h-6 stroke-[3]" />
                              ) : isNext ? (
                                <Star className="w-7 h-7 fill-white text-white" />
                              ) : (
                                <Lock className="w-5 h-5 text-slate-400" />
                              )}
                            </button>

                            <div>
                              <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                                  Lesson {idx + 1}
                                </span>
                                {isCompleted && (
                                  <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-0.5">
                                    <CheckCircle2 className="w-3 h-3" /> Mastered
                                  </span>
                                )}
                                {isNext && (
                                  <span className="text-[11px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                                    Up Next
                                  </span>
                                )}
                              </div>
                              <h4 className="text-base font-bold text-slate-900 font-display">
                                {lesson.title}
                              </h4>
                              <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                                {lesson.description}
                              </p>
                              <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                                <span>{lesson.exercises.length} Exercises</span>
                                <span aria-hidden="true">·</span>
                                <span className="text-emerald-700 font-semibold">
                                  +{lesson.xpReward} XP
                                </span>
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => isUnlocked && onStartLesson(lesson)}
                            disabled={!isUnlocked}
                            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                              isNext
                                ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm hover:scale-105'
                                : isCompleted
                                ? 'border border-emerald-600 text-emerald-700 hover:bg-emerald-50'
                                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            <span>
                              {isCompleted ? 'Review' : isNext ? 'Start' : 'Locked'}
                            </span>
                            {isUnlocked && <ArrowRight className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      );
                    })}

                    {/* Unit Milestone Banner */}
                    <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
                      {isUnitCompleted ? (
                        <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/70 border border-emerald-200/80 flex items-center justify-between gap-4 flex-wrap">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
                              <Trophy className="w-5 h-5 text-amber-300 fill-amber-300" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-extrabold uppercase tracking-wide text-emerald-800">
                                  Unit {unit.number} Milestone Unlocked
                                </span>
                                <span className="text-[10px] bg-emerald-200/80 text-emerald-900 font-bold px-2 py-0.5 rounded-full">
                                  100% Mastered
                                </span>
                              </div>
                              <p className="text-xs text-slate-700 mt-0.5">
                                <span className="font-semibold text-emerald-950">Badge:</span> Unit {unit.number} Mastery Badge (دَربَند {unit.number} تمغہ) · All {unit.lessons.length} lessons completed
                              </p>
                              <div className="flex items-center gap-2 text-[11px] text-emerald-800 font-semibold mt-1">
                                <span>+{unit.lessons.reduce((acc, l) => acc + l.xpReward, 0)} XP Earned</span>
                                <span>·</span>
                                <span className="text-slate-500">Mastery Progress: 100%</span>
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => onStartLesson(unit.lessons[0])}
                            className="font-bold text-emerald-800 hover:text-emerald-900 flex items-center gap-1.5 transition-colors px-3.5 py-2 rounded-xl bg-white hover:bg-emerald-50 border border-emerald-300 text-xs shadow-xs"
                          >
                            <span>دَربَند ءِ آزمائشت (Review Unit)</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between text-xs text-slate-500 flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                            <span>
                              Complete all {unit.lessons.length} lessons to earn the Unit {unit.number} Mastery Badge
                            </span>
                          </div>

                          <button
                            onClick={() => onStartLesson(unit.lessons[0])}
                            className="font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 transition-colors px-3 py-1.5 rounded-lg hover:bg-emerald-50 border border-emerald-200"
                          >
                            <span>Start Unit Lessons</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
