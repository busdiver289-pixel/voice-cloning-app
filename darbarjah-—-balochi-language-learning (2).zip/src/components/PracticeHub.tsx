import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Exercise } from '../types';
import { LexiconEntry } from '../types/lexicon';
import { LearnerVocabularyReview } from '../types/review';
import { hasRecoveredFromMistakes, MS_IN_DAY } from '../utils/smartReviewScheduler';
import { createLexiconQuizExercises } from '../utils/lexiconQuiz';
import { LexiconDetailModal } from './LexiconDetailModal';
import {
  Zap,
  RotateCcw,
  Volume2,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  BookOpen,
  AlertTriangle,
  Clock,
  ExternalLink,
  Flame,
  Award,
  Filter,
} from 'lucide-react';

interface PracticeHubProps {
  onStartCustomExercise: (exercises: Exercise[], title: string) => void;
}

type MistakeHubTab = 'mistakes' | 'weak' | 'recent' | 'due' | 'mastered';

export const PracticeHub: React.FC<PracticeHubProps> = ({ onStartCustomExercise }) => {
  const {
    vocabList,
    weakWords,
    mistakes,
    user,
    lexiconEntries,
    vocabularyReviews,
    detailedMistakes,
    smartReviewStats,
    startSmartReviewSession,
  } = useApp();

  const [activeTab, setActiveTab] = useState<MistakeHubTab>('mistakes');
  const [selectedLexiconEntry, setSelectedLexiconEntry] = useState<LexiconEntry | null>(null);

  // Map of canonical lexicon entries by ID for fast lookup
  const lexiconMap = useMemo(() => {
    const map = new Map<string, LexiconEntry>();
    lexiconEntries.forEach((e) => map.set(e.id, e));
    return map;
  }, [lexiconEntries]);

  // Launch the primary Smart Review workout
  const handleLaunchSmartReview = () => {
    const exercises = startSmartReviewSession(6);
    onStartCustomExercise(exercises, 'Darbarjah Smart Review');
  };

  // Launch targeted single-word drill
  const handleStartSingleWordPractice = (entry: LexiconEntry) => {
    const exercises = createLexiconQuizExercises(entry, lexiconEntries);
    onStartCustomExercise(exercises, `Drill: ${entry.arabic} (${entry.latin})`);
  };

  // Helper to format review status
  const getReviewStatusLabel = (review?: LearnerVocabularyReview) => {
    if (!review) return { label: 'New', color: 'text-slate-500 bg-slate-100 border-slate-200' };
    const now = Date.now();
    const diffMs = review.nextReviewAt - now;

    if (diffMs <= 0) {
      const overdueDays = Math.floor(-diffMs / MS_IN_DAY);
      if (overdueDays > 0) {
        return {
          label: `Overdue by ${overdueDays}d`,
          color: 'text-rose-700 bg-rose-50 border-rose-200',
        };
      }
      return {
        label: 'Due Today',
        color: 'text-amber-800 bg-amber-50 border-amber-200 font-bold',
      };
    }

    const daysLeft = Math.ceil(diffMs / MS_IN_DAY);
    if (daysLeft === 1) {
      return {
        label: 'Due Tomorrow',
        color: 'text-blue-700 bg-blue-50 border-blue-200',
      };
    }
    return {
      label: `Due in ${daysLeft} days`,
      color: 'text-slate-600 bg-slate-50 border-slate-200',
    };
  };

  // Build items list according to the active Mistake Hub filter
  const filteredHubItems = useMemo(() => {
    const now = Date.now();
    const allReviews = Object.values(vocabularyReviews);

    // Map reviews to corresponding lexicon entries
    const items = allReviews
      .map((rev) => ({
        review: rev,
        entry: lexiconMap.get(rev.lexiconId),
      }))
      .filter((item): item is { review: LearnerVocabularyReview; entry: LexiconEntry } => !!item.entry);

    switch (activeTab) {
      case 'mistakes':
        // Mistakes to review: items with mistake history that have not yet recovered
        return items
          .filter((i) => i.review.mistakeCount > 0 && !hasRecoveredFromMistakes(i.review))
          .sort((a, b) => b.review.mistakeCount - a.review.mistakeCount);

      case 'weak':
        // Weak words: mastery score < 50 or flagged as weak
        return items
          .filter((i) => i.review.masteryStatus === 'weak' || i.review.masteryScore < 50)
          .sort((a, b) => a.review.masteryScore - b.review.masteryScore);

      case 'recent':
        // Recently missed: sort by lastIncorrectAt descending
        return items
          .filter((i) => !!i.review.lastIncorrectAt)
          .sort((a, b) => (b.review.lastIncorrectAt || 0) - (a.review.lastIncorrectAt || 0));

      case 'due':
        // Due today: nextReviewAt <= now
        return items
          .filter((i) => i.review.nextReviewAt <= now)
          .sort((a, b) => a.review.nextReviewAt - b.review.nextReviewAt);

      case 'mastered':
        // Mastered: masteryStatus === 'mastered'
        return items
          .filter((i) => i.review.masteryStatus === 'mastered')
          .sort((a, b) => b.review.masteryScore - a.review.masteryScore);

      default:
        return items;
    }
  }, [vocabularyReviews, lexiconMap, activeTab]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* 1. HERO BANNER: START SMART REVIEW */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-700/60 mb-8 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-3 py-0.5 rounded-full border border-emerald-400/30">
                Spaced Repetition Engine
              </span>
              <span className="text-xs text-slate-300 font-medium">Phase 1 Foundation</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-display text-white">
              Smart Review & Mistake Hub
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Target due vocabulary, correct repeated mistakes, and reinforce low-retention words based on deterministic memory intervals.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row md:flex-col items-stretch sm:items-center md:items-end gap-3 shrink-0">
            <button
              onClick={handleLaunchSmartReview}
              className="px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm sm:text-base shadow-lg shadow-emerald-900/30 flex items-center justify-center gap-2.5 transition-all active:scale-95"
            >
              <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
              <span>START SMART REVIEW</span>
            </button>
            <span className="text-center sm:text-right text-xs text-emerald-300 font-semibold">
              {smartReviewStats.dueCount} words ready for review
            </span>
          </div>
        </div>

        {/* Real Dynamic Learner Metrics Grid */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              Due Today
            </span>
            <span className="text-xl sm:text-2xl font-extrabold text-amber-300 font-mono">
              {smartReviewStats.dueCount}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Spaced schedule</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              Mistakes Active
            </span>
            <span className="text-xl sm:text-2xl font-extrabold text-rose-400 font-mono">
              {smartReviewStats.mistakeCount}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Need attention</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              Weak Vocabulary
            </span>
            <span className="text-xl sm:text-2xl font-extrabold text-orange-300 font-mono">
              {smartReviewStats.weakCount}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Score &lt; 50%</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              Mastered Words
            </span>
            <span className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-mono">
              {smartReviewStats.masteredCount}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Long-term memory</span>
          </div>
        </div>
      </div>

      {/* 2. MISTAKE HUB NAVIGATION TABS */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-display">
              Mistake Hub
            </h2>
            <span className="text-xs text-slate-500">
              ({filteredHubItems.length} items in view)
            </span>
          </div>
          <span className="text-xs text-slate-400 italic">
            Items graduate when recovered (2+ correct &amp; score ≥ 70%)
          </span>
        </div>

        {/* 5 Distinct Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-2xl border border-slate-300/80 overflow-x-auto max-w-full">
          {(
            [
              { id: 'mistakes', label: 'Mistakes to Review', count: smartReviewStats.mistakeCount },
              { id: 'weak', label: 'Weak Words', count: smartReviewStats.weakCount },
              { id: 'recent', label: 'Recently Missed', count: detailedMistakes.length },
              { id: 'due', label: 'Due Today', count: smartReviewStats.dueCount },
              { id: 'mastered', label: 'Mastered', count: smartReviewStats.masteredCount },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 shrink-0 min-h-[44px] ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeTab === tab.id
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-300/80 text-slate-700'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 3. VOCABULARY CARDS LIST */}
      {filteredHubItems.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredHubItems.map(({ review, entry }) => {
            const statusInfo = getReviewStatusLabel(review);
            const isRecovered = hasRecoveredFromMistakes(review);

            return (
              <div
                key={entry.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar: Mastery Badge, Review Status & Mistake Count */}
                  <div className="flex items-start justify-between gap-2 mb-2 flex-wrap">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* Mastery State Pill */}
                      <span
                        className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md border ${
                          review.masteryStatus === 'mastered'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : review.masteryStatus === 'practicing'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : review.masteryStatus === 'weak'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {review.masteryStatus} ({review.masteryScore}%)
                      </span>

                      {/* Review Status Pill */}
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border flex items-center gap-1 ${statusInfo.color}`}
                      >
                        <Clock className="w-3 h-3" />
                        <span>{statusInfo.label}</span>
                      </span>

                      {/* Mistake Count */}
                      {review.mistakeCount > 0 && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-100 text-rose-900 border border-rose-300 flex items-center gap-0.5">
                          <AlertTriangle className="w-3 h-3 text-rose-600" />
                          <span>{review.mistakeCount} error{review.mistakeCount > 1 ? 's' : ''}</span>
                        </span>
                      )}

                      {/* Recovered Badge */}
                      {review.mistakeCount > 0 && isRecovered && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-0.5">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Recovered</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Word Display */}
                  <div className="my-2">
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-2xl font-bold font-arabic text-slate-900">
                        {entry.arabic}
                      </h3>
                      <span className="text-sm font-mono font-semibold text-emerald-800">
                        ({entry.latin})
                      </span>
                    </div>

                    {/* Documented Meaning (Multiple meanings supported) */}
                    <div className="mt-1 space-y-1">
                      {entry.definitions.map((def, idx) => (
                        <p key={idx} className="text-xs text-slate-700 line-clamp-1">
                          <span className="font-semibold text-slate-900">
                            {entry.definitions.length > 1 ? `${idx + 1}. ` : ''}
                            {def.english}
                          </span>
                          {def.urdu && <span className="text-slate-400 font-arabic ml-1">· {def.urdu}</span>}
                        </p>
                      ))}
                    </div>
                  </div>

                  {/* Spaced repetition consecutive correct progress */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                    <span>
                      Consecutive correct: <strong className="text-slate-800 font-mono">{review.consecutiveCorrect}</strong>
                    </span>
                    <span>
                      Attempts: <strong className="text-slate-800 font-mono">{review.correctAttempts}/{review.totalAttempts}</strong>
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 mt-3">
                  <button
                    onClick={() => setSelectedLexiconEntry(entry)}
                    className="text-xs font-semibold text-slate-600 hover:text-emerald-700 flex items-center gap-1 min-h-[44px] px-2"
                  >
                    <span>Open Dictionary</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleStartSingleWordPractice(entry)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors min-h-[44px]"
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-300" />
                    <span>Practice Word</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 font-display">
            {activeTab === 'mistakes'
              ? 'No active mistakes requiring review!'
              : activeTab === 'weak'
              ? 'No weak words detected!'
              : activeTab === 'due'
              ? 'All reviews up to date!'
              : activeTab === 'recent'
              ? 'No recent mistakes logged!'
              : 'No mastered vocabulary yet.'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {activeTab === 'mistakes'
              ? 'Words appear here whenever an answer is incorrect, and graduate once answered correctly twice with high mastery.'
              : 'Keep completing lessons and practicing to track your retention.'}
          </p>
          <button
            onClick={handleLaunchSmartReview}
            className="mt-2 px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-xs hover:bg-emerald-700"
          >
            Start Smart Review Session
          </button>
        </div>
      )}

      {/* Dictionary Detail Modal */}
      <LexiconDetailModal
        entry={selectedLexiconEntry}
        isOpen={!!selectedLexiconEntry}
        onClose={() => setSelectedLexiconEntry(null)}
        onStartPracticeWord={(entry) => {
          setSelectedLexiconEntry(null);
          handleStartSingleWordPractice(entry);
        }}
      />
    </div>
  );
};
