import React from 'react';
import { LexiconEntry } from '../types/lexicon';
import { useApp } from '../context/AppContext';
import { getFriendlyPosLabel } from '../utils/lexiconSearch';
import {
  X,
  Volume2,
  Bookmark,
  Plus,
  Check,
  Zap,
  BookOpen,
  ArrowRight,
  Sparkles,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';

interface LexiconDetailModalProps {
  entry: LexiconEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectReferenceWord?: (arabicOrLatin: string) => void;
  onStartPracticeWord?: (entry: LexiconEntry) => void;
}

export const LexiconDetailModal: React.FC<LexiconDetailModalProps> = ({
  entry,
  isOpen,
  onClose,
  onSelectReferenceWord,
  onStartPracticeWord,
}) => {
  const {
    getLexiconStatus,
    addToLearningQueue,
    removeFromLearningQueue,
    toggleBookmarkLexicon,
  } = useApp();

  if (!isOpen || !entry) return null;

  const status = getLexiconStatus(entry.id);

  const getStatusBadge = () => {
    switch (status.status) {
      case 'mastered':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
            Mastered ({status.score}%)
          </span>
        );
      case 'learning':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
            In Learning Queue ({status.score}%)
          </span>
        );
      case 'weak':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200">
            Needs Review / Weak ({status.score}%)
          </span>
        );
      default:
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
            Dictionary Entry (New)
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col">
        {/* Modal Top Bar */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between bg-gradient-to-r from-emerald-50/50 via-white to-teal-50/30">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider bg-slate-800 text-white px-2.5 py-0.5 rounded-md">
                {getFriendlyPosLabel(entry.partOfSpeech)}
              </span>
              {entry.domain && (
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-emerald-100 text-emerald-900 border border-emerald-200 capitalize">
                  {entry.domain}
                </span>
              )}
              {getStatusBadge()}
            </div>

            {/* Arabic Headword (Large typography) */}
            <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-950 font-arabic tracking-wide my-1">
              {entry.arabic}
            </h2>

            {/* Latin Canonical Spelling */}
            <p className="text-base sm:text-lg font-semibold text-emerald-800 font-mono tracking-tight">
              {entry.latin}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleBookmarkLexicon(entry.id)}
              className={`p-2 rounded-xl border transition-colors ${
                status.isBookmarked
                  ? 'bg-amber-50 border-amber-300 text-amber-500'
                  : 'bg-white border-slate-200 text-slate-400 hover:text-slate-600'
              }`}
              title={status.isBookmarked ? 'Remove bookmark' : 'Bookmark word'}
            >
              <Bookmark className={`w-5 h-5 ${status.isBookmarked ? 'fill-amber-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 space-y-6 flex-1">
          {/* Definitions Section (Supports Multiple Meanings) */}
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
              <span>English Definitions ({entry.definitions.length})</span>
            </h3>

            <div className="space-y-3">
              {entry.definitions.map((def, idx) => (
                <div
                  key={def.id || idx}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-start gap-3"
                >
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div className="flex-1">
                    <p className="text-slate-900 font-semibold text-base leading-snug">
                      {def.english}
                    </p>
                    {def.scientificName && (
                      <p className="text-xs font-serif italic text-slate-500 mt-0.5">
                        Scientific: {def.scientificName}
                      </p>
                    )}
                    {def.urdu && (
                      <p className="text-xs font-arabic text-slate-500 mt-1">
                        اردو: {def.urdu}
                      </p>
                    )}
                    {def.domain && (
                      <span className="inline-block mt-2 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                        {def.domain}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Synonyms */}
          {entry.synonyms && entry.synonyms.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Synonyms (syn.)
              </h4>
              <div className="flex flex-wrap gap-2">
                {entry.synonyms.map((syn, i) => (
                  <button
                    key={i}
                    onClick={() => onSelectReferenceWord && onSelectReferenceWord(syn.latin || syn.arabic)}
                    className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <span className="font-arabic text-sm">{syn.arabic}</span>
                    <span className="font-mono text-[11px] text-blue-700">({syn.latin})</span>
                    <ExternalLink className="w-3 h-3 text-blue-500" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Variants */}
          {entry.variants && entry.variants.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Documented Variants (var.)
              </h4>
              <div className="flex flex-wrap gap-2">
                {entry.variants.map((v, i) => {
                  const variant = v as any;
                  return (
                    <button
                      key={i}
                      onClick={() => onSelectReferenceWord && onSelectReferenceWord(v.latin || v.arabic)}
                      className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <span className="font-arabic text-sm">{v.arabic}</span>
                      <span className="font-mono text-[11px] text-amber-700">({v.latin})</span>
                      {variant.region && (
                        <span className="text-[9px] bg-amber-200/80 text-amber-950 font-bold px-1.5 py-0.2 rounded font-sans">
                          {variant.region}
                        </span>
                      )}
                      {variant.relationshipType && variant.relationshipType !== 'variant_of' && (
                        <span className="text-[9px] text-amber-800 italic">
                          {variant.relationshipType.replace(/_/g, ' ')}
                        </span>
                      )}
                      <ExternalLink className="w-3 h-3 text-amber-500" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Cross References */}
          {entry.crossReferences && entry.crossReferences.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Cross-References
              </h4>
              <div className="space-y-1.5">
                {entry.crossReferences.map((ref, i) => (
                  <div
                    key={i}
                    className="text-xs text-slate-600 flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/60"
                  >
                    <span className="font-medium">
                      {ref.type?.replace('_', ' ')}: <span className="font-arabic text-slate-900 font-bold">{ref.arabic}</span> ({ref.latin})
                    </span>
                    {ref.note && <span className="text-[11px] text-slate-400">{ref.note}</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Example Sentences */}
          {entry.examples && entry.examples.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Usage Examples
              </h4>
              <div className="space-y-2">
                {entry.examples.map((ex, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                    <p className="text-sm font-arabic font-bold text-slate-900">{ex.arabic}</p>
                    <p className="font-mono text-emerald-800 text-[11px]">{ex.latin}</p>
                    <p className="text-slate-600 italic font-sans">{ex.english}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Audio Section (Requirement 1, 2, 3 & 6: Distinct states for authentic, ai_preview, and unavailable) */}
          {entry.audio?.type === 'authentic_recording' && entry.audio.url ? (
            /* State 1: Authentic Native Recording */
            <div className="p-4 rounded-2xl bg-emerald-50/80 border-2 border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl" role="img" aria-label="microphone">🎙️</span>
                  <div>
                    <span className="text-sm font-extrabold text-emerald-950 block">
                      Verified native recording
                    </span>
                    <span className="text-[11px] text-emerald-700 font-medium">
                      Authentic Balochi speaker recording
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (entry.audio?.url) {
                      const audio = new Audio(entry.audio.url);
                      audio.play();
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-sm flex items-center gap-1.5 active:scale-95"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Play Native Recording</span>
                </button>
              </div>

              {/* Verified Recording Metadata */}
              {(entry.audio.speaker || entry.audio.source || entry.audio.dialect || entry.audio.recordingDate) && (
                <div className="pt-2.5 border-t border-emerald-200/60 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-emerald-900">
                  {entry.audio.speaker && (
                    <div>
                      <span className="text-emerald-700 font-semibold block text-[10px] uppercase tracking-wider">Speaker:</span>
                      <span className="font-medium">{entry.audio.speaker}</span>
                    </div>
                  )}
                  {entry.audio.source && (
                    <div>
                      <span className="text-emerald-700 font-semibold block text-[10px] uppercase tracking-wider">Source / Fieldwork:</span>
                      <span className="font-medium">{entry.audio.source}</span>
                    </div>
                  )}
                  {entry.audio.dialect && (
                    <div>
                      <span className="text-emerald-700 font-semibold block text-[10px] uppercase tracking-wider">Dialect / Region:</span>
                      <span className="font-medium">{entry.audio.dialect}</span>
                    </div>
                  )}
                  {entry.audio.recordingDate && (
                    <div>
                      <span className="text-emerald-700 font-semibold block text-[10px] uppercase tracking-wider">Recording Date:</span>
                      <span className="font-medium">{entry.audio.recordingDate}</span>
                    </div>
                  )}
                  {entry.audio.verified && (
                    <div className="sm:col-span-2 flex items-center gap-1 text-emerald-800 font-semibold text-[10px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Authenticity verified by Balochi linguistic archive</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : entry.audio?.type === 'ai_preview' ? (
            /* State 2: AI Pronunciation Preview */
            <div className="p-4 rounded-2xl bg-violet-50/80 border-2 border-violet-300 space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl" role="img" aria-label="robot">🤖</span>
                  <div>
                    <span className="text-sm font-extrabold text-violet-950 block">
                      AI pronunciation preview
                    </span>
                    <span className="text-xs font-bold text-rose-700 block">
                      Not a native recording.
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (entry.audio?.url) {
                      const audio = new Audio(entry.audio.url);
                      audio.play();
                    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                      window.speechSynthesis.cancel();
                      const utt = new SpeechSynthesisUtterance(entry.latin);
                      utt.rate = 0.85;
                      window.speechSynthesis.speak(utt);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs transition-all shadow-sm flex items-center gap-1.5 active:scale-95"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Play AI Preview</span>
                </button>
              </div>

              <p className="text-[11px] text-violet-900 leading-relaxed bg-white/60 p-2.5 rounded-xl border border-violet-200/60">
                <span className="font-bold">Synthetic Notice:</span> Machine-generated speech preview based on standardized Latin phonetics ({entry.latin}). Does not reflect authentic Balochi native speaker tone, cadence, or morphology.
              </p>
            </div>
          ) : (
            /* State 3: Unavailable */
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl" role="img" aria-label="muted">🔇</span>
                  <div>
                    <span className="text-sm font-bold text-slate-800 block">
                      Audio not available yet
                    </span>
                    <span className="text-[11px] text-slate-500">
                      No authentic field recording on file for this entry.
                    </span>
                  </div>
                </div>

                <span className="text-[11px] font-semibold text-slate-600 bg-slate-200/80 px-2.5 py-1 rounded-lg">
                  Awaiting Native Recording
                </span>
              </div>

              {/* Optional non-authentic romanized TTS preview */}
              <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
                <span className="text-slate-400 italic">
                  Preview Latin phonetics ({entry.latin}):
                </span>
                <button
                  onClick={() => {
                    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                      window.speechSynthesis.cancel();
                      const utt = new SpeechSynthesisUtterance(entry.latin);
                      utt.rate = 0.85;
                      window.speechSynthesis.speak(utt);
                    }
                  }}
                  className="px-2.5 py-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-medium text-[11px] self-start sm:self-auto transition-colors flex items-center gap-1 shrink-0"
                  title="Experimental machine-generated speech preview. Not authentic Balochi."
                >
                  <Volume2 className="w-3 h-3 text-slate-500" />
                  <span>TTS Preview (Non-authentic)</span>
                </button>
              </div>
            </div>
          )}

          {/* Source Traceability Metadata (Requirement 3) */}
          {(entry.sourceBook || entry.sourcePage) && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60 text-[11px] text-slate-500 flex items-center justify-between">
              <span className="font-semibold text-slate-600">
                Source: {entry.sourceBook || 'Balochi Labzbalad (Ishaque Khamosh, 2014)'}
              </span>
              {entry.sourcePage && (
                <span className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-[10px] text-slate-700">
                  Page {entry.sourcePage}
                </span>
              )}
            </div>
          )}

          {/* Repair Audit Trail (Requirement 3: Never silently overwrite uncertain source data) */}
          {entry.repairAudit && (
            <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200/80 text-[11px] text-amber-900 space-y-1">
              <div className="flex items-center justify-between font-bold text-amber-800">
                <span>Data Quality Repair Traceability</span>
                <span className="font-mono text-[10px] bg-amber-200/60 px-1.5 py-0.5 rounded">
                  {entry.repairAudit.sourceFile}
                </span>
              </div>
              <p className="text-[11px] text-amber-800">
                <span className="font-semibold">Original Imported:</span>{' '}
                <code className="bg-amber-100 px-1 py-0.5 rounded font-mono text-rose-800">
                  {entry.repairAudit.originalImportedValue}
                </code>{' '}
                → <span className="font-semibold">Corrected:</span>{' '}
                <code className="bg-emerald-100 text-emerald-900 px-1 py-0.5 rounded font-mono font-bold">
                  {entry.repairAudit.correctedValue}
                </code>
              </p>
              <p className="text-[10px] text-amber-700 italic">{entry.repairAudit.note}</p>
            </div>
          )}
        </div>

        {/* Modal Bottom Actions */}
        <div className="p-6 border-t border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row items-center justify-between gap-3">
          {status.isInQueue ? (
            <button
              onClick={() => removeFromLearningQueue(entry.id)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-rose-50 hover:border-rose-200 text-slate-700 hover:text-rose-600 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4 text-emerald-600" />
              <span>In Learning Queue (Remove)</span>
            </button>
          ) : (
            <button
              onClick={() => addToLearningQueue(entry.id)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Learn this word (Add to Queue)</span>
            </button>
          )}

          <button
            onClick={() => {
              if (onStartPracticeWord) {
                onStartPracticeWord(entry);
                onClose();
              }
            }}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-1.5"
          >
            <Zap className="w-4 h-4 text-amber-300" />
            <span>Practice this Word Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
