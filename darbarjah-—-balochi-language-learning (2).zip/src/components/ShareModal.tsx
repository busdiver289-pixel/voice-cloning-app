import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Send,
  Facebook,
  Twitter,
  Smartphone,
  Sparkles,
  Award,
} from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Canonical share URL and referral text
  const shareUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}?ref=invite`
      : 'https://ais-pre-yssn5uvp4b7q6jvdyqzayh-665453306617.asia-southeast1.run.app';

  const shareTitle = 'Darbarjah — Learn the Balochi Language (دَربَرجاہ)';
  const shareText =
    'Join me on Darbarjah to learn Balochi! Master vocabulary, pronunciation, native script, and daily conversation for free:';

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback manual copy
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
      } catch {
        // Ignored if cancelled
      }
    } else {
      handleCopyLink();
    }
  };

  const socialLinks = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-emerald-500 hover:bg-emerald-600 text-white',
      url: `https://api.whatsapp.com/send?text=${encodeURIComponent(
        `${shareText}\n${shareUrl}`
      )}`,
    },
    {
      name: 'Telegram',
      icon: Send,
      color: 'bg-sky-500 hover:bg-sky-600 text-white',
      url: `https://t.me/share/url?url=${encodeURIComponent(
        shareUrl
      )}&text=${encodeURIComponent(shareText)}`,
    },
    {
      name: 'X (Twitter)',
      icon: Twitter,
      color: 'bg-slate-900 hover:bg-slate-800 text-white',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(
        shareText
      )}&url=${encodeURIComponent(shareUrl)}`,
    },
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-600 hover:bg-blue-700 text-white',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
        shareUrl
      )}`,
    },
    {
      name: 'SMS / Text',
      icon: Smartphone,
      color: 'bg-amber-600 hover:bg-amber-700 text-white',
      url: `sms:?body=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden relative">
        {/* Header */}
        <div className="bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
              Community Sharing
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shrink-0">
              <Share2 className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display text-white">
                Share Darbarjah
              </h2>
              <p className="text-xs text-slate-300">
                Invite friends and family to preserve and learn Balochi!
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Referral Bonus Card */}
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-200/80 text-amber-900 flex items-center justify-center shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div className="text-xs">
              <span className="font-bold text-amber-950 block">
                Share &amp; Earn 25 Gems 💎
              </span>
              <span className="text-amber-800 text-[11px]">
                Both you and your invited friends get bonus gems upon joining.
              </span>
            </div>
          </div>

          {/* Copy Link Section */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1.5">
              Your Personal Sharing Link
            </label>
            <div className="flex items-center gap-2 p-1.5 rounded-2xl border border-slate-200 bg-slate-50 focus-within:border-emerald-500">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 bg-transparent px-3 py-1.5 text-xs text-slate-700 font-mono focus:outline-none select-all truncate"
              />
              <button
                onClick={handleCopyLink}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Link</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 1-Tap Social Share Channels */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-2">
              Share Directly via Apps
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {socialLinks.map((item) => {
                const Icon = item.icon;
                return (
                  <a
                    key={item.name}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`p-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-xs active:scale-95 ${item.color}`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </a>
                );
              })}
            </div>
          </div>

          {/* Device Native Share (if supported) */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              onClick={handleNativeShare}
              className="w-full py-3 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50 text-slate-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <Share2 className="w-4 h-4 text-emerald-700" />
              <span>More Share Options (Nearby, AirDrop, Messages)</span>
            </button>
          )}

          <div className="pt-2 text-center">
            <span className="text-[11px] text-slate-400 italic">
              «بلوچی مئے وتی شیرکَنیں زُبان اِنت» — Balochi is our sweet mother tongue
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
