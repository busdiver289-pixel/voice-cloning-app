import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Exercise, Lesson, MatchingPair } from '../types';
import { LexiconEntry } from '../types/lexicon';
import { LexiconDetailModal } from './LexiconDetailModal';
import { checkAnswer, CheckResult } from '../utils/answerChecker';
import { playSoundEffect, playSpeech } from '../utils/audio';
import { startSpeechRecognition, evaluateSpeechAccuracy, isSpeechRecognitionSupported, isSpeechRecognitionSupportedForLanguage } from '../utils/speech';
import {
  X,
  Heart,
  Volume2,
  Turtle,
  Mic,
  MicOff,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  HelpCircle,
  Loader2,
  ArrowRight,
  Flame,
  Star,
  RefreshCw,
  BookOpen,
  Award,
  Trophy,
} from 'lucide-react';

interface LessonModalProps {
  lesson: Lesson;
  onClose: () => void;
  onFinish: () => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  lesson,
  onClose,
  onFinish,
}) => {
  const { user, completeLesson, loseHeart, logMistake, lexiconEntries, activeCourse, recordReviewAttempt } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [exercises, setExercises] = useState<Exercise[]>(lesson.exercises);
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [typedAnswer, setTypedAnswer] = useState<string>('');
  const [selectedTokens, setSelectedTokens] = useState<string[]>([]);
  const [availableTokens, setAvailableTokens] = useState<string[]>([]);

  // Matching exercise state
  const [matchingPairs, setMatchingPairs] = useState<MatchingPair[]>([]);
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [wrongMatch, setWrongMatch] = useState<{ left: string; right: string } | null>(null);

  // Speaking exercise state
  const [isRecording, setIsRecording] = useState(false);
  const [speechTranscript, setSpeechTranscript] = useState<string>('');
  const [speakingAccuracy, setSpeakingAccuracy] = useState<number | null>(null);
  const recognitionRef = useRef<{ stop: () => void } | null>(null);

  // Checking & Feedback state
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [mistakeList, setMistakeList] = useState<Exercise[]>([]);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showQuitConfirm, setShowQuitConfirm] = useState(false);

  // In-Lesson Dictionary Lookup state
  const [selectedDictionaryEntry, setSelectedDictionaryEntry] = useState<LexiconEntry | null>(null);

  // AI Explanation Drawer state
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);

  // Lesson Finished Summary State
  const [isFinished, setIsFinished] = useState(false);

  const currentExercise = exercises[currentIndex];
  const progressPercent = Math.round((currentIndex / exercises.length) * 100);

  const matchingLexicon = lexiconEntries.find(
    (e) =>
      (currentExercise?.targetText &&
        (e.arabic === currentExercise.targetText || e.headword === currentExercise.targetText)) ||
      (currentExercise?.audioText && e.latin.toLowerCase() === currentExercise.audioText.toLowerCase())
  );
  const hasAuthenticRecording =
    matchingLexicon?.audio?.type === 'authentic_recording' && !!matchingLexicon.audio.url;

  // Reset exercise-specific states on step change
  useEffect(() => {
    setSelectedOption('');
    setTypedAnswer('');
    setIsSubmitted(false);
    setResult(null);
    setSpeechTranscript('');
    setSpeakingAccuracy(null);
    setSelectedLeft(null);
    setWrongMatch(null);
    setAiExplanation(null);

    if (currentExercise) {
      if (currentExercise.wordBank) {
        setAvailableTokens([...currentExercise.wordBank]);
        setSelectedTokens([]);
      }
      if (currentExercise.matchingPairs) {
        setMatchingPairs([...currentExercise.matchingPairs]);
        setMatchedIds([]);
      }
      // Auto-play audio if enabled
      if (user.settings.autoPlayAudio && currentExercise.audioText) {
        playSpeech(currentExercise.audioText, user.learningLanguage, {
          useGemini: user.settings.useGeminiVoice,
        });
      }
    }
  }, [currentIndex, currentExercise, user.settings.autoPlayAudio, user.settings.useGeminiVoice, user.learningLanguage]);

  const handleOpenDictionary = (queryText?: string) => {
    if (!lexiconEntries || lexiconEntries.length === 0) return;

    if (queryText) {
      const clean = queryText.replace(/[?؟،!.]/g, '').trim();
      const exactMatch = lexiconEntries.find(
        (e) =>
          e.arabic === clean ||
          e.headword === clean ||
          e.latin.toLowerCase() === clean.toLowerCase()
      );
      if (exactMatch) {
        setSelectedDictionaryEntry(exactMatch);
        return;
      }

      // Try word tokens
      const words = clean.split(/\s+/);
      for (const w of words) {
        if (w.length > 1) {
          const match = lexiconEntries.find(
            (e) =>
              e.arabic === w ||
              e.headword === w ||
              e.latin.toLowerCase() === w.toLowerCase()
          );
          if (match) {
            setSelectedDictionaryEntry(match);
            return;
          }
        }
      }
    }

    // Try targetWordIds
    if (lesson.targetWordIds && lesson.targetWordIds.length > 0) {
      const firstTarget = lesson.targetWordIds[0];
      const match = lexiconEntries.find(
        (e) => e.id === firstTarget || e.id === `lex_${firstTarget}` || firstTarget.includes(e.id)
      );
      if (match) {
        setSelectedDictionaryEntry(match);
        return;
      }
    }

    // Fallback substring
    if (queryText) {
      const fallback = lexiconEntries.find(
        (e) =>
          e.arabic.includes(queryText) ||
          e.latin.toLowerCase().includes(queryText.toLowerCase())
      );
      if (fallback) {
        setSelectedDictionaryEntry(fallback);
        return;
      }
    }

    if (lexiconEntries.length > 0) {
      setSelectedDictionaryEntry(lexiconEntries[0]);
    }
  };

  // Clean up mic on unmount
  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  const handleAudioPlay = (speed: 'normal' | 'slow' = 'normal') => {
    if (!currentExercise) return;

    // Use authentic native recording if available
    if (hasAuthenticRecording && matchingLexicon?.audio?.url) {
      setIsPlayingAudio(true);
      const audio = new Audio(matchingLexicon.audio.url);
      audio.playbackRate = speed === 'slow' ? 0.75 : 1.0;
      audio.onended = () => setIsPlayingAudio(false);
      audio.onerror = () => setIsPlayingAudio(false);
      audio.play().catch(() => setIsPlayingAudio(false));
      return;
    }

    if (!currentExercise.audioText) return;
    setIsPlayingAudio(true);
    playSpeech(currentExercise.audioText, user.learningLanguage, {
      speed,
      useGemini: user.settings.useGeminiVoice,
      onEnd: () => setIsPlayingAudio(false),
    });
  };

  const handleTokenClick = (token: string, fromSelected: boolean) => {
    playSoundEffect('click', user.settings.soundEffects);
    if (fromSelected) {
      setSelectedTokens((prev) => {
        const idx = prev.indexOf(token);
        if (idx === -1) return prev;
        const next = [...prev];
        next.splice(idx, 1);
        return next;
      });
      setAvailableTokens((prev) => [...prev, token]);
    } else {
      setAvailableTokens((prev) => {
        const idx = prev.indexOf(token);
        if (idx === -1) return prev;
        const next = [...prev];
        next.splice(idx, 1);
        return next;
      });
      setSelectedTokens((prev) => [...prev, token]);
    }
  };

  // Matching pair handler
  const handleLeftClick = (id: string) => {
    if (matchedIds.includes(id)) return;
    playSoundEffect('click', user.settings.soundEffects);
    setSelectedLeft(id);
    setWrongMatch(null);
  };

  const handleRightClick = (id: string) => {
    if (matchedIds.includes(id) || !selectedLeft) return;

    if (selectedLeft === id) {
      // Correct match!
      playSoundEffect('correct', user.settings.soundEffects);
      const newMatched = [...matchedIds, id];
      setMatchedIds(newMatched);
      setSelectedLeft(null);

      // If all matched, auto-pass!
      if (newMatched.length === matchingPairs.length) {
        const res: CheckResult = {
          isCorrect: true,
          hasTypo: false,
          userAnswer: 'Matched all pairs',
          expectedAnswer: 'All pairs correctly matched',
          similarity: 1.0,
          feedback: 'Perfect! All pairs matched.',
        };
        setResult(res);
        setIsSubmitted(true);
        setCorrectCount((c) => c + 1);
      }
    } else {
      // Mismatch
      playSoundEffect('incorrect', user.settings.soundEffects);
      setWrongMatch({ left: selectedLeft, right: id });
      setTimeout(() => {
        setWrongMatch(null);
        setSelectedLeft(null);
      }, 700);
    }
  };

  // Speaking exercise recording handler
  const handleToggleRecord = () => {
    if (!isSpeechRecognitionSupported()) {
      setSpeechTranscript('');
      setResult({
        isCorrect: false,
        hasTypo: false,
        userAnswer: '',
        expectedAnswer: currentExercise.correctAnswer,
        similarity: 0,
        feedback: 'Speech recognition is not supported in this browser.',
      });
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      setSpeechTranscript('');
      const rec = startSpeechRecognition(
        user.learningLanguage,
        (transcript, isFinal) => {
          setSpeechTranscript(transcript);
          if (isFinal) {
            setIsRecording(false);
            const evalResult = evaluateSpeechAccuracy(
              transcript,
              currentExercise.correctAnswer,
              currentExercise.acceptedAnswers
            );
            setSpeakingAccuracy(evalResult.score);
          }
        },
        (err) => {
          console.warn('Speech recognition error:', err);
          setIsRecording(false);
        },
        () => {
          setIsRecording(false);
        }
      );
      recognitionRef.current = rec;
    }
  };

  // Simulated voice tester for environments without mic permissions
  const handleSimulateSpeech = () => {
    const target = currentExercise.correctAnswer;
    setSpeechTranscript(target);
    setSpeakingAccuracy(100);
    playSoundEffect('correct', user.settings.soundEffects);
  };

  // Check answer logic
  const handleCheck = () => {
    if (!currentExercise || isSubmitted) return;

    let userAnswer = '';
    if (currentExercise.type === 'multiple_choice') {
      userAnswer = selectedOption;
    } else if (currentExercise.type === 'word_selection') {
      userAnswer = selectedTokens.join(' ');
    } else if (currentExercise.type === 'translation') {
      userAnswer = selectedOption || typedAnswer || selectedTokens.join(' ');
    } else if (currentExercise.type === 'typing') {
      userAnswer = typedAnswer;
    } else if (currentExercise.type === 'listening') {
      userAnswer = selectedOption || typedAnswer;
    } else if (currentExercise.type === 'fill_in_the_blank') {
      userAnswer = selectedOption;
    } else if (currentExercise.type === 'speaking') {
      userAnswer = speechTranscript;
    }

    // Identify corresponding canonical lexicon entry
    const targetLexEntry = matchingLexicon || lexiconEntries.find(
      (e) =>
        (currentExercise.targetText && (e.arabic === currentExercise.targetText || e.latin.toLowerCase() === currentExercise.targetText.toLowerCase() || e.id === currentExercise.targetText)) ||
        (lesson.targetWordIds && (lesson.targetWordIds.includes(e.id) || lesson.targetWordIds.includes(`lex_${e.id}`)))
    );

    // Multiple meanings support: never mark an answer incorrect if it matches any documented meaning of canonical entry
    const mergedAccepted: string[] = [...(currentExercise.acceptedAnswers || [])];
    if (targetLexEntry) {
      targetLexEntry.definitions.forEach((d) => {
        if (d.english) mergedAccepted.push(d.english);
        if (d.urdu) mergedAccepted.push(d.urdu);
      });
      mergedAccepted.push(targetLexEntry.arabic);
      mergedAccepted.push(targetLexEntry.latin);
      if (targetLexEntry.variants) {
        targetLexEntry.variants.forEach((v) => {
          if (v.arabic) mergedAccepted.push(v.arabic);
          if (v.latin) mergedAccepted.push(v.latin);
        });
      }
    }

    let checkRes: CheckResult;
    if (currentExercise.type === 'speaking') {
      const evalRes = evaluateSpeechAccuracy(
        userAnswer,
        currentExercise.correctAnswer,
        mergedAccepted
      );
      checkRes = {
        isCorrect: evalRes.isPassed,
        hasTypo: false,
        userAnswer,
        expectedAnswer: currentExercise.correctAnswer,
        similarity: evalRes.score / 100,
        feedback: evalRes.feedback,
      };
    } else {
      checkRes = checkAnswer(
        userAnswer,
        currentExercise.correctAnswer,
        mergedAccepted
      );
    }

    setResult(checkRes);
    setIsSubmitted(true);

    if (targetLexEntry) {
      recordReviewAttempt(targetLexEntry.id, checkRes.isCorrect, {
        exerciseId: currentExercise.id,
        exerciseType: currentExercise.type,
        questionPrompt: currentExercise.prompt,
        targetWord: currentExercise.targetText || targetLexEntry.arabic,
        expectedAnswer: currentExercise.correctAnswer,
        learnerAnswer: userAnswer,
        sourceLessonId: lesson.id,
        sourceUnitId: lesson.unitId,
        difficulty:
          currentExercise.difficulty === 'advanced'
            ? 'hard'
            : currentExercise.difficulty === 'beginner'
            ? 'easy'
            : 'medium',
      });
    }

    if (checkRes.isCorrect) {
      playSoundEffect('correct', user.settings.soundEffects);
      setCorrectCount((c) => c + 1);
    } else {
      playSoundEffect('incorrect', user.settings.soundEffects);
      loseHeart();
      setMistakeList((m) => [...m, currentExercise]);
      logMistake({
        exerciseId: currentExercise.id,
        questionPrompt: currentExercise.prompt,
        targetWord: currentExercise.targetText,
        userAnswer,
        correctAnswer: currentExercise.correctAnswer,
        language: user.learningLanguage,
      });
    }
  };

  // Next step or finish
  const handleContinue = () => {
    if (currentIndex < exercises.length - 1) {
      setCurrentIndex((idx) => idx + 1);
    } else {
      // Completed all exercises in lesson!
      setIsFinished(true);
      const accuracy = Math.round((correctCount / exercises.length) * 100);
      completeLesson(lesson.id, lesson.xpReward, accuracy, lesson.targetWordIds);
    }
  };

  // Request AI Explanation
  const handleFetchAiExplanation = async () => {
    if (!currentExercise || !result) return;
    setIsLoadingAi(true);
    setShowAiModal(true);

    try {
      const res = await fetch('/api/gemini/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentExercise.prompt,
          userAnswer: result.userAnswer,
          correctAnswer: currentExercise.correctAnswer,
          language: user.learningLanguage,
          grammarNote: currentExercise.grammarNote,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAiExplanation(data.explanation);
      } else {
        setAiExplanation(
          `In ${user.learningLanguage}, "${currentExercise.correctAnswer}" is the standard expression. ${currentExercise.grammarNote || ''}`
        );
      }
    } catch {
      setAiExplanation(
        `In ${user.learningLanguage}, "${currentExercise.correctAnswer}" is the correct form. ${currentExercise.grammarNote || ''}`
      );
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Is Check button enabled?
  const canCheck = () => {
    if (currentExercise.type === 'multiple_choice') return !!selectedOption;
    if (currentExercise.type === 'word_selection') return selectedTokens.length > 0;
    if (currentExercise.type === 'translation') return !!(selectedOption || typedAnswer || selectedTokens.length > 0);
    if (currentExercise.type === 'typing') return typedAnswer.trim().length > 0;
    if (currentExercise.type === 'listening') return !!(selectedOption || typedAnswer);
    if (currentExercise.type === 'fill_in_the_blank') return !!selectedOption;
    if (currentExercise.type === 'speaking') return !!speechTranscript || speakingAccuracy !== null;
    if (currentExercise.type === 'matching') return matchedIds.length === matchingPairs.length;
    return false;
  };

  // If Finished Screen
  if (isFinished) {
    const accuracy = Math.round((correctCount / exercises.length) * 100);
    const activeUnit = activeCourse.sections
      .flatMap((s) => s.units)
      .find((u) => u.id === lesson.unitId);

    const unitLessons = activeUnit?.lessons || [];
    const isUnitMilestone =
      activeUnit &&
      unitLessons.length > 0 &&
      unitLessons.every(
        (l) => l.id === lesson.id || user.completedLessons.includes(l.id)
      );
    const totalUnitXp = unitLessons.reduce((acc, l) => acc + l.xpReward, 0);

    return (
      <div className="fixed inset-0 z-50 bg-white flex flex-col justify-between p-6 sm:p-12 overflow-y-auto">
        <div className="max-w-md mx-auto w-full my-auto text-center">
          {/* Unit Milestone Celebration or Standard Lesson Completion */}
          {isUnitMilestone ? (
            <div className="mb-6 p-6 rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white shadow-xl relative overflow-hidden">
              <div className="w-16 h-16 bg-white/20 rounded-2xl mx-auto flex items-center justify-center mb-3 ring-4 ring-white/30 animate-bounce">
                <Trophy className="w-8 h-8 text-amber-300 fill-amber-300" />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest bg-amber-400/20 text-amber-300 px-3 py-1 rounded-full border border-amber-300/30 inline-block mb-2">
                Unit Milestone Unlocked
              </span>
              <h2 className="text-2xl font-extrabold font-display">
                Unit {activeUnit.number} Complete!
              </h2>
              <p className="text-xs text-emerald-100 mt-1">
                {activeUnit.title}
              </p>

              {/* Unit Milestone Stats Grid */}
              <div className="mt-4 pt-4 border-t border-white/15 grid grid-cols-2 gap-2 text-left">
                <div className="bg-white/10 rounded-xl p-2.5">
                  <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                    Milestone State
                  </span>
                  <span className="text-xs font-bold text-white flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                    All {unitLessons.length} Lessons (100%)
                  </span>
                </div>
                <div className="bg-white/10 rounded-xl p-2.5">
                  <span className="text-[10px] text-emerald-200 block uppercase font-bold">
                    Unit Total XP
                  </span>
                  <span className="text-xs font-bold text-amber-300 font-mono">
                    +{totalUnitXp} XP Earned
                  </span>
                </div>
              </div>

              <div className="mt-3 p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-400/30 flex items-center gap-2.5 text-left">
                <Award className="w-6 h-6 text-amber-400 shrink-0" />
                <div className="text-[11px]">
                  <span className="font-bold text-white block">
                    Awarded: Unit {activeUnit.number} Mastery Badge
                  </span>
                  <span className="text-emerald-200 text-[10px]">
                    دَربَند {activeUnit.number} تمغہ added to your learning milestones
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl mx-auto flex items-center justify-center mb-6 shadow-inner animate-bounce">
              <Star className="w-10 h-10 fill-emerald-500 text-emerald-500" />
            </div>
          )}

          <h2 className="text-3xl font-extrabold text-slate-900 font-display mb-2">
            Lesson Complete!
          </h2>
          <p className="text-slate-500 text-sm mb-8">
            You just completed <span className="font-semibold text-slate-800">{lesson.title}</span>. Fantastic consistency!
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Total XP</span>
              <span className="text-xl font-extrabold text-emerald-700 font-mono">
                +{lesson.xpReward}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Accuracy</span>
              <span className="text-xl font-extrabold text-slate-900 font-mono">
                {accuracy}%
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-center">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Streak</span>
              <div className="flex items-center justify-center gap-1 text-xl font-extrabold text-amber-600 font-mono">
                <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
                <span>{user.streak}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              onFinish();
              onClose();
            }}
            className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-base shadow-md transition-all flex items-center justify-center gap-2"
          >
            <span>Continue Journey</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col justify-between overflow-hidden">
      {/* Top Header Bar */}
      <div className="border-b border-slate-200 px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
        <button
          onClick={() => setShowQuitConfirm(true)}
          className="p-2 text-slate-400 hover:text-slate-700 rounded-lg transition-colors"
          title="Quit Lesson"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Lesson Progress bar */}
        <div className="flex-1 max-w-xl mx-2 bg-slate-100 h-3 rounded-full overflow-hidden">
          <div
            className="bg-emerald-500 h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Hearts indicator */}
        <div className="flex items-center gap-1.5 text-rose-500 font-bold font-mono text-sm shrink-0">
          <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
          <span>{user.hearts}</span>
        </div>
      </div>

      {/* Main Exercise Area */}
      <div className="flex-1 max-w-2xl w-full mx-auto px-4 py-6 overflow-y-auto flex flex-col justify-center">
        {/* Exercise Prompt */}
        <div className="mb-6">
          <span className="text-xs font-bold text-emerald-700 tracking-wider uppercase block mb-1">
            {currentExercise.type.replace(/_/g, ' ')}
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
            {currentExercise.prompt}
          </h2>
        </div>

        {/* Target sentence / Audio Box */}
        {(currentExercise.targetText || currentExercise.audioText) && (
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 mb-6 flex items-center gap-4">
            {currentExercise.audioText && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleAudioPlay('normal')}
                  disabled={isPlayingAudio}
                  className={`w-12 h-12 rounded-xl text-white flex items-center justify-center active:scale-95 transition-all shadow-sm ${
                    hasAuthenticRecording
                      ? 'bg-emerald-600 hover:bg-emerald-700 ring-2 ring-emerald-300'
                      : 'bg-violet-600 hover:bg-violet-700 ring-2 ring-violet-300'
                  }`}
                  title={hasAuthenticRecording ? 'Play verified native recording' : 'Play AI pronunciation preview (Not native recording)'}
                >
                  <Volume2 className="w-6 h-6" />
                </button>
                <button
                  onClick={() => handleAudioPlay('slow')}
                  disabled={isPlayingAudio}
                  className="w-10 h-10 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center hover:bg-slate-300 active:scale-95 transition-all"
                  title="Slow audio"
                >
                  <Turtle className="w-5 h-5" />
                </button>
              </div>
            )}

            <div className="flex-1">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2 flex-wrap">
                  {currentExercise.targetText && (
                    <div className="text-xl sm:text-2xl font-bold text-slate-900 tracking-wide font-arabic">
                      {currentExercise.targetText}
                    </div>
                  )}
                  {hasAuthenticRecording ? (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                      <span>🎙️</span> Native Recording
                    </span>
                  ) : (
                    <span className="text-[10px] bg-violet-100 text-violet-800 font-semibold px-2 py-0.5 rounded-full border border-violet-200 flex items-center gap-1">
                      <span>🤖</span> AI Preview
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handleOpenDictionary(currentExercise.targetText || currentExercise.prompt)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold transition-colors"
                  title="Look up in Balochi Dictionary"
                >
                  <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Dictionary</span>
                </button>
              </div>
              {currentExercise.transliteration && (
                <div className="text-xs sm:text-sm text-slate-500 italic mt-0.5">
                  ({currentExercise.transliteration})
                </div>
              )}
            </div>
          </div>
        )}

        {/* Exercise Type 1: Multiple Choice */}
        {currentExercise.type === 'multiple_choice' && currentExercise.options && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentExercise.options.map((option, idx) => {
              const isSelected = selectedOption === option;
              return (
                <button
                  key={option}
                  onClick={() => !isSubmitted && setSelectedOption(option)}
                  disabled={isSubmitted}
                  className={`text-left p-4 rounded-xl border text-sm font-semibold transition-all flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm ring-1 ring-emerald-600'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <span>{option}</span>
                  <span className="text-xs text-slate-400 font-mono">
                    {idx + 1}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Exercise Type 2: Word Selection (Sentence Builder) */}
        {currentExercise.type === 'word_selection' && (
          <div className="space-y-6">
            {/* Selected tokens tray */}
            <div className="min-h-16 p-3 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50/50 flex flex-wrap gap-2 items-center">
              {selectedTokens.length === 0 ? (
                <span className="text-xs text-slate-400 italic px-2">
                  Click words below to construct the sentence in order...
                </span>
              ) : (
                selectedTokens.map((token, i) => (
                  <button
                    key={`${token}_${i}`}
                    onClick={() => !isSubmitted && handleTokenClick(token, true)}
                    disabled={isSubmitted}
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-300 shadow-sm text-sm font-semibold text-slate-800 hover:border-rose-400 active:scale-95 transition-all"
                  >
                    {token}
                  </button>
                ))
              )}
            </div>

            {/* Available tokens pool */}
            <div className="flex flex-wrap gap-2 justify-center">
              {availableTokens.map((token, i) => (
                <button
                  key={`${token}_${i}`}
                  onClick={() => !isSubmitted && handleTokenClick(token, false)}
                  disabled={isSubmitted}
                  className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-800 shadow-sm hover:border-emerald-500 hover:bg-emerald-50/30 active:scale-95 transition-all"
                >
                  {token}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Exercise Type 3 & 4: Translation & Typing */}
        {(currentExercise.type === 'typing' || (currentExercise.type === 'translation' && !currentExercise.options)) && (
          <div className="space-y-4">
            <input
              type="text"
              value={typedAnswer}
              onChange={(e) => setTypedAnswer(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && canCheck() && !isSubmitted) {
                  handleCheck();
                }
              }}
              disabled={isSubmitted}
              placeholder="Type your answer here..."
              className="w-full p-4 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-base font-medium placeholder:text-slate-400 shadow-sm"
              autoFocus
            />
            {currentExercise.hint && (
              <p className="text-xs text-slate-500 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                <span>Hint: {currentExercise.hint}</span>
              </p>
            )}
          </div>
        )}

        {/* Translation with Options */}
        {currentExercise.type === 'translation' && currentExercise.options && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentExercise.options.map((option) => (
              <button
                key={option}
                onClick={() => !isSubmitted && setSelectedOption(option)}
                disabled={isSubmitted}
                className={`text-left p-4 rounded-xl border text-sm font-semibold transition-all ${
                  selectedOption === option
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm ring-1 ring-emerald-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        )}

        {/* Exercise Type 5: Listening */}
        {currentExercise.type === 'listening' && (
          <div className="space-y-6">
            <div className={`flex flex-col items-center justify-center p-8 rounded-2xl border text-center ${
              hasAuthenticRecording
                ? 'bg-emerald-50/70 border-emerald-200'
                : 'bg-violet-50/70 border-violet-200'
            }`}>
              <button
                onClick={() => handleAudioPlay('normal')}
                disabled={isPlayingAudio}
                className={`w-20 h-20 rounded-full text-white flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all mb-3 ring-4 ${
                  hasAuthenticRecording
                    ? 'bg-emerald-600 ring-emerald-200'
                    : 'bg-violet-600 ring-violet-200'
                }`}
              >
                <Volume2 className="w-10 h-10" />
              </button>
              <div className="flex flex-col items-center gap-1">
                <span className={`text-xs font-bold ${hasAuthenticRecording ? 'text-emerald-900' : 'text-violet-950'}`}>
                  {hasAuthenticRecording ? '🎙️ Verified native recording' : '🤖 AI Pronunciation Preview'}
                </span>
                {!hasAuthenticRecording && (
                  <span className="text-[11px] text-rose-600 font-semibold italic">
                    Not a native recording. Authentic native audio awaiting recording.
                  </span>
                )}
              </div>
            </div>

            {currentExercise.options ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentExercise.options.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => !isSubmitted && setSelectedOption(opt)}
                    disabled={isSubmitted}
                    className={`p-4 rounded-xl border text-sm font-semibold transition-all text-left ${
                      selectedOption === opt
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            ) : (
              <input
                type="text"
                value={typedAnswer}
                onChange={(e) => setTypedAnswer(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && canCheck() && !isSubmitted) {
                    handleCheck();
                  }
                }}
                disabled={isSubmitted}
                placeholder="Type what you hear..."
                className="w-full p-4 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-base font-medium shadow-sm"
              />
            )}
          </div>
        )}

        {/* Exercise Type 6: Matching Pairs */}
        {currentExercise.type === 'matching' && (
          <div className="grid grid-cols-2 gap-4">
            {/* Left column */}
            <div className="space-y-3">
              {matchingPairs.map((pair) => {
                const isMatched = matchedIds.includes(pair.id);
                const isSelected = selectedLeft === pair.id;
                const isWrong = wrongMatch?.left === pair.id;

                return (
                  <button
                    key={pair.id}
                    onClick={() => handleLeftClick(pair.id)}
                    disabled={isMatched}
                    className={`w-full p-3.5 rounded-xl border text-sm font-semibold transition-all text-left font-arabic ${
                      isMatched
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-60 cursor-default'
                        : isWrong
                        ? 'bg-rose-50 border-rose-400 text-rose-800 animate-shake'
                        : isSelected
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-600'
                        : 'border-slate-200 bg-white hover:border-slate-300 text-slate-800'
                    }`}
                  >
                    <div>{pair.left}</div>
                    {pair.transliteration && (
                      <span className="text-[11px] text-slate-400 font-normal font-sans">
                        {pair.transliteration}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Right column */}
            <div className="space-y-3">
              {matchingPairs.map((pair) => {
                const isMatched = matchedIds.includes(pair.id);
                const isWrong = wrongMatch?.right === pair.id;

                return (
                  <button
                    key={pair.id}
                    onClick={() => handleRightClick(pair.id)}
                    disabled={isMatched || !selectedLeft}
                    className={`w-full p-3.5 rounded-xl border text-sm font-semibold transition-all text-left ${
                      isMatched
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-60 cursor-default'
                        : isWrong
                        ? 'bg-rose-50 border-rose-400 text-rose-800 animate-shake'
                        : 'border-slate-200 bg-white hover:border-slate-300 text-slate-800'
                    }`}
                  >
                    {pair.right}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Exercise Type 7: Fill in the blank */}
        {currentExercise.type === 'fill_in_the_blank' && currentExercise.options && (
          <div className="space-y-6">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-lg font-bold text-slate-800">
              {currentExercise.targetText?.replace('___', `[ ${selectedOption || '___'} ]`)}
            </div>

            <div className="grid grid-cols-2 gap-3">
              {currentExercise.options.map((opt) => (
                <button
                  key={opt}
                  onClick={() => !isSubmitted && setSelectedOption(opt)}
                  disabled={isSubmitted}
                  className={`p-4 rounded-xl border text-sm font-semibold text-center transition-all ${
                    selectedOption === opt
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm ring-1 ring-emerald-600'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Exercise Type 8: Speaking Practice */}
        {currentExercise.type === 'speaking' && (
          <div className="flex flex-col items-center justify-center p-6 space-y-6 text-center">
            {/* Big Mic Button */}
            <div className="relative">
              <button
                onClick={handleToggleRecord}
                className={`w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-xl ${
                  isRecording
                    ? 'bg-rose-500 text-white animate-pulse ring-8 ring-rose-200'
                    : 'bg-emerald-600 text-white hover:scale-105 active:scale-95 ring-4 ring-emerald-100'
                }`}
                title={
                  isRecording
                    ? 'Listening... click to stop'
                    : user.learningLanguage === 'balochi'
                    ? 'Balochi speech beta — speak slowly'
                    : 'Click to speak'
                }
                disabled={false}
              >
                {isRecording ? <Mic className="w-10 h-10 animate-bounce" /> : <Mic className="w-10 h-10" />}
              </button>
            </div>

            <div className="max-w-sm">
              <span className="text-sm font-semibold text-slate-700 block">
                {isRecording
                  ? 'Listening now... speak clearly'
                  : user.learningLanguage === 'balochi'
                  ? 'Balochi speech beta — speak slowly'
                  : 'Tap the microphone and read aloud'}
              </span>
              {user.learningLanguage === 'balochi' && (
                <span className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-2.5 py-0.5 mt-2 inline-block">
                  🎙️ Balochi speech beta — speak slowly
                </span>
              )}
              {speechTranscript && (
                <div className="mt-3 p-3 bg-slate-100 rounded-xl text-xs text-slate-700 font-mono">
                  "{speechTranscript}"
                </div>
              )}
            </div>

            {/* Developer-only simulation is intentionally hidden from learners. */}
          </div>
        )}
      </div>

      {/* Bottom Submission & Feedback Bar */}
      <div
        className={`border-t px-4 sm:px-8 py-5 transition-colors ${
          !isSubmitted
            ? 'border-slate-200 bg-white'
            : result?.isCorrect
            ? 'border-emerald-200 bg-emerald-50'
            : 'border-rose-200 bg-rose-50'
        }`}
      >
        <div className="max-w-2xl mx-auto flex items-center justify-between gap-4">
          {!isSubmitted ? (
            <>
              <button
                onClick={() => {
                  loseHeart();
                  handleContinue();
                }}
                className="text-xs font-semibold text-slate-400 hover:text-slate-600 transition-colors"
              >
                Skip Question
              </button>

              <button
                onClick={handleCheck}
                disabled={!canCheck()}
                className={`px-8 py-3 rounded-xl font-bold text-sm shadow-md transition-all ${
                  canCheck()
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white active:scale-95 cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Check Answer
              </button>
            </>
          ) : (
            <>
              {/* Feedback Content */}
              <div className="flex items-start gap-3">
                {result?.isCorrect ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
                )}

                <div>
                  <h3
                    className={`font-bold text-sm sm:text-base font-display ${
                      result?.isCorrect ? 'text-emerald-900' : 'text-rose-900'
                    }`}
                  >
                    {result?.isCorrect
                      ? result.hasTypo
                        ? 'Accepted (with typo)'
                        : 'Nicely done!'
                      : 'Correct solution:'}
                  </h3>

                  {!result?.isCorrect && (
                    <p className="text-xs sm:text-sm text-rose-800 font-semibold mt-0.5 font-arabic">
                      {currentExercise.correctAnswer}
                    </p>
                  )}

                  {result?.feedback && (
                    <p className="text-xs text-slate-600 mt-0.5">{result.feedback}</p>
                  )}

                  {/* AI Explanation Trigger */}
                  <button
                    onClick={handleFetchAiExplanation}
                    className="mt-2 text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 underline underline-offset-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Explain with AI</span>
                  </button>
                </div>
              </div>

              {/* Continue button */}
              <button
                onClick={handleContinue}
                className={`px-8 py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-95 text-white ${
                  result?.isCorrect
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                Continue
              </button>
            </>
          )}
        </div>
      </div>

      {/* AI Explanation Drawer Modal */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative">
            <button
              onClick={() => setShowAiModal(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-slate-900 font-display text-base">
                AI Grammar & Context Tutor
              </h3>
            </div>

            {isLoadingAi ? (
              <div className="py-10 flex flex-col items-center justify-center text-slate-500 space-y-2">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
                <span className="text-xs font-medium">Consulting language engine...</span>
              </div>
            ) : (
              <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-4 rounded-xl border border-slate-200">
                {aiExplanation}
              </div>
            )}

            <button
              onClick={() => setShowAiModal(false)}
              className="w-full mt-4 py-2.5 rounded-xl bg-slate-900 text-white font-semibold text-xs hover:bg-slate-800 transition-colors"
            >
              Understood
            </button>
          </div>
        </div>
      )}

      {/* Quit Confirmation Dialog */}
      {showQuitConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 text-center">
            <h3 className="font-bold text-lg text-slate-900 font-display mb-2">
              Quit lesson?
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              You will lose the progress made in this session so far.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => setShowQuitConfirm(false)}
                className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 transition-colors"
              >
                Keep Learning
              </button>
              <button
                onClick={onClose}
                className="w-full py-2.5 rounded-xl border border-slate-200 text-slate-600 font-semibold text-xs hover:bg-slate-50 transition-colors"
              >
                Quit Session
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-Lesson Dictionary Entry Detail Modal */}
      <LexiconDetailModal
        entry={selectedDictionaryEntry}
        isOpen={!!selectedDictionaryEntry}
        onClose={() => setSelectedDictionaryEntry(null)}
        onStartPracticeWord={() => {
          setSelectedDictionaryEntry(null);
        }}
      />
    </div>
  );
};
