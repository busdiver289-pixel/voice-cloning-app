import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SHOP_ITEMS } from '../data/courses';
import { ShopItem } from '../types';
import { Heart, Shield, Zap, Key, Check, AlertCircle } from 'lucide-react';

export const ShopModal: React.FC = () => {
  const { user, purchaseShopItem } = useApp();
  const [notification, setNotification] = useState<{ message: string; isError: boolean } | null>(null);

  const handleBuy = (item: ShopItem) => {
    const res = purchaseShopItem(item);
    setNotification({
      message: res.message,
      isError: !res.success,
    });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'heart':
        return <Heart className="w-6 h-6 fill-rose-500 text-rose-500" />;
      case 'shield':
        return <Shield className="w-6 h-6 text-blue-500 fill-blue-100" />;
      case 'zap':
        return <Zap className="w-6 h-6 text-amber-500 fill-amber-100" />;
      case 'key':
        return <Key className="w-6 h-6 text-purple-500" />;
      default:
        return <Heart className="w-6 h-6 text-emerald-500" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-display">
            The Bazaar & Gem Store
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Exchange gems earned from lessons and achievements for power-ups and streak protection.
          </p>
        </div>

        {/* Gem Balance */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-5 py-3 flex items-center gap-3 self-start sm:self-auto shadow-sm">
          <span className="text-2xl">💎</span>
          <div>
            <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider block">
              Your Gems
            </span>
            <span className="text-xl font-extrabold text-emerald-900 font-mono">
              {user.gems}
            </span>
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div
          className={`mb-6 p-4 rounded-xl border flex items-center gap-3 text-sm font-semibold transition-all ${
            notification.isError
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
          }`}
        >
          {notification.isError ? (
            <AlertCircle className="w-5 h-5 shrink-0" />
          ) : (
            <Check className="w-5 h-5 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {SHOP_ITEMS.map((item) => {
          const canAfford = user.gems >= item.costGems;
          return (
            <div
              key={item.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all"
            >
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                  {getIcon(item.icon)}
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-base font-display">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <div className="flex items-center gap-1.5 font-bold text-slate-900 text-sm">
                  <span>💎</span>
                  <span className="font-mono">{item.costGems} Gems</span>
                </div>

                <button
                  onClick={() => handleBuy(item)}
                  disabled={!canAfford}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm ${
                    canAfford
                      ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                  }`}
                >
                  {canAfford ? 'Get Item' : 'Need more gems'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Current Inventory Summary */}
      <div className="mt-10 bg-slate-50 rounded-2xl border border-slate-200 p-6">
        <h3 className="font-bold text-slate-900 text-sm font-display mb-3">
          Your Active Inventory & Power-ups
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-400 block mb-0.5">Remaining Hearts</span>
            <span className="font-bold text-slate-800 text-sm font-mono">
              {user.hearts} / {user.maxHearts}
            </span>
          </div>

          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-400 block mb-0.5">Equipped Streak Freezes</span>
            <span className="font-bold text-slate-800 text-sm font-mono">
              {user.streakFreezeCount} Shields
            </span>
          </div>

          <div className="p-3 bg-white rounded-xl border border-slate-200">
            <span className="text-slate-400 block mb-0.5">Unlocked Lessons</span>
            <span className="font-bold text-slate-800 text-sm font-mono">
              {user.unlockedLessons.length} Modules
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
