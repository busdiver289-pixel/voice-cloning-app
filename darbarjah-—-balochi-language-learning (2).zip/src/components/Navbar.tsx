import React from 'react';
import { useApp } from '../context/AppContext';
import { SUPPORTED_LANGUAGES } from '../data/courses';
import { Flame, Heart, Volume2, VolumeX, Share2, User } from 'lucide-react';

interface NavbarProps {
  currentTab: 'learn' | 'practice' | 'vocabulary' | 'tutor' | 'shop' | 'profile';
  onSelectTab: (tab: 'learn' | 'practice' | 'vocabulary' | 'tutor' | 'shop' | 'profile') => void;
  onOpenLanguageSelector: () => void;
  onOpenShareModal?: () => void;
  onOpenAuthModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenLanguageSelector,
  onOpenShareModal,
  onOpenAuthModal,
}) => {
  const { user, updateSettings } = useApp();
  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === user.learningLanguage) || SUPPORTED_LANGUAGES[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onSelectTab('learn')}
            className="flex items-center gap-2 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              د
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-slate-900 block leading-none font-display">
                Darbarjah
              </span>
              <span className="text-[10px] text-emerald-700 font-semibold tracking-wider uppercase block mt-0.5 font-sans">
                Balochi Language Learning (دَربَر جاہ)
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => onSelectTab('learn')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap ${
              currentTab === 'learn'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Learn Course
          </button>
          <button
            onClick={() => onSelectTab('practice')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap ${
              currentTab === 'practice'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Practice &amp; Review
          </button>
          <button
            onClick={() => onSelectTab('vocabulary')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap ${
              currentTab === 'vocabulary'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Dictionary &amp; Lexicon
          </button>
          <button
            onClick={() => onSelectTab('tutor')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
              currentTab === 'tutor'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            AI Roleplay
          </button>
          <button
            onClick={() => onSelectTab('shop')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap ${
              currentTab === 'shop'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Shop
          </button>
          <button
            onClick={() => onSelectTab('profile')}
            className={`transition-colors pb-0.5 border-b-2 whitespace-nowrap ${
              currentTab === 'profile'
                ? 'border-emerald-600 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Profile
          </button>
        </nav>

        {/* Zone 3: Primary actions & game status metrics */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Share App Trigger */}
          {onOpenShareModal && (
            <button
              onClick={onOpenShareModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 transition-colors text-xs font-bold shadow-2xs"
              title="Share Darbarjah link with friends"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-700" />
              <span className="hidden sm:inline">Share</span>
            </button>
          )}

          {/* Auth Button or User Badge */}
          {user.isAuthenticated ? (
            <button
              onClick={() => onSelectTab('profile')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors text-xs font-bold text-slate-800"
              title={`Logged in as ${user.username}`}
            >
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold">
                {user.username.slice(0, 1).toUpperCase()}
              </div>
              <span className="hidden md:inline truncate max-w-[80px]">{user.username}</span>
            </button>
          ) : (
            onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white transition-colors text-xs font-bold shadow-2xs"
                title="Sign in or create account"
              >
                <User className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )
          )}

          {/* Language Selector Trigger */}
          <button
            onClick={onOpenLanguageSelector}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition-colors text-xs font-semibold text-slate-700"
            title="Switch Language"
          >
            <span className="text-base leading-none">{currentLang.flag}</span>
            <span className="hidden sm:inline">{currentLang.name}</span>
          </button>

          {/* Streak indicator */}
          <button
            onClick={() => onSelectTab('profile')}
            className="flex items-center gap-1 text-xs font-bold text-amber-600 hover:text-amber-700 transition-colors"
            title={`${user.streak} day streak`}
          >
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="tabular-nums font-mono">{user.streak}</span>
          </button>

          {/* Hearts indicator */}
          <button
            onClick={() => onSelectTab('shop')}
            className="flex items-center gap-1 text-xs font-bold text-rose-600 hover:text-rose-700 transition-colors"
            title={`${user.hearts}/${user.maxHearts} hearts remaining`}
          >
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
            <span className="tabular-nums font-mono">{user.hearts}</span>
          </button>

          {/* Gems indicator */}
          <button
            onClick={() => onSelectTab('shop')}
            className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors"
            title={`${user.gems} gems`}
          >
            <span className="text-emerald-500 text-sm">💎</span>
            <span className="tabular-nums font-mono">{user.gems}</span>
          </button>

          {/* Sound toggle button */}
          <button
            onClick={() => updateSettings({ soundEffects: !user.settings.soundEffects })}
            className="p-1.5 text-slate-400 hover:text-slate-700 transition-colors"
            title={user.settings.soundEffects ? 'Sound effects enabled' : 'Sound effects muted'}
          >
            {user.settings.soundEffects ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile navigation row */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-100 bg-white py-2 px-1 text-xs font-medium text-slate-600">
        <button
          onClick={() => onSelectTab('learn')}
          className={`px-2 py-1 ${currentTab === 'learn' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Learn
        </button>
        <button
          onClick={() => onSelectTab('practice')}
          className={`px-2 py-1 ${currentTab === 'practice' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Practice
        </button>
        <button
          onClick={() => onSelectTab('vocabulary')}
          className={`px-2 py-1 ${currentTab === 'vocabulary' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Dictionary
        </button>
        <button
          onClick={() => onSelectTab('tutor')}
          className={`px-2 py-1 ${currentTab === 'tutor' ? 'text-emerald-700 font-bold' : ''}`}
        >
          AI Tutor
        </button>
        <button
          onClick={() => onSelectTab('shop')}
          className={`px-2 py-1 ${currentTab === 'shop' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Shop
        </button>
        <button
          onClick={() => onSelectTab('profile')}
          className={`px-2 py-1 ${currentTab === 'profile' ? 'text-emerald-700 font-bold' : ''}`}
        >
          Profile
        </button>
      </div>
    </header>
  );
};
