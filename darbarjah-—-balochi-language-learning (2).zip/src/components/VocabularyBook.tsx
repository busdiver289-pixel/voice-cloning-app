import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { LexiconEntry, PersonalLexiconState } from '../types/lexicon';
import { Exercise } from '../types';
import {
  searchLexicon,
  getFriendlyPosLabel,
} from '../utils/lexiconSearch';
import { createLexiconQuizExercises } from '../utils/lexiconQuiz';
import { LexiconDetailModal } from './LexiconDetailModal';
import { AlphabetGuide } from './AlphabetGuide';
import {
  Search,
  BookOpen,
  Filter,
  Bookmark,
  Plus,
  Check,
  Zap,
  ArrowRight,
  ExternalLink,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Volume2,
  Terminal,
  Mic,
  Radio,
  ListOrdered,
} from 'lucide-react';
import {
  computeAudioPriorityQueue,
  getAudioCoverageReport,
  AudioPriorityItem,
} from '../utils/audioPriorityQueue';

interface VocabularyBookProps {
  onStartCustomExercise?: (exercises: Exercise[], title: string) => void;
  onOpenDiagnostics?: () => void;
  isDevMode?: boolean;
}

export const VocabularyBook: React.FC<VocabularyBookProps> = ({
  onStartCustomExercise,
  onOpenDiagnostics,
  isDevMode = false,
}) => {
  const {
    lexiconEntries,
    user,
    activeCourse,
    addToLearningQueue,
    removeFromLearningQueue,
    toggleBookmarkLexicon,
    getLexiconStatus,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dictionary' | 'alphabet' | 'queue' | 'audio_queue'>('dictionary');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedPos, setSelectedPos] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [audioFilter, setAudioFilter] = useState<'all' | 'authentic' | 'ai_preview' | 'unavailable'>('all');
  const [displayScript, setDisplayScript] = useState<'arabic' | 'latin'>('arabic');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Selected entry for detailed view modal
  const [selectedEntry, setSelectedEntry] = useState<LexiconEntry | null>(null);

  // Available unique domains from lexicon
  const availableDomains = useMemo(() => {
    const set = new Set<string>();
    lexiconEntries.forEach((e) => {
      if (e.domain) set.add(e.domain);
      e.definitions.forEach((d) => {
        if (d.domain) set.add(d.domain);
      });
    });
    return ['all', ...Array.from(set).sort()];
  }, [lexiconEntries]);

  // Personal status map
  const personalStatuses = useMemo(() => {
    const map: Record<string, string> = {};
    lexiconEntries.forEach((e) => {
      map[e.id] = getLexiconStatus(e.id).status;
    });
    return map;
  }, [lexiconEntries, getLexiconStatus]);

  // Filtered entries
  const filteredEntries = useMemo(() => {
    const effectiveStatus = activeTab === 'queue' ? 'learning' : selectedStatus;
    let results = searchLexicon(lexiconEntries, searchTerm, {
      domainFilter: selectedDomain,
      posFilter: selectedPos,
      statusFilter: effectiveStatus,
      personalStatuses,
      bookmarkedIds: user.bookmarkedLexiconIds || [],
    });

    if (audioFilter === 'authentic') {
      results = results.filter((e) => e.audio?.type === 'authentic_recording' && !!e.audio.url);
    } else if (audioFilter === 'ai_preview') {
      results = results.filter((e) => e.audio?.type === 'ai_preview');
    } else if (audioFilter === 'unavailable') {
      results = results.filter((e) => !e.audio || e.audio.type === 'unavailable');
    }

    return results;
  }, [
    lexiconEntries,
    searchTerm,
    selectedDomain,
    selectedPos,
    selectedStatus,
    audioFilter,
    activeTab,
    personalStatuses,
    user.bookmarkedLexiconIds,
  ]);

  // Audio Priority Queue and Authoritative Coverage calculation
  const personalLexiconMap = useMemo(() => {
    const map: Record<string, PersonalLexiconState> = {};
    lexiconEntries.forEach((e) => {
      const st = getLexiconStatus(e.id);
      map[e.id] = {
        wordId: e.id,
        status: st.status,
        masteryScore: st.masteryScore,
        isBookmarked: st.isBookmarked,
        isInLearningQueue: st.isInQueue,
        mistakeCount: st.mistakeCount,
        correctCount: st.correctCount,
      };
    });
    return map;
  }, [lexiconEntries, getLexiconStatus]);

  const audioQueue = useMemo(() => {
    return computeAudioPriorityQueue(lexiconEntries, activeCourse, personalLexiconMap);
  }, [lexiconEntries, activeCourse, personalLexiconMap]);

  const audioCoverage = useMemo(() => {
    return getAudioCoverageReport(lexiconEntries, activeCourse, personalLexiconMap);
  }, [lexiconEntries, activeCourse, personalLexiconMap]);

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredEntries.length / itemsPerPage));
  const paginatedEntries = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredEntries.slice(start, start + itemsPerPage);
  }, [filteredEntries, currentPage, itemsPerPage]);

  const handleLaunchPractice = (entry: LexiconEntry) => {
    if (onStartCustomExercise) {
      const exercises = createLexiconQuizExercises(entry, lexiconEntries);
      onStartCustomExercise(
        exercises,
        `Lexicon Practice: ${entry.arabic} (${entry.latin})`
      );
    }
  };

  const handleSelectReferenceWord = (arabicOrLatin: string) => {
    setSearchTerm(arabicOrLatin);
    const found = lexiconEntries.find(
      (e) =>
        e.arabic === arabicOrLatin ||
        e.latin.toLowerCase() === arabicOrLatin.toLowerCase()
    );
    if (found) {
      setSelectedEntry(found);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Top Segmented Tabs: Dictionary ⇄ Alphabet & Phonology ⇄ My Learning Queue */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-display">
              Balochi Lexicon & Language Reference
            </h1>
            <span className="text-xs font-semibold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full border border-emerald-200">
              Corpus Engine ({lexiconEntries.length.toLocaleString()} Words)
            </span>
            {isDevMode && onOpenDiagnostics && (
              <button
                onClick={onOpenDiagnostics}
                className="text-xs font-mono font-bold bg-slate-900 text-emerald-400 hover:bg-slate-800 px-2.5 py-0.5 rounded-full border border-slate-700 flex items-center gap-1 transition-colors"
                title="Open Lexicon Diagnostics Dashboard (Ctrl+Shift+D)"
              >
                <Terminal className="w-3 h-3 text-emerald-400" />
                <span>Diagnostics</span>
              </button>
            )}
          </div>
          <p className="text-slate-500 text-sm">
            Explore authoritative headwords, multiple definitions, phonetics, and linked orthography.
          </p>
        </div>

        {/* Mode Toggle Pills */}
        <div className="flex items-center p-1 bg-slate-200/80 rounded-2xl border border-slate-300/80 self-start sm:self-auto">
          <button
            onClick={() => {
              setActiveTab('dictionary');
              setCurrentPage(1);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'dictionary'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Dictionary (قاموس)
          </button>
          <button
            onClick={() => setActiveTab('alphabet')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'alphabet'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Alphabet (آبێنک)
          </button>
          <button
            onClick={() => {
              setActiveTab('queue');
              setCurrentPage(1);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'queue'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Learning Queue</span>
            {(user.learningQueueLexiconIds?.length || 0) > 0 && (
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] flex items-center justify-center font-bold">
                {user.learningQueueLexiconIds?.length}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              setActiveTab('audio_queue');
              setCurrentPage(1);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'audio_queue'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Audio Priority</span>
            <span className="w-5 h-5 rounded-full bg-violet-600 text-white text-[10px] flex items-center justify-center font-bold">
              {audioCoverage.activeLessonWordsCount}
            </span>
          </button>
        </div>
      </div>

      {/* RENDER ALPHABET MODULE IF ACTIVE */}
      {activeTab === 'alphabet' ? (
        <AlphabetGuide
          onOpenDictionaryWord={(entry) => setSelectedEntry(entry)}
        />
      ) : activeTab === 'audio_queue' ? (
        /* RENDER AUDIO PRIORITY QUEUE MODULE */
        <div className="space-y-6">
          {/* Header Card */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-violet-950 text-white p-6 rounded-3xl shadow-sm border border-slate-700/60">
            <div className="flex items-start justify-between flex-wrap gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-extrabold uppercase tracking-wider bg-violet-500/20 text-violet-300 px-2.5 py-0.5 rounded-full border border-violet-400/30">
                    Audio Architecture · Phase 1
                  </span>
                  <span className="text-xs text-slate-300 font-medium">Internal Prioritization Engine</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold font-display text-white">
                  🎙️ Authentic Audio Priority Queue
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                  Every dictionary entry supports transparent audio classification. Rather than generating fake bulk audio, this system dynamically prioritizes words needing authentic Balochi recordings based on active lessons, frequency, and learner practice.
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/10 text-xs space-y-1">
                <span className="text-slate-300 block font-semibold">Priority Tiers:</span>
                <span className="text-amber-300 block font-bold">1. Active Lessons (+10k)</span>
                <span className="text-emerald-300 block font-bold">2. High Frequency (+2.5k)</span>
                <span className="text-blue-300 block font-bold">3. Learning Queue (+1k)</span>
                <span className="text-rose-300 block font-bold">4. Practice Mistakes (+500)</span>
              </div>
            </div>

            {/* Authoritative Audio Coverage Metrics */}
            <div className="mt-6 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                  Authentic Audio
                </span>
                <span className="text-xl font-extrabold text-emerald-400 font-mono">
                  {audioCoverage.authenticCount}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">0.0% (Verified native)</span>
              </div>

              <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                  AI Previews
                </span>
                <span className="text-xl font-extrabold text-violet-300 font-mono">
                  {audioCoverage.aiPreviewCount}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Labeled synthetic</span>
              </div>

              <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                  Awaiting Audio
                </span>
                <span className="text-xl font-extrabold text-amber-300 font-mono">
                  {audioCoverage.unavailableCount}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">100% transparent</span>
              </div>

              <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                  Active Lesson Words
                </span>
                <span className="text-xl font-extrabold text-teal-300 font-mono">
                  {audioCoverage.activeLessonWordsCount}
                </span>
                <span className="text-[10px] text-teal-200/80 block mt-0.5">Highest Priority Targets</span>
              </div>
            </div>
          </div>

          {/* Priority Queue Cards List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-600 px-1">
              <span className="font-bold flex items-center gap-1.5">
                <ListOrdered className="w-4 h-4 text-violet-600" />
                <span>Top Recording Priorities ({audioQueue.length} total awaiting recordings)</span>
              </span>
              <span className="text-slate-400 italic">Showing top 30 ranked by demand</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {audioQueue.slice(0, 30).map((item, index) => {
                const e = item.entry;
                return (
                  <div
                    key={e.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200/90 hover:border-violet-300 hover:shadow-md transition-all flex flex-col justify-between gap-3"
                  >
                    <div>
                      {/* Top Row: Rank & Score */}
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="w-6 h-6 rounded-lg bg-slate-900 text-white font-mono font-bold text-xs flex items-center justify-center">
                            #{index + 1}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                              item.tier === 'active_lesson'
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : item.tier === 'high_frequency'
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                : item.tier === 'learning_queue'
                                ? 'bg-blue-100 text-blue-900 border border-blue-300'
                                : 'bg-slate-100 text-slate-700 border border-slate-200'
                            }`}
                          >
                            {item.tier.replace('_', ' ')}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {item.priorityScore.toLocaleString()} pts
                          </span>
                        </div>

                        <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                          <span>🔇</span> Awaiting Native
                        </span>
                      </div>

                      {/* Headword & Translation */}
                      <div className="flex items-baseline justify-between gap-2 my-1">
                        <div>
                          <span className="text-2xl font-bold font-arabic text-slate-900 ml-1">
                            {e.arabic}
                          </span>
                          <span className="text-sm font-mono font-semibold text-emerald-800 ml-2">
                            ({e.latin})
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">
                        <span className="font-semibold text-slate-800">Meaning:</span>{' '}
                        {e.definitions[0]?.english} {e.definitions[0]?.urdu ? `· ${e.definitions[0].urdu}` : ''}
                      </p>

                      {/* Reasons Breakdown */}
                      <div className="mt-2 space-y-0.5">
                        {item.reasons.map((r, ri) => (
                          <div key={ri} className="text-[11px] text-slate-500 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 shrink-0" />
                            <span>{r}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Bottom Actions */}
                    <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => setSelectedEntry(e)}
                        className="text-xs font-semibold text-violet-700 hover:text-violet-900 flex items-center gap-1"
                      >
                        <span>Entry Details</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>

                      <button
                        onClick={() => handleLaunchPractice(e)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <Zap className="w-3 h-3 text-amber-300" />
                        <span>Practice</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* RENDER LEXICON DICTIONARY BROWSER */
        <div className="space-y-6">
          {/* Search Bar & Script Preference Toggle */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search Balochi (آبێنک), Latin (ábénk), Urdu, or English meaning..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-semibold"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Script Toggle */}
            <div className="flex items-center gap-1 text-xs font-semibold self-end sm:self-auto bg-white p-1 rounded-xl border border-slate-200">
              <span className="text-slate-400 px-2">Primary:</span>
              <button
                onClick={() => setDisplayScript('arabic')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  displayScript === 'arabic'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Baloch (بلوچی)
              </button>
              <button
                onClick={() => setDisplayScript('latin')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  displayScript === 'latin'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Latin (Latîn)
              </button>
            </div>
          </div>

          {/* Filter Pills Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Domain Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              <span className="text-slate-400 font-semibold flex items-center gap-1 shrink-0">
                <Filter className="w-3.5 h-3.5" />
                Domain:
              </span>
              {availableDomains.map((dom) => (
                <button
                  key={dom}
                  onClick={() => {
                    setSelectedDomain(dom);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-semibold capitalize whitespace-nowrap transition-colors ${
                    selectedDomain === dom
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {dom}
                </button>
              ))}
            </div>
          </div>

          {/* Secondary Filter Row: POS & Status */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-500 font-semibold">Part of Speech:</span>
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'n', label: 'Noun (n)' },
                  { id: 'adj', label: 'Adjective (adj)' },
                  { id: 'v', label: 'Verb (v)' },
                  { id: 'interj', label: 'Interjection' },
                  { id: 'phrase', label: 'Phrase' },
                ] as const
              ).map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setSelectedPos(p.id);
                    setCurrentPage(1);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    selectedPos === p.id
                      ? 'bg-slate-800 text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-semibold">Status:</span>
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'bookmarked', label: 'Bookmarked' },
                  { id: 'learning', label: 'Learning' },
                  { id: 'mastered', label: 'Mastered' },
                ] as const
              ).map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedStatus(s.id);
                    setCurrentPage(1);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    selectedStatus === s.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Audio Filter Pills */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-semibold flex items-center gap-1">
                <Volume2 className="w-3 h-3 text-slate-400" />
                Audio:
              </span>
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'authentic', label: '🎙️ Native' },
                  { id: 'ai_preview', label: '🤖 AI' },
                  { id: 'unavailable', label: '🔇 Awaiting' },
                ] as const
              ).map((a) => (
                <button
                  key={a.id}
                  onClick={() => {
                    setAudioFilter(a.id);
                    setCurrentPage(1);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    audioFilter === a.id
                      ? 'bg-violet-700 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          {/* Results Summary */}
          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>
              Showing {filteredEntries.length} lexical entries
              {selectedDomain !== 'all' ? ` in ${selectedDomain}` : ''}
              {searchTerm ? ` matching "${searchTerm}"` : ''}
              {audioFilter !== 'all' ? ` (${audioFilter})` : ''}
            </span>
            <span className="font-mono">
              Page {currentPage} of {totalPages}
            </span>
          </div>

          {/* Lexicon Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {paginatedEntries.map((entry) => {
              const status = getLexiconStatus(entry.id);
              const isArabicPrimary = displayScript === 'arabic';

              return (
                <div
                  key={entry.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Header: POS, Domain, Audio State & Bookmark */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                          {getFriendlyPosLabel(entry.partOfSpeech)}
                        </span>
                        {entry.domain && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 capitalize">
                            {entry.domain}
                          </span>
                        )}
                        {status.isInQueue && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                            Learning
                          </span>
                        )}
                        {/* Audio Status Pill */}
                        {entry.audio?.type === 'authentic_recording' && entry.audio.url ? (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-0.5">
                            <span>🎙️</span> Native
                          </span>
                        ) : entry.audio?.type === 'ai_preview' ? (
                          <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-violet-100 text-violet-800 border border-violet-200 flex items-center gap-0.5">
                            <span>🤖</span> AI
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-500 border border-slate-200">
                            🔇 No Audio
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => toggleBookmarkLexicon(entry.id)}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          status.isBookmarked
                            ? 'bg-amber-50 border-amber-300 text-amber-500'
                            : 'bg-white border-slate-200 text-slate-300 hover:text-slate-500'
                        }`}
                        title="Bookmark"
                      >
                        <Bookmark
                          className={`w-3.5 h-3.5 ${
                            status.isBookmarked ? 'fill-amber-400' : ''
                          }`}
                        />
                      </button>
                    </div>

                    {/* Word Typography */}
                    <div className="my-2 cursor-pointer" onClick={() => setSelectedEntry(entry)}>
                      <h3
                        className={`font-bold text-slate-900 ${
                          isArabicPrimary
                            ? 'text-3xl font-arabic tracking-wide'
                            : 'text-2xl font-mono text-emerald-900'
                        }`}
                      >
                        {isArabicPrimary ? entry.arabic : entry.latin}
                      </h3>
                      <p
                        className={`font-medium ${
                          isArabicPrimary
                            ? 'text-sm font-mono text-emerald-800'
                            : 'text-xl font-arabic text-slate-700'
                        }`}
                      >
                        {isArabicPrimary ? entry.latin : entry.arabic}
                      </p>
                    </div>

                    {/* Numbered Definitions (Multiple meanings supported) */}
                    <div className="space-y-1.5 my-3">
                      {entry.definitions.map((def, idx) => (
                        <div key={def.id || idx} className="text-xs text-slate-700 flex items-start gap-1.5">
                          {entry.definitions.length > 1 && (
                            <span className="w-4 h-4 rounded-full bg-slate-100 text-slate-600 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                          )}
                          <div>
                            <span className="font-semibold text-slate-900">{def.english}</span>
                            {def.scientificName && (
                              <span className="block text-[11px] font-serif italic text-slate-400">
                                {def.scientificName}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Synonyms & Variants Tags */}
                    {(entry.synonyms || entry.variants) && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {entry.synonyms?.map((syn, i) => (
                          <span
                            key={i}
                            className="text-[10px] bg-blue-50 text-blue-800 px-1.5 py-0.5 rounded border border-blue-200"
                          >
                            syn. {syn.arabic} ({syn.latin})
                          </span>
                        ))}
                        {entry.variants?.map((v, i) => (
                          <span
                            key={i}
                            className="text-[10px] bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded border border-amber-200"
                          >
                            var. {v.arabic} ({v.latin})
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Card Bottom Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 mt-3">
                    <button
                      onClick={() => setSelectedEntry(entry)}
                      className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
                    >
                      <span>Details</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>

                    <div className="flex items-center gap-1.5">
                      {status.isInQueue ? (
                        <button
                          onClick={() => removeFromLearningQueue(entry.id)}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-500 text-[11px] font-semibold flex items-center gap-1"
                          title="In Learning Queue"
                        >
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Queued</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => addToLearningQueue(entry.id)}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-semibold flex items-center gap-1 shadow-xs"
                        >
                          <Plus className="w-3 h-3 text-emerald-400" />
                          <span>Learn</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleLaunchPractice(entry)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors"
                        title="Practice this word"
                      >
                        <Zap className="w-3 h-3 text-amber-300" />
                        <span>Practice</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Empty State */}
          {filteredEntries.length === 0 && (
            <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
              <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-900 font-display">
                No matching lexicon entries
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Try typing an unaccented Latin spelling, Balochi (بلوچی) headword, or a broader English or Urdu keyword.
              </p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedDomain('all');
                  setSelectedPos('all');
                  setSelectedStatus('all');
                }}
                className="mt-4 px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-xs"
              >
                Reset Filters
              </button>
            </div>
          )}

          {/* Responsive Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white disabled:opacity-40 disabled:pointer-events-none text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>

              <span className="text-xs font-semibold text-slate-600">
                Page {currentPage} of {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white disabled:opacity-40 disabled:pointer-events-none text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Lexicon Entry Detail Modal */}
      <LexiconDetailModal
        entry={selectedEntry}
        isOpen={!!selectedEntry}
        onClose={() => setSelectedEntry(null)}
        onSelectReferenceWord={handleSelectReferenceWord}
        onStartPracticeWord={handleLaunchPractice}
      />
    </div>
  );
};
