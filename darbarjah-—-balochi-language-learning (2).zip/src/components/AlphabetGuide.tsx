import React, { useState } from 'react';
import { BALOCHI_ALPHABET, AlphabetLetter } from '../data/alphabetData';
import { LexiconEntry } from '../types/lexicon';
import { useApp } from '../context/AppContext';
import { BookOpen, Sparkles, Volume2, ArrowRight, ExternalLink } from 'lucide-react';
import { playAlefbeSpeech } from '../utils/audio';

interface AlphabetGuideProps {
  onOpenDictionaryWord: (entry: LexiconEntry) => void;
}

export const AlphabetGuide: React.FC<AlphabetGuideProps> = ({ onOpenDictionaryWord }) => {
  const { lexiconEntries } = useApp();
  const [selectedType, setSelectedType] = useState<string>('all');
  const [playingLetterId, setPlayingLetterId] = useState<string | null>(null);

  const letterTypes = ['all', 'consonant', 'vowel', 'retroflex'];

  const filteredLetters = BALOCHI_ALPHABET.filter(
    (l) => selectedType === 'all' || l.phoneticType === selectedType
  );

  const handlePlayLetter = async (letter: AlphabetLetter) => {
    setPlayingLetterId(letter.id);
    await playAlefbeSpeech(
      letter.id,
      `${letter.arabic}, ${letter.exampleWord.arabic}`,
      {
        onEnd: () => setPlayingLetterId(null),
      }
    );
    setPlayingLetterId(null);
  };

  const handleOpenWord = (letter: AlphabetLetter) => {
    if (letter.exampleWord.lexId) {
      const match = lexiconEntries.find((e) => e.id === letter.exampleWord.lexId);
      if (match) {
        onOpenDictionaryWord(match);
        return;
      }
    }

    // Fallback: match by Arabic or Latin
    const match = lexiconEntries.find(
      (e) =>
        e.arabic === letter.exampleWord.arabic ||
        e.latin.toLowerCase() === letter.exampleWord.latin.toLowerCase()
    );
    if (match) {
      onOpenDictionaryWord(match);
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white relative overflow-hidden shadow-md">
        <div className="max-w-2xl relative z-10">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300 uppercase tracking-wider mb-2">
            <span>Language Reference</span>
            <span>·</span>
            <span>Balochi Alphabet & Phonology</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display mb-2">
            Balochi Orthography (آبێنک)
          </h2>
          <p className="text-sm text-emerald-100/90 leading-relaxed mb-4">
            Balochi is written in the native Balochi script (بلوچی نبشتہ راہ) alongside the standardized Latin orthography. Explore each letter, hear its phonetics, and jump directly into the Dictionary.
          </p>

          <div className="flex items-center gap-2">
            <span className="text-xs bg-white/10 px-3 py-1.5 rounded-lg border border-white/15">
              {BALOCHI_ALPHABET.length} Core Letters
            </span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-3 py-1.5 rounded-lg border border-emerald-400/30">
              Interactive Lexicon Integration
            </span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {letterTypes.map((type) => (
          <button
            key={type}
            onClick={() => setSelectedType(type)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-colors ${
              selectedType === type
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Letters Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredLetters.map((letter) => (
          <div
            key={letter.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-extrabold font-arabic text-slate-900">
                    {letter.arabic}
                  </span>
                  <span className="text-lg font-bold font-mono text-emerald-700">
                    {letter.latin}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handlePlayLetter(letter)}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      playingLetterId === letter.id
                        ? 'bg-emerald-600 text-white border-emerald-600 animate-pulse'
                        : 'border-slate-200 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50'
                    }`}
                    title={`Hear pronunciation of ${letter.nameLatin}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200">
                    {letter.phoneticType}
                  </span>
                </div>
              </div>

              {/* Name & IPA */}
              <div className="flex items-center gap-2 text-xs text-slate-500 font-mono mb-2">
                <span>{letter.nameArabic} ({letter.nameLatin})</span>
                <span>·</span>
                <span className="text-slate-700 font-semibold">{letter.ipa}</span>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                {letter.description}
              </p>
            </div>

            {/* Example Word -> Linked to Dictionary */}
            <div className="pt-3 border-t border-slate-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Example Word
              </span>
              <button
                onClick={() => handleOpenWord(letter)}
                className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/70 border border-slate-200/80 hover:border-emerald-300 transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-arabic font-bold text-slate-900 group-hover:text-emerald-950">
                      {letter.exampleWord.arabic}
                    </span>
                    <span className="text-xs font-mono text-emerald-800">
                      ({letter.exampleWord.latin})
                    </span>
                  </div>
                  <span className="text-xs text-slate-500 block">
                    {letter.exampleWord.english}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 group-hover:text-emerald-700 shrink-0">
                  <span>Lexicon</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </div>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
