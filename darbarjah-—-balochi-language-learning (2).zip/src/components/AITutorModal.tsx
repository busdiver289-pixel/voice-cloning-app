import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { playSpeech, playSoundEffect } from '../utils/audio';
import { startSpeechRecognition, isSpeechRecognitionSupportedForLanguage } from '../utils/speech';
import { extractSpokenText } from '../utils/aiTutorEngine';
import {
  Sparkles,
  Send,
  Mic,
  MicOff,
  Volume2,
  RefreshCw,
  HelpCircle,
  Eye,
  EyeOff,
  Coffee,
  ShoppingBag,
  Compass,
  MessageSquare,
  Loader2,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'tutor' | 'user';
  text: string;
  translation?: string;
  hint?: string;
  suggestions?: string[];
}

export const AITutorModal: React.FC = () => {
  const { user } = useApp();

  const getScenarios = () => {
    if (user.learningLanguage === 'balochi') {
      return [
        {
          id: 'greetings_intro',
          title: 'Meet & Greet (سلام سَنگت)',
          description: 'Say hello (Salaam), introduce your name, and ask how your friend is doing.',
          icon: MessageSquare,
          initialGreeting: 'سلام سَنگت! وَش آتکے۔ تئی نام کئے اِنت؟ (Salaam Sangat! Washh Aatke. Tai naam Kae ent?)',
          initialTranslation: 'Hello friend! Welcome. What is your name?',
          initialHint: 'Say: "Mani Naam Ali ent" (My name is Ali) or "Man wasshan" (I am fine)',
          initialSuggestions: [
            'منی نام علی انت (Mani naam Ali ent)',
            'من دراہ ءُ وش آں (Man drah o wash aan)',
            'سلام! تئی نام چے انت؟ (Salaam! Tai naam che ent?)',
          ],
        },
        {
          id: 'origin_home',
          title: 'Where Are You From? (تو کُجّیگے)',
          description: 'Ask and tell where you are from (Karachi, Quetta, Gwadar).',
          icon: Compass,
          initialGreeting: 'سلام! تو کُجّیگے؟ (Salaam! Tao kujege? - Where are you from?)',
          initialTranslation: 'Hello! Where are you from?',
          initialHint: 'Reply: "Man Karachieg aan" (I am from Karachi)',
          initialSuggestions: [
            'من کراچیگ آں (Man Karachieg aan)',
            'من کوئٹہ ءَ ننداں (Man Quetta a nandan)',
            'من گوادر ءِ زِربار ءَ آں (Man Gwadar a aan)',
          ],
        },
        {
          id: 'family_chat',
          title: 'Family & Friends (کھول ءُ سَنگت)',
          description: 'Talk about family members (Pith, Maath, Sangat).',
          icon: Coffee,
          initialGreeting: 'تئی سَنگت کئے اِنت؟ (Tai sangat Kae ent? - Who is your friend?)',
          initialTranslation: 'Who is your friend?',
          initialHint: 'Say: "Mani Sangat Ali ent" (My friend is Ali)',
          initialSuggestions: [
            'منی سنگت علی انت (Mani sangat Ali ent)',
            'منی برات ءُ گہار (Mani braat o gwhaar)',
            'سنگت باز جوانیں مردمے انت (Sangat baz jowanen mardume ent)',
          ],
        },
        {
          id: 'bazaar',
          title: 'Bazaar & Market (میلہ ءُ بازار)',
          description: 'Ask for tea (Chae), fruits, or items in the bazaar.',
          icon: ShoppingBag,
          initialGreeting: 'وَش آتکے! چماٹو ءُ پماز لوٹے؟ (Washh Aatke! Do you need tomatoes and onions?)',
          initialTranslation: 'Welcome! Do you need tomatoes and onions?',
          initialHint: 'Reply: "Minntwar!" (Thank you!) or "Yakk cup chae bade" (Give me a cup of tea)',
          initialSuggestions: [
            'یک کپ چائے بدئے (Yakk cup chae bade)',
            'بہائی چنت انت؟ (Behaaei chent ent?)',
            'ہو، چماٹو لوٹاں (Hao, chamato lotan)',
          ],
        },
      ];
    }

    if (user.learningLanguage === 'spanish') {
      return [
        {
          id: 'cafe',
          title: 'Café & Restaurant',
          description: 'Order water, coffee, and ask for the bill.',
          icon: Coffee,
          initialGreeting: '¡Hola! Bienvenido a nuestro café. ¿Qué te gustaría tomar?',
          initialTranslation: 'Hello! Welcome to our cafe. What would you like to drink?',
          initialHint: 'Say: "Un café con agua, por favor" (A coffee with water, please)',
          initialSuggestions: ['Un café con leche, por favor', 'Un vaso de agua fresca', '¿Qué me recomiendas?'],
        },
        {
          id: 'directions',
          title: 'City Directions',
          description: 'Ask where the train station or central plaza is located.',
          icon: Compass,
          initialGreeting: '¡Hola! ¿Te puedo ayudar a encontrar algún lugar?',
          initialTranslation: 'Hello! Can I help you find somewhere?',
          initialHint: 'Ask: "¿Dónde está la estación?" (Where is the station?)',
          initialSuggestions: ['¿Dónde está la estación?', 'Busco la plaza central', 'Muchas gracias'],
        },
        {
          id: 'casual',
          title: 'Friendly Chat',
          description: 'Casual greetings and asking how someone is doing.',
          icon: MessageSquare,
          initialGreeting: '¡Hola amigo! ¿Cómo estás hoy?',
          initialTranslation: 'Hello friend! How are you today?',
          initialHint: 'Reply: "Muy bien, gracias. ¿Y tú?" (Very well, thanks. And you?)',
          initialSuggestions: ['Muy bien, gracias. ¿Y tú?', 'Un poco cansado pero bien', '¡Hola! Qué gusto verte'],
        },
      ];
    }

    // Default Moroccan Darija scenarios
    return [
      {
        id: 'cafe',
        title: 'Moroccan Mint Tea Cafe',
        description: 'Order authentic tea (Atay), ask for sugar, and talk with the cafe owner.',
        icon: Coffee,
        initialGreeting: 'السلام عليكم! مرحبا بيك ف القهوة ديالنا. شنو تشرب اليوم؟ (Salam alaykum! Welcome to our cafe. What would you like to drink today?)',
        initialTranslation: 'Hello! Welcome to our cafe. What would you like to drink today?',
        initialHint: 'Say: "Atay b n3na3 afak" (Mint tea please)',
        initialSuggestions: ['أتاي بالنعناع عفاك (Atay b n3na3 afak)', 'واحد قهوة كحلة (Wahed qahwa khla)', 'بشحال هاد أتاي؟ (Bchhal had atay?)'],
      },
      {
        id: 'souk',
        title: 'Bargaining at the Souk',
        description: 'Negotiate playfully with an artisan for a handcrafted tagine or lantern.',
        icon: ShoppingBag,
        initialGreeting: 'مرحبا خويا! تفضل شوف هاد الطاجين الزوين. عجبك؟ (Marhaba khoya! Come look at this beautiful tagine. Do you like it?)',
        initialTranslation: 'Welcome brother! Come see this beautiful tagine. Do you like it?',
        initialHint: 'Ask: "Bchhal had tajine?" (How much is this tagine?)',
        initialSuggestions: ['بشحال هاد الطاجين؟ (Bchhal had tajine?)', 'نقص ليا شوية عفاك (Nqes liya chwiya)', 'زوين بزاف (Zwin bzaf)'],
      },
      {
        id: 'directions',
        title: 'Asking City Directions',
        description: 'Ask a local how to reach the old Medina, train station, or main square.',
        icon: Compass,
        initialGreeting: 'السلام عليكم، واش نقدر نعاونك؟ (Salam alaykum, can I help you with something?)',
        initialTranslation: 'Hello, can I help you with something?',
        initialHint: 'Ask: "Fin kayn Jemaa el-Fna afak?" (Where is Jemaa el-Fna please?)',
        initialSuggestions: ['فين كاين جامع الفنا عفاك؟ (Fin kayn Jemaa el-Fna?)', 'واش محطة القطار قريبة؟ (Wash l-gare qriba?)', 'شكراً بزاف خويا (Chokran bzaf)'],
      },
      {
        id: 'casual',
        title: 'Friendly Casual Chat',
        description: 'Practice everyday small talk, how are you, and introductions.',
        icon: MessageSquare,
        initialGreeting: 'أهلاً! لاباس عليك؟ كيدوز نهارك؟ (Ahlan! Labas alik? How is your day going?)',
        initialTranslation: 'Hello! How are you? How is your day going?',
        initialHint: 'Reply: "Kolchi labas lhamdoulillah, w nta?" (Everything is fine praise God, and you?)',
        initialSuggestions: ['كلشي لاباس الحمد لله (Kolchi labas lhamdoulillah)', 'كي داير نتا؟ (Ki dayer nta?)', 'نهاري زوين بزاف (Nhari zwin bzaf)'],
      },
    ];
  };

  const scenarios = getScenarios();
  const [activeScenario, setActiveScenario] = useState(scenarios[0]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showTranslations, setShowTranslations] = useState<Record<string, boolean>>({});
  const [isRecording, setIsRecording] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Update scenario if language changes
  useEffect(() => {
    setActiveScenario(scenarios[0]);
  }, [user.learningLanguage]);

  // Initialize first message when scenario changes
  useEffect(() => {
    setMessages([
      {
        id: 'msg_0',
        sender: 'tutor',
        text: activeScenario.initialGreeting,
        translation: activeScenario.initialTranslation,
        hint: activeScenario.initialHint,
        suggestions: activeScenario.initialSuggestions || [],
      },
    ]);
    setShowTranslations({});
    setInputText('');
    setIsRecording(false);
    setVoiceNotice(null);
  }, [activeScenario]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleResetConversation = () => {
    setMessages([
      {
        id: `msg_reset_${Date.now()}`,
        sender: 'tutor',
        text: activeScenario.initialGreeting,
        translation: activeScenario.initialTranslation,
        hint: activeScenario.initialHint,
        suggestions: activeScenario.initialSuggestions || [],
      },
    ]);
    setShowTranslations({});
    setInputText('');
    setIsRecording(false);
    playSoundEffect('click', user.settings.soundEffects);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    setInputText('');
    setVoiceNotice(null);

    const newMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sender: 'user',
      text,
    };

    const updatedHistory = [...messages, newMsg];
    setMessages(updatedHistory);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          language: user.learningLanguage,
          scenario: `${activeScenario.title}: ${activeScenario.description}`,
          messages: updatedHistory.map((m) => ({
            sender: m.sender === 'user' ? 'Learner' : 'Tutor',
            text: m.text,
          })),
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const replyMsg: ChatMessage = {
          id: `msg_tutor_${Date.now()}`,
          sender: 'tutor',
          text: data.reply,
          translation: data.translation,
          hint: data.hint,
          suggestions: Array.isArray(data.suggestions) ? data.suggestions : [],
        };
        setMessages((prev) => [...prev, replyMsg]);
        playSoundEffect('correct', user.settings.soundEffects);
      } else {
        throw new Error('Tutor response failed');
      }
    } catch {
      // Seamless contextual fallback message
      const fallbackMsg: ChatMessage = {
        id: `msg_fallback_${Date.now()}`,
        sender: 'tutor',
        text:
          user.learningLanguage === 'balochi'
            ? 'باز وش سَنگت! تئی گپ باز جوان انت، بیا دگہ گپ کنیں (Baz wash sangat! Tai gapp baz jowan ent, bya diga gapp kanen)'
            : 'Very well said! Let us continue our practice conversation.',
        translation: 'Very fine friend! Your words are good, let us converse further.',
        hint:
          user.learningLanguage === 'balochi'
            ? 'Say: "Minntwar!" (Thank you!) or "Tao choni?" (How are you?)'
            : 'Keep going!',
        suggestions: [
          'باز منتوار واجہ (Baz minntwar waja)',
          'تئی هال چوں انت؟ (Tai haal chon ent?)',
          'پدا گندیں (Pada ginden)',
        ],
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleVoice = () => {
    if (!isSpeechRecognitionSupportedForLanguage(user.learningLanguage)) {
      setVoiceNotice('Voice input is not supported in this browser.');
      setTimeout(() => setVoiceNotice(null), 3500);
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      setVoiceNotice(null);
    } else {
      setIsRecording(true);
      setVoiceNotice(
        user.learningLanguage === 'balochi'
          ? 'Balochi speech beta — speak slowly'
          : 'Listening... Speak now'
      );
      startSpeechRecognition(
        user.learningLanguage,
        (transcript, isFinal) => {
          setInputText(transcript);
          if (isFinal) {
            setIsRecording(false);
            setVoiceNotice(null);
          }
        },
        (error: string) => {
          setIsRecording(false);
          setVoiceNotice(`Voice input: ${error}`);
          setTimeout(() => setVoiceNotice(null), 3000);
        },
        () => {
          setIsRecording(false);
          setVoiceNotice(null);
        }
      );
    }
  };

  const toggleTranslation = (msgId: string) => {
    setShowTranslations((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  // Find latest active suggestions from tutor
  const latestTutorMsg = [...messages].reverse().find((m) => m.sender === 'tutor');
  const activeSuggestions = latestTutorMsg?.suggestions || [];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-display">
              AI Conversation Roleplay
            </h1>
          </div>
          <p className="text-slate-500 text-sm">
            Practice conversational speaking in realistic everyday scenarios with immediate native translation, audio, and feedback.
          </p>
        </div>
      </div>

      {/* Scenario Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {scenarios.map((sc) => {
          const Icon = sc.icon;
          const isActive = activeScenario.id === sc.id;
          return (
            <button
              key={sc.id}
              onClick={() => setActiveScenario(sc)}
              className={`p-3.5 rounded-xl border text-left transition-all min-h-[44px] ${
                isActive
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm ring-1 ring-emerald-600'
                  : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
              }`}
            >
              <Icon className={`w-5 h-5 mb-2 ${isActive ? 'text-emerald-700' : 'text-slate-500'}`} />
              <div className="font-bold text-xs">{sc.title}</div>
            </button>
          );
        })}
      </div>

      {/* Chat Window */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[540px] overflow-hidden">
        {/* Scenario Header with Reset Option */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
              AI
            </div>
            <div>
              <span className="font-bold text-slate-900 text-xs block">
                Native Language Partner ({activeScenario.title})
              </span>
              <span className="text-[11px] text-slate-500">
                Speaks in {user.learningLanguage === 'balochi' ? 'Balochi (بلوچی)' : user.learningLanguage}
              </span>
            </div>
          </div>

          <button
            onClick={handleResetConversation}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-emerald-700 bg-white hover:bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-lg transition-colors shadow-xs"
            title="Restart current conversation scenario"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Restart</span>
          </button>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-md p-4 rounded-2xl text-sm ${
                  msg.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-br-none shadow-sm'
                    : 'bg-slate-100 text-slate-900 rounded-bl-none border border-slate-200/60'
                }`}
              >
                <div className="font-arabic text-base font-semibold leading-relaxed">
                  {msg.text}
                </div>

                {/* Translation toggle & audio for tutor message */}
                {msg.sender === 'tutor' && msg.translation && (
                  <div className="mt-2 pt-2 border-t border-slate-200/60">
                    {showTranslations[msg.id] ? (
                      <p className="text-xs text-slate-600 italic">
                        {msg.translation}
                      </p>
                    ) : null}

                    <div className="flex items-center gap-3 mt-1.5 text-[11px] text-slate-500">
                      <button
                        onClick={() => toggleTranslation(msg.id)}
                        className="hover:text-slate-900 flex items-center gap-1 font-medium underline"
                      >
                        {showTranslations[msg.id] ? (
                          <>
                            <EyeOff className="w-3 h-3" /> Hide Translation
                          </>
                        ) : (
                          <>
                            <Eye className="w-3 h-3" /> Show English
                          </>
                        )}
                      </button>

                      <button
                        onClick={() =>
                          playSpeech(extractSpokenText(msg.text), user.learningLanguage, {
                            useGemini: user.settings.useGeminiVoice,
                          })
                        }
                        className="hover:text-emerald-700 flex items-center gap-1 font-medium"
                      >
                        <Volume2 className="w-3 h-3" /> Listen
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Hint badge */}
              {msg.sender === 'tutor' && msg.hint && (
                <div className="text-[11px] text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md mt-1.5 border border-emerald-100 flex items-center gap-1.5">
                  <HelpCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                  <span>Idea: {msg.hint}</span>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs py-1">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
              <span>Language partner is replying...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Voice notification status if active */}
        {voiceNotice && (
          <div className="px-4 py-1.5 bg-amber-50 border-t border-amber-200 text-amber-800 text-xs flex items-center justify-between">
            <span>{voiceNotice}</span>
            <button
              onClick={() => setVoiceNotice(null)}
              className="text-[10px] text-amber-700 underline font-bold"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Interactive Quick Reply Suggestions */}
        {activeSuggestions.length > 0 && !isLoading && (
          <div className="px-3 py-2 bg-slate-50/90 border-t border-slate-200/60 flex items-center gap-2 overflow-x-auto">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" /> Quick Reply:
            </span>
            {activeSuggestions.map((sug, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(sug)}
                className="text-xs bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 rounded-lg px-2.5 py-1 whitespace-nowrap transition-colors shadow-xs shrink-0 font-medium"
              >
                {sug}
              </button>
            ))}
          </div>
        )}

        {/* Input Bar */}
        <div className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
          <button
            onClick={handleToggleVoice}
            className={`p-2.5 rounded-xl border transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${
              isRecording
                ? 'bg-rose-500 text-white border-rose-500 animate-pulse'
                : 'border-slate-200 text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
            title={
              isRecording
                ? 'Listening... Tap to finish'
                : user.learningLanguage === 'balochi'
                ? 'Balochi speech beta — speak slowly'
                : 'Speak into microphone'
            }
            disabled={false}
          >
            {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendMessage();
            }}
            placeholder={
              isRecording
                ? user.learningLanguage === 'balochi'
                  ? 'Balochi speech beta — speak slowly'
                  : 'Speak into microphone'
                : user.learningLanguage === 'balochi'
                ? 'Balochi speech beta — speak slowly or type...'
                : `Reply in ${user.learningLanguage} or English...`
            }
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!inputText.trim() || isLoading}
            className={`p-2.5 rounded-xl text-white transition-all min-h-[44px] min-w-[44px] flex items-center justify-center ${
              inputText.trim() && !isLoading
                ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95'
                : 'bg-slate-200 cursor-not-allowed text-slate-400'
            }`}
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

