import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_ACHIEVEMENTS } from '../data/achievements';
import {
  Flame,
  Star,
  Award,
  Zap,
  Target,
  Settings,
  RotateCcw,
  Check,
  Volume2,
  Mic,
  Shield,
  User,
  Terminal,
  Share2,
  LogOut,
  Sparkles,
} from 'lucide-react';

interface ProfileViewProps {
  onOpenDiagnostics?: () => void;
  isDevMode?: boolean;
  onToggleDevMode?: () => void;
  onOpenAuthModal?: () => void;
  onOpenShareModal?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onOpenDiagnostics,
  isDevMode = false,
  onToggleDevMode,
  onOpenAuthModal,
  onOpenShareModal,
}) => {
  const {
    user,
    levelInfo,
    vocabList,
    claimAchievement,
    updateSettings,
    resetAllProgress,
    unlockAllCourseLessons,
    logout,
  } = useApp();

  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [secretClickCount, setSecretClickCount] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleSecretClick = () => {
    const next = secretClickCount + 1;
    setSecretClickCount(next);
    if (next >= 5) {
      onToggleDevMode?.();
      setToastMessage('Developer Mode Active! Lexicon Diagnostic Engine enabled.');
      setTimeout(() => setToastMessage(null), 3500);
      setSecretClickCount(0);
    }
  };

  const avgMastery =
    vocabList.length > 0
      ? Math.round(
          vocabList.reduce((acc, v) => acc + (v.masteryScore || 0), 0) /
            vocabList.length
        )
      : 0;
  const masteredWords = vocabList.filter(
    (v) => (v.masteryScore || 0) >= 80
  ).length;

  // Past 7 days calendar generator
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const dateStr = d.toISOString().split('T')[0];
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const isActive = user.activeDates.includes(dateStr);
    return { dateStr, dayName, isActive };
  });

  const dailyGoalOptions = [
    { label: 'Casual', xp: 10 },
    { label: 'Regular', xp: 20 },
    { label: 'Serious', xp: 30 },
    { label: 'Intense', xp: 50 },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* User Header Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col sm:flex-row items-center sm:items-start gap-6">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center text-3xl font-bold shadow-md shrink-0 font-display">
          {user.username.slice(0, 1).toUpperCase()}
        </div>

        <div className="flex-1 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-display">
                {user.username}
              </h1>
              <p className="text-xs text-slate-500">
                {user.authProvider === 'phone'
                  ? `${user.countryCode || ''} ${user.phoneNumber || ''}`
                  : user.email}
              </p>
              <div className="flex items-center gap-2.5 mt-1.5 flex-wrap">
                {user.isAuthenticated ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-600" />
                    <span>
                      {user.authProvider === 'google'
                        ? 'Google Account'
                        : user.authProvider === 'phone'
                        ? 'Phone Verified'
                        : 'Registered Account'}
                    </span>
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                    Guest Account (Local)
                  </span>
                )}
                {user.isAuthenticated ? (
                  <button
                    onClick={logout}
                    className="text-[11px] text-slate-500 hover:text-rose-600 font-semibold flex items-center gap-1 transition-colors"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>Sign Out</span>
                  </button>
                ) : (
                  onOpenAuthModal && (
                    <button
                      onClick={onOpenAuthModal}
                      className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold underline transition-colors"
                    >
                      Sign In / Register
                    </button>
                  )
                )}
              </div>
            </div>

            <div className="flex items-center justify-center sm:justify-end gap-3 text-xs font-semibold">
              <span className="text-emerald-700 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-200">
                Native: {user.nativeLanguage}
              </span>
              <span className="text-blue-700 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200 uppercase">
                Learning: {user.learningLanguage}
              </span>
            </div>
          </div>

          {/* Level Progress Bar */}
          <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <span className="text-slate-800 flex items-center gap-1.5">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                Level {levelInfo.level} Scholar
              </span>
              <span className="text-slate-500 font-mono">
                {user.xp} Total XP ({levelInfo.currentLevelXp} / {levelInfo.nextLevelXp} XP to Level {levelInfo.level + 1})
              </span>
            </div>
            <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${levelInfo.progressPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Community Sharing Link Card */}
      {onOpenShareModal && (
        <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 border border-emerald-700/40">
          <div className="flex items-center gap-3.5 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center border border-emerald-400/30 shrink-0">
              <Share2 className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h3 className="text-base font-bold font-display text-white">
                  Share Darbarjah With Friends
                </h3>
                <span className="text-[10px] font-extrabold uppercase bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-400/30">
                  +25 Gems
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Invite friends via WhatsApp, Telegram, or copy link to learn Balochi together!
              </p>
            </div>
          </div>

          <button
            onClick={onOpenShareModal}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-95 shrink-0 flex items-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            <span>Open Sharing Link</span>
          </button>
        </div>
      )}

      {/* USER PROGRESS: XP · MASTERY · STREAK */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Metric 1: XP */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
            <Star className="w-6 h-6 fill-amber-500" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              User Progress · XP
            </span>
            <div className="text-2xl font-extrabold text-slate-900 font-display">
              {user.xp} <span className="text-xs font-normal text-slate-500">XP</span>
            </div>
            <span className="text-xs text-slate-500">Level {levelInfo.level} Scholar</span>
          </div>
        </div>

        {/* Metric 2: Mastery */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              User Progress · Mastery
            </span>
            <div className="text-2xl font-extrabold text-slate-900 font-display">
              {avgMastery}%
            </div>
            <span className="text-xs text-slate-500">{masteredWords} words mastered</span>
          </div>
        </div>

        {/* Metric 3: Streak */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-orange-50 text-orange-500 flex items-center justify-center shrink-0">
            <Flame className="w-6 h-6 fill-orange-500" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              User Progress · Streak
            </span>
            <div className="text-2xl font-extrabold text-slate-900 font-display">
              {user.streak} <span className="text-xs font-normal text-slate-500">Days</span>
            </div>
            <span className="text-xs text-slate-500">Best: {user.longestStreak} days</span>
          </div>
        </div>
      </div>

      {/* Streak & Activity 7-Day History */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
            <h2 className="text-base font-bold text-slate-900 font-display">
              {user.streak} Day Learning Streak
            </h2>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            Longest Streak: {user.longestStreak} days
          </span>
        </div>

        {/* 7-day pill calendar */}
        <div className="grid grid-cols-7 gap-2">
          {last7Days.map((day) => (
            <div
              key={day.dateStr}
              className={`p-3 rounded-xl border text-center transition-all ${
                day.isActive
                  ? 'border-amber-300 bg-amber-50 text-amber-900 font-bold'
                  : 'border-slate-200 bg-slate-50 text-slate-400'
              }`}
            >
              <span className="text-[11px] block uppercase mb-1">{day.dayName}</span>
              <div className="w-6 h-6 mx-auto rounded-full flex items-center justify-center">
                {day.isActive ? (
                  <Check className="w-4 h-4 text-amber-600 stroke-[3]" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-slate-300" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Goal Configuration */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <Target className="w-5 h-5 text-emerald-600" />
          <h2 className="text-base font-bold text-slate-900 font-display">
            Daily Goal Target
          </h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Choose a comfortable daily XP target to build a lasting language routine.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {dailyGoalOptions.map((opt) => {
            const isSelected = user.dailyGoalXp === opt.xp;
            return (
              <button
                key={opt.xp}
                onClick={() => updateSettings({} as any)} // we can update dailyGoal in user
                className={`p-3.5 rounded-xl border text-center transition-all ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600 font-bold'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <span className="block text-sm font-semibold">{opt.label}</span>
                <span className="block text-xs text-slate-500 font-mono mt-0.5">
                  {opt.xp} XP / day
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Achievements Showcase */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Award className="w-5 h-5 text-amber-500" />
          <h2 className="text-base font-bold text-slate-900 font-display">
            Achievements & Rewards
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {INITIAL_ACHIEVEMENTS.map((ach) => {
            const currentVal = ach.currentValue(user);
            const isComplete = currentVal >= ach.requirement;
            const isClaimed = user.claimedAchievements.includes(ach.id);

            return (
              <div
                key={ach.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{ach.name}</span>
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      +{ach.gemReward} 💎
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{ach.description}</p>
                  <div className="text-[11px] text-slate-400 font-mono mt-1">
                    Progress: {Math.min(ach.requirement, currentVal)} / {ach.requirement}
                  </div>
                </div>

                {isClaimed ? (
                  <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1.5 rounded-lg shrink-0">
                    Claimed
                  </span>
                ) : isComplete ? (
                  <button
                    onClick={() => claimAchievement(ach.id)}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all shrink-0 animate-bounce"
                  >
                    Claim Reward
                  </button>
                ) : (
                  <span className="text-xs text-slate-400 border border-slate-200 px-2.5 py-1 rounded-lg shrink-0">
                    In progress
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Settings & Controls */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-5 h-5 text-slate-700" />
          <h2 className="text-base font-bold text-slate-900 font-display">
            Audio & Practice Settings
          </h2>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between py-2 border-b border-slate-100">
            <div>
              <span className="text-sm font-semibold text-slate-800 block">Sound Effects</span>
              <span className="text-xs text-slate-500">Play chimes on correct and incorrect answers</span>
            </div>
            <button
              onClick={() => updateSettings({ soundEffects: !user.settings.soundEffects })}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                user.settings.soundEffects ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 left-0.5 ${
                  user.settings.soundEffects ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-slate-100">
            <div>
              <span className="text-sm font-semibold text-slate-800 block">Auto-Play Native Audio</span>
              <span className="text-xs text-slate-500">Automatically speak foreign phrases on new questions</span>
            </div>
            <button
              onClick={() => updateSettings({ autoPlayAudio: !user.settings.autoPlayAudio })}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                user.settings.autoPlayAudio ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 left-0.5 ${
                  user.settings.autoPlayAudio ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-slate-100">
            <div>
              <span className="text-sm font-semibold text-slate-800 block">Gemini High-Fidelity Voice</span>
              <span className="text-xs text-slate-500">Use server-side AI native pronunciation model</span>
            </div>
            <button
              onClick={() => updateSettings({ useGeminiVoice: !user.settings.useGeminiVoice })}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                user.settings.useGeminiVoice ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 left-0.5 ${
                  user.settings.useGeminiVoice ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Preferred Practice Type */}
          <div className="py-2 border-b border-slate-100">
            <span className="text-sm font-semibold text-slate-800 block mb-1">
              User's Preferred Practice Type (Recommendation Factor #7)
            </span>
            <span className="text-xs text-slate-500 block mb-3">
              Guides the "Recommended Next" algorithm to prioritize your favorite learning style.
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(
                [
                  { id: 'balanced', label: 'Balanced Mix', desc: 'Equal skills' },
                  { id: 'listening', label: 'Listening Focus', desc: 'Audio sprints' },
                  { id: 'speaking', label: 'Speaking Focus', desc: 'Voice drills' },
                  { id: 'quiz', label: 'Quiz Focus', desc: 'Word assembly' },
                ] as const
              ).map((mode) => {
                const isSelected =
                  (user.settings?.preferredPracticeType || 'balanced') === mode.id;
                return (
                  <button
                    key={mode.id}
                    onClick={() =>
                      updateSettings({ preferredPracticeType: mode.id })
                    }
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 ring-1 ring-emerald-600'
                        : 'border-slate-200 bg-slate-50 hover:bg-white text-slate-700'
                    }`}
                  >
                    <span className="text-xs font-bold block">{mode.label}</span>
                    <span className="text-[11px] text-slate-500 block">
                      {mode.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Difficulty Preference */}
          <div className="py-2 border-b border-slate-100">
            <span className="text-sm font-semibold text-slate-800 block mb-1">
              Target Difficulty (Recommendation Factor #6)
            </span>
            <span className="text-xs text-slate-500 block mb-3">
              Controls whether exercises adapt automatically or lock to a preferred level.
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(
                [
                  { id: 'adaptive', label: 'Adaptive Auto', desc: 'Scales with errors' },
                  { id: 'beginner', label: 'Beginner', desc: 'High guidance' },
                  { id: 'intermediate', label: 'Intermediate', desc: 'Full recall' },
                  { id: 'advanced', label: 'Advanced', desc: 'Fast drills' },
                ] as const
              ).map((diff) => {
                const isSelected =
                  (user.settings?.difficultyPreference || 'adaptive') === diff.id;
                return (
                  <button
                    key={diff.id}
                    onClick={() =>
                      updateSettings({ difficultyPreference: diff.id })
                    }
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 ring-1 ring-emerald-600'
                        : 'border-slate-200 bg-slate-50 hover:bg-white text-slate-700'
                    }`}
                  >
                    <span className="text-xs font-bold block">{diff.label}</span>
                    <span className="text-[11px] text-slate-500 block">
                      {diff.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Developer / Progress Tools */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={unlockAllCourseLessons}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 underline"
          >
            Unlock all lessons in current track (Explorer Mode)
          </button>

          <div className="flex items-center gap-3">
            {isDevMode && onOpenDiagnostics && (
              <button
                onClick={onOpenDiagnostics}
                className="text-xs font-mono font-bold bg-slate-900 text-emerald-400 hover:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1.5 shadow-sm transition-all"
                title="Open Lexicon Diagnostics Dashboard (Ctrl+Shift+D)"
              >
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span>Dev Diagnostics</span>
              </button>
            )}

            <button
              onClick={() => setShowResetConfirm(true)}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo Progress</span>
            </button>
          </div>
        </div>

        {/* Discreet Version Footer & Secret 5-Click Developer Easter Egg */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
          <button
            onClick={handleSecretClick}
            className="hover:text-slate-600 transition-colors text-left font-mono"
            title="Darbarjah Balochi Edition"
          >
            <span>Darbarjah Balochi · Build v2.5.0</span>
            {secretClickCount > 0 && secretClickCount < 5 && (
              <span className="ml-2 text-emerald-600 font-bold">
                ({5 - secretClickCount} more clicks to unlock dev mode)
              </span>
            )}
          </button>

          <span className="text-[10px] text-slate-400 font-mono">
            Shortcut: Ctrl+Shift+D
          </span>
        </div>

        {toastMessage && (
          <div className="mt-3 p-2.5 rounded-xl bg-slate-900 border border-emerald-500/50 text-emerald-300 text-xs font-mono text-center shadow-lg animate-fade-in">
            {toastMessage}
          </div>
        )}
      </div>

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 text-center">
            <h3 className="font-bold text-lg text-slate-900 font-display mb-2">
              Reset learning progress?
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              This will restore initial demo state, clearing your completed lessons, mastery records, and mistakes.
            </p>
            <div className="space-y-2">
              <button
                onClick={() => {
                  resetAllProgress();
                  setShowResetConfirm(false);
                }}
                className="w-full py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs hover:bg-rose-700"
              >
                Confirm Reset
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="w-full py-2.5 rounded-xl border border-slate-200 text-slate-600 font-semibold text-xs hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
