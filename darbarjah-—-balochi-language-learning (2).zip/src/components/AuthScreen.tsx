import React, { useState } from 'react';
import {
  signInWithPopup,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { Sparkles, AlertCircle, ArrowRight, ShieldCheck, Mail, Lock, Check } from 'lucide-react';

interface AuthScreenProps {
  onAuthed: () => void;
  onSkip?: () => void;
}

export default function AuthScreen({ onAuthed, onSkip }: AuthScreenProps) {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      onAuthed();
    } catch (err: any) {
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Google sign in failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmail = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!email.trim() || !pass.trim()) {
      setError('Please provide both email and password.');
      return;
    }
    if (pass.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setError(null);
    setLoading(true);
    try {
      if (mode === 'signup') {
        await createUserWithEmailAndPassword(auth, email.trim(), pass);
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), pass);
      }
      onAuthed();
    } catch (err: any) {
      let msg = err.message || 'Authentication failed.';
      if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please switch to Log In.';
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0a2e24] text-white p-6 relative overflow-hidden selection:bg-emerald-500 selection:text-white">
      {/* Background Islamic Geometric & Radial Glow */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]" />
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-emerald-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Brand Header */}
      <div className="text-center z-10 mb-8 max-w-md">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-800/60 border border-emerald-600/40 text-emerald-200 text-xs font-semibold mb-4 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Firebase Cloud Sync Enabled</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black mb-2 tracking-tight">
          Darbarjah - درباجه
        </h1>
        <p className="text-emerald-100/75 text-sm sm:text-base font-medium">
          Balochi Language Learning - بلوچی زبان
        </p>
      </div>

      {/* Main Auth Card */}
      <div className="w-full max-w-sm bg-white/10 backdrop-blur-md rounded-2xl p-6 sm:p-7 border border-white/15 shadow-2xl z-10">
        {/* Toggle Mode */}
        <div className="flex bg-black/25 rounded-xl p-1 mb-5">
          <button
            type="button"
            onClick={() => { setMode('signup'); setError(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              mode === 'signup'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-white/60 hover:text-white'
            }`}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => { setMode('login'); setError(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-white/60 hover:text-white'
            }`}
          >
            Log In
          </button>
        </div>

        {/* Google OAuth Button */}
        <button
          onClick={handleGoogle}
          disabled={loading}
          className="w-full bg-white hover:bg-slate-100 text-slate-900 py-3 px-4 rounded-xl font-semibold flex items-center justify-center gap-3 transition-all transform active:scale-[0.98] shadow-md disabled:opacity-60 cursor-pointer"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <div className="flex items-center gap-3 my-4">
          <div className="flex-1 h-px bg-white/15" />
          <span className="text-xs uppercase tracking-wider text-white/50 font-semibold">or email</span>
          <div className="flex-1 h-px bg-white/15" />
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Email & Password Form */}
        <form onSubmit={handleEmail} className="space-y-3">
          <div className="relative">
            <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-white/40 pointer-events-none" />
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              type="email"
              required
              className="w-full bg-black/25 border border-white/10 rounded-xl pl-10 pr-3 py-2.5 text-white placeholder-white/40 text-sm focus:outline-none focus:border-emerald-400 transition-colors"
            />
          </div>

          <div className="relative">
            <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-white/40 pointer-events-none" />
            <input
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              type="password"
              placeholder="Password (min 6 characters)"
              required
              className="w-full bg-black/25 border border-white/10 rounded-xl pl-10 pr-3 py-2.5 text-white placeholder-white/40 text-sm focus:outline-none focus:border-emerald-400 transition-colors"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 transition-all transform active:scale-[0.98] disabled:opacity-60 cursor-pointer"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'signup' ? 'Create Account' : 'Log In'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Security badge */}
        <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-white/50">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Secure Firebase Auth</span>
          </div>
          {onSkip && (
            <button
              onClick={onSkip}
              className="text-emerald-300 hover:text-white underline underline-offset-2 transition-colors cursor-pointer"
            >
              Continue as Guest
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
