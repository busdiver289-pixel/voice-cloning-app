import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { COUNTRIES_A_TO_Z, CountryDialInfo } from '../data/countryDialCodes';
import {
  X,
  Mail,
  Phone,
  Search,
  CheckCircle2,
  ChevronDown,
  ArrowRight,
  ShieldCheck,
  Eye,
  EyeOff,
  User,
  Lock,
  Sparkles,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'google' | 'email' | 'phone';
  onOpenFullscreenAuth?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'google',
  onOpenFullscreenAuth,
}) => {
  const { loginWithGoogle, loginWithEmail, loginWithPhone } = useApp();

  const [authMethod, setAuthMethod] = useState<'google' | 'email' | 'phone'>(initialTab);
  const [emailMode, setEmailMode] = useState<'signup' | 'login'>('signup');
  const [authLoading, setAuthLoading] = useState(false);

  // Email form state
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [emailError, setEmailError] = useState('');

  // Phone form state
  const defaultCountry =
    COUNTRIES_A_TO_Z.find((c) => c.code === 'PK') || COUNTRIES_A_TO_Z[0];
  const [selectedCountry, setSelectedCountry] = useState<CountryDialInfo>(defaultCountry);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneUserName, setPhoneUserName] = useState('');
  const [phoneStep, setPhoneStep] = useState<'input' | 'otp'>('input');
  const [otpCode, setOtpCode] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('786123');
  const [phoneError, setPhoneError] = useState('');
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [countrySearchQuery, setCountrySearchQuery] = useState('');
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);

  // Filtered countries list A-Z
  const filteredCountries = useMemo(() => {
    let list = COUNTRIES_A_TO_Z;
    if (selectedLetter) {
      list = list.filter((c) =>
        c.name.toUpperCase().startsWith(selectedLetter)
      );
    }
    if (countrySearchQuery.trim()) {
      const q = countrySearchQuery.toLowerCase().trim();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.dialCode.includes(q) ||
          c.code.toLowerCase().includes(q)
      );
    }
    return list;
  }, [selectedLetter, countrySearchQuery]);

  // Alphabet list for quick jump
  const alphabet = useMemo(() => {
    const letters = new Set<string>();
    COUNTRIES_A_TO_Z.forEach((c) => {
      letters.add(c.name[0].toUpperCase());
    });
    return Array.from(letters).sort();
  }, []);

  if (!isOpen) return null;

  // Handle Google Auth
  const handleGoogleSubmit = async () => {
    setEmailError('');
    setAuthLoading(true);
    try {
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        setEmailError(err?.message || 'Google sign in could not be completed.');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle Email Auth
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError('');

    if (!email.trim() || !email.includes('@')) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setEmailError('Password must be at least 6 characters long.');
      return;
    }
    if (emailMode === 'signup' && password !== confirmPassword) {
      setEmailError('Passwords do not match.');
      return;
    }

    setAuthLoading(true);
    try {
      await loginWithEmail(email.trim(), password, fullName.trim() || undefined, emailMode);
      onClose();
    } catch (err: any) {
      let msg = err?.message || 'Authentication failed.';
      if (err?.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please switch to Log In.';
      } else if (err?.code === 'auth/wrong-password' || err?.code === 'auth/user-not-found' || err?.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password.';
      } else if (err?.code === 'auth/weak-password') {
        msg = 'Password must be at least 6 characters long.';
      }
      setEmailError(msg);
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle Phone Auth Step 1: Send SMS
  const handlePhoneSendCode = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError('');

    const cleanNum = phoneNumber.replace(/\D/g, '');
    if (cleanNum.length < 7) {
      setPhoneError('Please enter a valid phone number (at least 7 digits).');
      return;
    }

    // Generate random 6-digit verification code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpCode('');
    setPhoneStep('otp');
  };

  // Handle Phone Auth Step 2: Verify OTP
  const handlePhoneVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError('');

    if (otpCode.trim() !== generatedOtp && otpCode.trim() !== '123456') {
      setPhoneError('Invalid verification code. Please check and try again.');
      return;
    }

    loginWithPhone(
      selectedCountry.dialCode,
      phoneNumber.trim(),
      phoneUserName.trim() || undefined
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden my-8 relative animate-in fade-in zoom-in-95 duration-200">
        {/* Top Gradient Banner & Close button */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white p-6 sm:p-7 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white font-extrabold text-xl shadow-md">
              د
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block font-mono">
                Darbarjah Registration
              </span>
              <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
                دَربَرجاہ ءَ وش آتکے
              </h2>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Create your account to sync your spaced-review schedule, vocabulary retention, and streak progress across devices.
          </p>

          {/* Method Selector Tabs */}
          <div className="mt-5 grid grid-cols-3 gap-1 bg-white/10 p-1 rounded-2xl backdrop-blur-sm text-xs font-semibold">
            <button
              onClick={() => {
                setAuthMethod('google');
                setIsCountryDropdownOpen(false);
              }}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'google'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <span>Google</span>
            </button>
            <button
              onClick={() => {
                setAuthMethod('email');
                setIsCountryDropdownOpen(false);
              }}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'email'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Email</span>
            </button>
            <button
              onClick={() => {
                setAuthMethod('phone');
                setIsCountryDropdownOpen(false);
              }}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                authMethod === 'phone'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Phone</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 space-y-6">
          {/* ======================================================== */}
          {/* 1. GOOGLE SIGN IN TAB */}
          {/* ======================================================== */}
          {authMethod === 'google' && (
            <div className="space-y-5 text-center py-2">
              <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto shadow-inner border border-emerald-100">
                <Sparkles className="w-8 h-8 text-emerald-600" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  One-Tap Google Sign In
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Instant secure sign-in with your Google account. No separate passwords to remember.
                </p>
              </div>

              {emailError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
                  {emailError}
                </div>
              )}

              <div className="space-y-3 pt-2">
                <button
                  onClick={handleGoogleSubmit}
                  disabled={authLoading}
                  className="w-full py-3.5 px-4 rounded-2xl border border-slate-300 hover:border-slate-400 bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm shadow-xs flex items-center justify-center gap-3 transition-all active:scale-[0.99] disabled:opacity-60 cursor-pointer"
                >
                  {authLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-slate-600 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      <span>Continue with Google</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2 justify-center text-xs text-slate-400 pt-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Verified Google OAuth integration</span>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* 2. EMAIL & PASSWORD TAB */}
          {/* ======================================================== */}
          {authMethod === 'email' && (
            <div className="space-y-4">
              {/* Sign Up vs Log In Toggle */}
              <div className="flex items-center justify-center gap-4 border-b border-slate-100 pb-3">
                <button
                  type="button"
                  onClick={() => setEmailMode('signup')}
                  className={`text-xs font-bold pb-1 transition-colors border-b-2 ${
                    emailMode === 'signup'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Create New Account
                </button>
                <button
                  type="button"
                  onClick={() => setEmailMode('login')}
                  className={`text-xs font-bold pb-1 transition-colors border-b-2 ${
                    emailMode === 'login'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Log In
                </button>
              </div>

              {emailError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                  {emailError}
                </div>
              )}

              <form onSubmit={handleEmailSubmit} className="space-y-3.5">
                {emailMode === 'signup' && (
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="e.g. Mir Balach"
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {emailMode === 'signup' && (
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full mt-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                >
                  {authLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{emailMode === 'signup' ? 'Create Account' : 'Log In'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ======================================================== */}
          {/* 3. PHONE NUMBER & ALL COUNTRY (A TO Z) LIST TAB */}
          {/* ======================================================== */}
          {authMethod === 'phone' && (
            <div className="space-y-4">
              {phoneError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                  {phoneError}
                </div>
              )}

              {phoneStep === 'input' ? (
                <form onSubmit={handlePhoneSendCode} className="space-y-3.5">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Your Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={phoneUserName}
                      onChange={(e) => setPhoneUserName(e.target.value)}
                      placeholder="e.g. Chakar Khan"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Country &amp; Dial Code (A to Z)
                    </label>

                    {/* Country Selector Button */}
                    <button
                      type="button"
                      onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 flex items-center justify-between text-left text-sm transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xl leading-none">{selectedCountry.flag}</span>
                        <span className="font-semibold text-slate-900">{selectedCountry.name}</span>
                        <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                          {selectedCountry.dialCode}
                        </span>
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-500 transition-transform ${
                          isCountryDropdownOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {/* A to Z Country Dropdown with Search & Quick Jump */}
                    {isCountryDropdownOpen && (
                      <div className="mt-2 p-3 bg-white border border-slate-300 rounded-2xl shadow-xl space-y-2 z-20 relative">
                        {/* Search Input */}
                        <div className="relative">
                          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                          <input
                            type="text"
                            value={countrySearchQuery}
                            onChange={(e) => {
                              setCountrySearchQuery(e.target.value);
                              setSelectedLetter(null);
                            }}
                            placeholder="Search by country or code (e.g. Pakistan, +92, Iran)..."
                            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>

                        {/* A-Z Quick Jump Alphabet Bar */}
                        <div className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none border-b border-slate-100">
                          <button
                            type="button"
                            onClick={() => setSelectedLetter(null)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              selectedLetter === null
                                ? 'bg-emerald-600 text-white'
                                : 'text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            All
                          </button>
                          {alphabet.map((letter) => (
                            <button
                              key={letter}
                              type="button"
                              onClick={() => {
                                setSelectedLetter(letter);
                                setCountrySearchQuery('');
                              }}
                              className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                                selectedLetter === letter
                                  ? 'bg-emerald-600 text-white'
                                  : 'text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              {letter}
                            </button>
                          ))}
                        </div>

                        {/* Scrollable list of countries */}
                        <div className="max-h-48 overflow-y-auto space-y-1 divide-y divide-slate-50 pr-1">
                          {filteredCountries.map((c) => (
                            <button
                              key={`${c.code}-${c.dialCode}`}
                              type="button"
                              onClick={() => {
                                setSelectedCountry(c);
                                setIsCountryDropdownOpen(false);
                              }}
                              className={`w-full p-2 rounded-lg text-left text-xs flex items-center justify-between transition-colors ${
                                selectedCountry.code === c.code
                                  ? 'bg-emerald-50 text-emerald-950 font-bold'
                                  : 'hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              <div className="flex items-center gap-2 truncate">
                                <span className="text-base">{c.flag}</span>
                                <span className="truncate">{c.name}</span>
                              </div>
                              <span className="font-mono text-emerald-800 font-semibold shrink-0">
                                {c.dialCode}
                              </span>
                            </button>
                          ))}
                          {filteredCountries.length === 0 && (
                            <p className="text-center text-xs text-slate-400 py-4">
                              No matching country found.
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Phone Number
                    </label>
                    <div className="flex items-center rounded-xl border border-slate-200 overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500">
                      <span className="px-3.5 py-2.5 bg-slate-100 text-slate-700 font-mono text-sm font-bold border-r border-slate-200 shrink-0">
                        {selectedCountry.dialCode}
                      </span>
                      <input
                        type="tel"
                        required
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="300 1234567"
                        className="flex-1 px-3.5 py-2.5 text-sm focus:outline-none font-mono"
                      />
                    </div>
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      We will send a 6-digit confirmation code.
                    </span>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
                  >
                    <span>Send Verification Code</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                /* Phone Step 2: Verification Code Input */
                <form onSubmit={handlePhoneVerifyOtp} className="space-y-4">
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-100 text-center">
                    <span className="text-xs text-slate-600 block">
                      Verification code sent to:
                    </span>
                    <span className="font-mono font-bold text-emerald-900 text-sm block mt-0.5">
                      {selectedCountry.dialCode} {phoneNumber}
                    </span>
                    <div className="mt-2 inline-block px-2.5 py-1 rounded-full bg-emerald-200/60 text-emerald-950 font-mono text-xs font-bold">
                      Demo Code: {generatedOtp}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1 text-center">
                      Enter 6-Digit Code
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      placeholder="123456"
                      className="w-full text-center tracking-widest font-mono text-2xl py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPhoneStep('input')}
                      className="w-1/3 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50"
                    >
                      Change Number
                    </button>
                    <button
                      type="submit"
                      className="w-2/3 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Verify &amp; Start</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Footer: Skip / Continue as guest */}
          <div className="pt-4 border-t border-slate-100 flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <button
                type="button"
                onClick={onClose}
                className="text-slate-500 hover:text-slate-800 font-semibold hover:underline cursor-pointer"
              >
                Continue as Guest (Explore App)
              </button>
              <span className="text-[11px] text-slate-400">Balochi Language Preservation</span>
            </div>

            {onOpenFullscreenAuth && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenFullscreenAuth();
                }}
                className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold text-center hover:underline cursor-pointer pt-1"
              >
                Open Atmospheric Full-Screen Portal (درباجہ)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
