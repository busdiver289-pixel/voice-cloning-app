export type LanguageCode = 'balochi' | 'darija' | 'spanish' | 'japanese' | 'french' | 'german';

export interface LanguageInfo {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
  description: string;
  speechCode: string;
  hasScriptTransliteration?: boolean;
  hasUrduTranslation?: boolean;
}

export type ExerciseType =
  | 'multiple_choice'
  | 'word_selection'
  | 'translation'
  | 'typing'
  | 'listening'
  | 'matching'
  | 'fill_in_the_blank'
  | 'speaking';

export interface MatchingPair {
  id: string;
  left: string;
  right: string;
  transliteration?: string;
  urduTranslation?: string;
}

export interface Exercise {
  id: string;
  lessonId: string;
  type: ExerciseType;
  prompt: string;
  targetText?: string;
  transliteration?: string;
  urduTranslation?: string;
  correctAnswer: string;
  acceptedAnswers?: string[];
  options?: string[];
  wordBank?: string[];
  matchingPairs?: MatchingPair[];
  audioText?: string;
  hint?: string;
  grammarNote?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export interface Lesson {
  id: string;
  unitId: string;
  title: string;
  description: string;
  iconName: string;
  xpReward: number;
  exercises: Exercise[];
  targetWordIds: string[];
}

export interface Unit {
  id: string;
  sectionId: string;
  number: number;
  title: string;
  description: string;
  color: string;
  lessons: Lesson[];
  milestoneTest?: {
    id: string;
    title: string;
    xpReward: number;
  };
}

export interface Section {
  id: string;
  number: number;
  title: string;
  description: string;
  units: Unit[];
}

export interface Course {
  language: LanguageCode;
  title: string;
  sections: Section[];
}

export type MasteryLevel = 'new' | 'beginning' | 'learning' | 'familiar' | 'mastered';

export interface VocabularyItem {
  id: string;
  lexId?: string; // Direct link to canonical LexiconEntry (prevents duplication)
  language: LanguageCode;
  word: string;
  transliteration?: string;
  translation: string;
  urduTranslation?: string;
  partOfSpeech: 'noun' | 'verb' | 'adjective' | 'greeting' | 'phrase' | 'number' | 'other';
  exampleTarget: string;
  exampleTransliteration?: string;
  exampleEnglish: string;
  exampleUrdu?: string;
  audioText: string;
  category: string;
  masteryScore: number; // 0 to 100
  mistakeCount: number;
  correctCount: number;
  lastPracticed?: string;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  requirement: number;
  currentValue: (user: UserProfile) => number;
  gemReward: number;
  icon: string;
  isUnlocked: boolean;
  isClaimed: boolean;
}

export interface UserSettings {
  soundEffects: boolean;
  autoPlayAudio: boolean;
  voiceSpeed: 'normal' | 'slow';
  useGeminiVoice: boolean;
  hapticFeedback: boolean;
  speechRecognitionEnabled: boolean;
  preferredPracticeType: 'balanced' | 'listening' | 'speaking' | 'flashcards' | 'quiz';
  difficultyPreference: 'adaptive' | 'beginner' | 'intermediate' | 'advanced';
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatarSeed: string;
  nativeLanguage: string;
  learningLanguage: LanguageCode;
  xp: number;
  level: number;
  streak: number;
  longestStreak: number;
  lastActivityDate: string; // YYYY-MM-DD
  activeDates: string[]; // ['2026-09-28', '2026-09-29', '2026-09-30']
  hearts: number; // max 5
  maxHearts: number;
  gems: number;
  dailyGoalXp: number;
  todayXp: number;
  unlockedLessons: string[];
  completedLessons: string[];
  streakFreezeCount: number;
  settings: UserSettings;
  claimedAchievements: string[];
  isAuthenticated?: boolean;
  authProvider?: 'google' | 'email' | 'phone' | 'guest';
  phoneNumber?: string;
  countryCode?: string;
  fullName?: string;
  learningQueueLexiconIds?: string[];
  bookmarkedLexiconIds?: string[];
  vocabularyReviews?: Record<string, import('./review').LearnerVocabularyReview>;
  detailedMistakes?: import('./review').DetailedMistakeRecord[];
  streakFreeze?: import('./review').StreakFreezeRecord;
  lexiconMastery?: Record<
    string,
    {
      masteryScore: number;
      status: 'new' | 'learning' | 'weak' | 'practicing' | 'mastered';
      mistakeCount: number;
      correctCount: number;
    }
  >;
}

export * from './review';

export interface MistakeLog {
  id: string;
  exerciseId: string;
  questionPrompt: string;
  targetWord?: string;
  userAnswer: string;
  correctAnswer: string;
  language: LanguageCode;
  timestamp: number;
}

export interface ShopItem {
  id: string;
  title: string;
  description: string;
  costGems: number;
  icon: string;
  category: 'hearts' | 'streak' | 'boost' | 'unlock';
}
