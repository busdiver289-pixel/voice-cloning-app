/**
 * Darbarjah Smart Review & Mistake Hub Type Definitions
 * Phase 1: Spaced Review Scheduling & Deterministic Mistake Tracking
 */

export type MasteryStatus = 'new' | 'learning' | 'weak' | 'practicing' | 'mastered';

export type MistakeCategory =
  | 'meaning'
  | 'Balochi → English'
  | 'English → Balochi'
  | 'native script recognition'
  | 'Latin recognition'
  | 'pronunciation/listening'
  | 'definition'
  | 'spelling';

/**
 * Learner Vocabulary Review Data Model
 * Tracks spaced repetition state referencing canonical lexicon ID without duplicating dictionary records.
 */
export interface LearnerVocabularyReview {
  lexiconId: string;
  firstLearnedAt: number;
  lastPracticedAt: number;
  lastCorrectAt?: number;
  lastIncorrectAt?: number;
  totalAttempts: number;
  correctAttempts: number;
  incorrectAttempts: number;
  consecutiveCorrect: number;
  masteryScore: number; // 0 to 100
  masteryStatus: MasteryStatus;
  reviewCount: number;
  nextReviewAt: number; // UTC millisecond timestamp
  difficulty: 'easy' | 'medium' | 'hard';
  mistakeCount: number;
  sourceLessonId?: string;
  sourceUnitId?: string;
}

/**
 * Detailed Mistake Log Record
 */
export interface DetailedMistakeRecord {
  id: string;
  lexiconId: string;
  exerciseId: string;
  exerciseType: string;
  timestamp: number;
  expectedAnswer: string;
  learnerAnswer?: string;
  mistakeCategory?: MistakeCategory;
}

/**
 * Streak Freeze Data Model Foundation
 */
export interface StreakFreezeRecord {
  freezeCount: number;
  freezeEarnedAt?: string;
  freezeUsedAt?: string;
  freezeReason?: string;
}

export interface SmartReviewSummary {
  dueCount: number;
  mistakeCount: number;
  weakCount: number;
  masteredCount: number;
  totalTracked: number;
}
