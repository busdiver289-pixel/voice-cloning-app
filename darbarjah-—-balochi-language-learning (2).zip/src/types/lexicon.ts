/**
 * Balochi Lexical Database & Lexicon Engine Type Definitions
 */

export type LexiconPos =
  | 'n'
  | 'adj'
  | 'v'
  | 'adv'
  | 'prep'
  | 'pron'
  | 'conj'
  | 'interj'
  | 'num'
  | 'phrase'
  | 'affix'
  | 'other';

export interface LexiconDefinition {
  id: string;
  english: string;
  urdu?: string | null;
  domain?: string | null; // e.g. linguistics, agriculture, botany, economics, nautical
  scientificName?: string; // e.g. Diospyros ebenum
  grammaticalNote?: string;
}

export type LexiconRelationType =
  | 'variant_of'
  | 'synonym_of'
  | 'related_to'
  | 'derived_from'
  | 'cross_reference';

export interface LexiconReference {
  arabic: string;
  latin: string;
  refId?: string;
  type?: LexiconRelationType;
  note?: string;
}

export interface LexiconExampleSentence {
  id?: string;
  arabic: string;
  latin: string;
  english: string;
  urdu?: string;
}

export interface LexiconAudio {
  type: 'authentic_recording' | 'ai_preview' | 'unavailable';
  url?: string;
  source?: string;
  speaker?: string;
  verified?: boolean;
  dialect?: string;
  recordingDate?: string;
  notes?: string;
}

export interface LexiconVariantRelation {
  arabic: string;
  latin: string;
  refId?: string;
  relationshipType?: 'variant_of' | 'dialect_form' | 'spelling_variant';
  region?: 'Makran' | 'Rakhshan' | 'Koh-e-Suleman' | 'Eastern' | 'Southern' | 'Western' | 'General';
  source?: string;
  note?: string;
}

export interface LexiconRepairAudit {
  sourceFile: string;
  sourcePage?: number;
  originalImportedValue: string;
  correctedValue: string;
  note: string;
}

export interface LexiconEntry {
  id: string;
  arabic: string;
  latin: string;
  headword: string;
  partOfSpeech: LexiconPos;
  domain?: string;
  definitions: LexiconDefinition[];
  synonyms?: LexiconReference[];
  variants?: (LexiconReference | LexiconVariantRelation)[];
  crossReferences?: LexiconReference[];
  examples?: LexiconExampleSentence[];
  audio?: LexiconAudio;
  audioUrl?: string; // Real audio only, never fabricated
  frequency?: 'high' | 'medium' | 'low';
  etymology?: string;
  sourceBook?: string;
  sourceFile?: string;
  sourcePage?: number;
  sourceEntryIndex?: number;
  originalImportedValue?: string;
  normalizedValue?: string;
  status?: 'canonical' | 'repaired' | 'anomaly';
  repairAudit?: LexiconRepairAudit;
}

export interface LexiconImportAuditReport {
  timestamp: string;
  sourceBook: string;
  totalPagesProcessed: number;
  totalEntriesGenerated: number;
  entriesWithArabic: number;
  entriesWithLatin: number;
  entriesWithEnglish: number;
  entriesWithUrdu: number;
  entriesWithMultipleMeanings: number;
  entriesWithVariants: number;
  entriesWithSynonyms: number;
  entriesWithDomain: number;
  entriesWithPos: number;
  entriesWithAudio: number;
  entriesWithoutAudio: number;
  duplicatesRemoved: number;
  parsingAnomalies: Array<{
    page?: number;
    rawText: string;
    issue: string;
  }>;
}

export type PersonalVocabStatus = 'new' | 'learning' | 'weak' | 'practicing' | 'mastered';

export interface PersonalLexiconState {
  wordId: string;
  status: PersonalVocabStatus;
  masteryScore: number; // 0 to 100
  isBookmarked: boolean;
  isInLearningQueue: boolean;
  mistakeCount: number;
  correctCount: number;
  lastPracticed?: number;
}
